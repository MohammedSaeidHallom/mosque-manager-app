foreground_xml = """<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="108dp"
    android:height="108dp"
    android:viewportWidth="960"
    android:viewportHeight="960">
    
    <group android:scaleX="0.85" android:scaleY="0.85" android:pivotX="480" android:pivotY="480">
        <!-- Moon -->
        <path
            android:fillColor="#DCA94D"
            android:pathData="M 640 100 A 400 400 0 1 0 760 820 A 350 350 0 1 1 640 100 Z" />
            
        <!-- Base for Mosque -->
        <path
            android:fillColor="#DCA94D"
            android:pathData="M 280 780 L 680 780 C 680 780 620 810 500 810 C 380 810 280 780 280 780 Z" />
            
        <!-- Main Dome -->
        <path
            android:fillColor="#DCA94D"
            android:pathData="M 400 780 C 400 600 580 600 580 780 Z" />
            
        <!-- Main Dome Spire -->
        <path
            android:fillColor="#DCA94D"
            android:pathData="M 485 600 L 485 550 L 495 550 L 495 600 Z" />
        <path
            android:fillColor="#DCA94D"
            android:pathData="M 490 530 A 10 10 0 1 0 491 530 Z" 
            android:strokeColor="#DCA94D" android:strokeWidth="15" android:strokeLineCap="round"/>
            
        <!-- Left Minaret -->
        <path
            android:fillColor="#DCA94D"
            android:pathData="M 330 780 L 330 620 L 345 620 L 345 780 Z" />
        <path
            android:fillColor="#DCA94D"
            android:pathData="M 320 620 L 355 620 L 355 600 L 337.5 540 L 320 600 Z" />
            
        <!-- Right Minaret -->
        <path
            android:fillColor="#DCA94D"
            android:pathData="M 610 780 L 610 580 L 625 580 L 625 780 Z" />
        <path
            android:fillColor="#DCA94D"
            android:pathData="M 600 580 L 635 580 L 635 560 L 617.5 500 L 600 560 Z" />
            
        <!-- Small Dome Left -->
        <path
            android:fillColor="#DCA94D"
            android:pathData="M 345 780 C 345 700 400 700 400 780 Z" />
            
        <!-- Small Dome Right -->
        <path
            android:fillColor="#DCA94D"
            android:pathData="M 580 780 C 580 700 635 700 635 780 Z" />
            
        <!-- Big Star -->
        <path
            android:fillColor="#DCA94D"
            android:pathData="M 540 380 L 560 440 L 620 460 L 560 480 L 540 540 L 520 480 L 460 460 L 520 440 Z" />
            
        <!-- Small Stars -->
        <path
            android:fillColor="#DCA94D"
            android:pathData="M 400 240 L 410 270 L 440 280 L 410 290 L 400 320 L 390 290 L 360 280 L 390 270 Z" />
        <path
            android:fillColor="#DCA94D"
            android:pathData="M 720 300 L 725 315 L 740 320 L 725 325 L 720 340 L 715 325 L 700 320 L 715 315 Z" />
        <path
            android:fillColor="#DCA94D"
            android:pathData="M 320 400 L 325 410 L 335 415 L 325 420 L 320 430 L 315 420 L 305 415 L 315 410 Z" />
    </group>
</vector>
"""

with open('app/src/main/res/drawable/ic_launcher_foreground.xml', 'w') as f:
    f.write(foreground_xml)

