import re

with open("app/src/main/java/com/example/utils/PdfGenerator.kt", "r") as f:
    content = f.read()

# Add imports
if "import android.text.StaticLayout" not in content:
    content = content.replace("import android.graphics.Paint", "import android.graphics.Paint\nimport android.text.StaticLayout\nimport android.text.TextPaint\nimport android.text.Layout")

# Find drawTable function
old_draw_table = """        fun drawTable(headers: List<String>, data: List<List<String>>, weights: List<Float>) {
            val totalWeight = weights.sum()
            val availableWidth = PAGE_WIDTH - 2 * MARGIN
            val colWidths = weights.map { (it / totalWeight) * availableWidth }
            val rowHeight = 25f
            
            checkNewPage(rowHeight)
            val headerBgPaint = Paint().apply { color = Color.parseColor("#059669") }
            canvas.drawRect(MARGIN, yPos, PAGE_WIDTH - MARGIN, yPos + rowHeight, headerBgPaint)
            
            var xPos = PAGE_WIDTH - MARGIN
            headers.forEachIndexed { i, header ->
                canvas.drawText(header, xPos - 5f, yPos + 17f, tableHeaderPaint)
                xPos -= colWidths[i]
            }
            yPos += rowHeight
            val rowBgPaint1 = Paint().apply { color = Color.parseColor("#F9FAFB") }
            val rowBgPaint2 = Paint().apply { color = Color.WHITE }
            val borderPaint = Paint().apply { color = Color.parseColor("#E5E7EB"); style = Paint.Style.STROKE; strokeWidth = 1f }
            data.forEachIndexed { rowIndex, row ->
                checkNewPage(rowHeight)
                val bgPaint = if (rowIndex % 2 == 0) rowBgPaint1 else rowBgPaint2
                canvas.drawRect(MARGIN, yPos, PAGE_WIDTH - MARGIN, yPos + rowHeight, bgPaint)
                canvas.drawRect(MARGIN, yPos, PAGE_WIDTH - MARGIN, yPos + rowHeight, borderPaint)
                var cX = PAGE_WIDTH - MARGIN
                row.forEachIndexed { colIndex, text ->
                    // Truncate text if it's too long, simple approach
                    val maxLength = if (text.length > 30) 30 else text.length
                    val truncText = text.substring(0, maxLength)
                    canvas.drawText(truncText, cX - 5f, yPos + 17f, normalPaint)
                    if (colIndex < row.size - 1) {
                        canvas.drawLine(cX - colWidths[colIndex], yPos, cX - colWidths[colIndex], yPos + rowHeight, borderPaint)
                    }
                    cX -= colWidths[colIndex]
                }
                yPos += rowHeight
            }
        }"""

new_draw_table = """        fun drawTable(headers: List<String>, data: List<List<String>>, weights: List<Float>) {
            val totalWeight = weights.sum()
            val availableWidth = PAGE_WIDTH - 2 * MARGIN
            val colWidths = weights.map { (it / totalWeight) * availableWidth }
            val defaultRowHeight = 25f
            
            checkNewPage(defaultRowHeight)
            val headerBgPaint = Paint().apply { color = Color.parseColor("#059669") }
            canvas.drawRect(MARGIN, yPos, PAGE_WIDTH - MARGIN, yPos + defaultRowHeight, headerBgPaint)
            
            var xPos = PAGE_WIDTH - MARGIN
            headers.forEachIndexed { i, header ->
                canvas.drawText(header, xPos - 5f, yPos + 17f, tableHeaderPaint)
                xPos -= colWidths[i]
            }
            yPos += defaultRowHeight
            val rowBgPaint1 = Paint().apply { color = Color.parseColor("#F9FAFB") }
            val rowBgPaint2 = Paint().apply { color = Color.WHITE }
            val borderPaint = Paint().apply { color = Color.parseColor("#E5E7EB"); style = Paint.Style.STROKE; strokeWidth = 1f }
            
            val textPaint = TextPaint(normalPaint)
            
            data.forEachIndexed { rowIndex, row ->
                // First calculate max height needed for this row
                var maxLines = 1
                val layouts = row.mapIndexed { colIndex, text ->
                    val width = colWidths[colIndex] - 10f // 5f padding on each side
                    val layout = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                        StaticLayout.Builder.obtain(text, 0, text.length, textPaint, width.toInt())
                            .setAlignment(Layout.Alignment.ALIGN_NORMAL) // RIGHT ALIGNMENT since rtl text and textPaint aligns right
                            .setLineSpacing(0f, 1f)
                            .setIncludePad(false)
                            .build()
                    } else {
                        @Suppress("DEPRECATION")
                        StaticLayout(text, textPaint, width.toInt(), Layout.Alignment.ALIGN_NORMAL, 1f, 0f, false)
                    }
                    if (layout.lineCount > maxLines) maxLines = layout.lineCount
                    layout
                }
                
                val rowHeight = Math.max(defaultRowHeight, (maxLines * textPaint.textSize) + 10f)
                checkNewPage(rowHeight)
                
                val bgPaint = if (rowIndex % 2 == 0) rowBgPaint1 else rowBgPaint2
                canvas.drawRect(MARGIN, yPos, PAGE_WIDTH - MARGIN, yPos + rowHeight, bgPaint)
                canvas.drawRect(MARGIN, yPos, PAGE_WIDTH - MARGIN, yPos + rowHeight, borderPaint)
                
                var cX = PAGE_WIDTH - MARGIN
                row.forEachIndexed { colIndex, _ ->
                    val layout = layouts[colIndex]
                    canvas.save()
                    // cX is the right edge of the column.
                    // Because layout draws from x=0 to width, and our align is ALIGN_NORMAL.
                    // Actually StaticLayout with ALIGN_NORMAL and RTL text will align to right if direction is RTL.
                    // Let's just translate canvas and draw. 
                    // width is colWidths[colIndex]
                    // translate to left edge of the text bounds
                    canvas.translate(cX - colWidths[colIndex] + 5f, yPos + 5f)
                    layout.draw(canvas)
                    canvas.restore()
                    
                    if (colIndex < row.size - 1) {
                        canvas.drawLine(cX - colWidths[colIndex], yPos, cX - colWidths[colIndex], yPos + rowHeight, borderPaint)
                    }
                    cX -= colWidths[colIndex]
                }
                yPos += rowHeight
            }
        }"""

if old_draw_table in content:
    content = content.replace(old_draw_table, new_draw_table)
    with open("app/src/main/java/com/example/utils/PdfGenerator.kt", "w") as f:
        f.write(content)
    print("Replaced drawTable successfully")
else:
    print("Could not find old_draw_table")

