foreground_xml = """<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="108dp"
    android:height="108dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <group android:scaleX="0.75" android:scaleY="0.75" android:pivotX="12" android:pivotY="12">
        <path
            android:fillColor="#DCA94D"
            android:pathData="M 18,2 C 11,2 6,7 6,12 C 6,17 11,22 18,22 C 13,22 9,17.5 9,12 C 9,6.5 13,2 18,2 Z" />
    </group>
</vector>
"""

with open('app/src/main/res/drawable/ic_launcher_foreground.xml', 'w') as f:
    f.write(foreground_xml)

ic_mosque_xml = """<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#DCA94D"
        android:pathData="M 18,2 C 11,2 6,7 6,12 C 6,17 11,22 18,22 C 13,22 9,17.5 9,12 C 9,6.5 13,2 18,2 Z" />
</vector>
"""

with open('app/src/main/res/drawable/ic_mosque.xml', 'w') as f:
    f.write(ic_mosque_xml)

