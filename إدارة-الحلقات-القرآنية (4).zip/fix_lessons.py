content = """@Composable
fun LessonRecordItem(
    record: com.example.data.LessonRecord,
    lessonId: String,
    updateRecord: (String, String, String) -> Unit
) {
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFF9FAFB)), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE5E7EB))) {
        Column(Modifier.padding(16.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(record.studentName, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                Row(Modifier.background(Color.White, androidx.compose.foundation.shape.RoundedCornerShape(8.dp)).padding(4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    val options = listOf(Triple("حضور", Color(0xFF16A34A), "حضور"), Triple("إذن", Color(0xFFD97706), "إذن"), Triple("غائب", Color.Red, "غائب"))
                    options.forEach { (label, color, value) ->
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable { updateRecord(record.studentId, "attendance", value) }) {
                            RadioButton(selected = record.attendance == value, onClick = { updateRecord(record.studentId, "attendance", value) }, colors = RadioButtonDefaults.colors(selectedColor = color, unselectedColor = Color.Gray), modifier = Modifier.size(24.dp))
                            Spacer(Modifier.width(2.dp))
                            Text(label, color = color, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            
            if (record.attendance == "حضور") {
                HorizontalDivider(Modifier.padding(vertical = 8.dp))
                Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("المنهج", fontSize = 12.sp, color = Color.Gray)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { updateRecord(record.studentId, "type", if (record.type == "تلاوة") "" else "تلاوة") }, colors = ButtonDefaults.buttonColors(containerColor = if (record.type == "تلاوة") MaterialTheme.colorScheme.primary else Color.LightGray), modifier = Modifier.weight(1f)) { Text("تلاوة") }
                        Button(onClick = { updateRecord(record.studentId, "type", if (record.type == "رشيدي") "" else "رشيدي") }, colors = ButtonDefaults.buttonColors(containerColor = if (record.type == "رشيدي") MaterialTheme.colorScheme.primary else Color.LightGray), modifier = Modifier.weight(1f)) { Text("رشيدي") }
                        Button(onClick = { updateRecord(record.studentId, "type", if (record.type == "قرآن غيباً") "" else "قرآن غيباً") }, colors = ButtonDefaults.buttonColors(containerColor = if (record.type == "قرآن غيباً") MaterialTheme.colorScheme.primary else Color.LightGray), modifier = Modifier.weight(1f)) { Text("قرآن غيباً", fontSize = 10.sp) }
                    }
                    
                    var pageText by remember { mutableStateOf(record.page ?: "") }
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                        OutlinedTextField(
                            value = pageText,
                            onValueChange = { pageText = it },
                            label = { CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) { Text("رقم/معلومات الصفحة", fontSize = 12.sp) } },
                            modifier = Modifier.fillMaxWidth().onFocusChanged { focusState ->
                                if (!focusState.isFocused) {
                                    updateRecord(record.studentId, "page", pageText)
                                }
                            },
                            singleLine = true,
                            textStyle = androidx.compose.ui.text.TextStyle(textAlign = TextAlign.Right, textDirection = androidx.compose.ui.text.style.TextDirection.Ltr)
                        )
                    }
                    
                    Text("التقييم", fontSize = 12.sp, color = Color.Gray)
                    val grades = listOf("ممتاز 100", "جيد جداً", "جيد", "وسط", "إعادة")
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        grades.take(3).forEach { grade ->
                            OutlinedButton(onClick = { updateRecord(record.studentId, "grade", if (record.grade == grade) "" else grade) }, colors = ButtonDefaults.outlinedButtonColors(containerColor = if (record.grade == grade) MaterialTheme.colorScheme.primary.copy(alpha=0.1f) else Color.Transparent), modifier = Modifier.weight(1f), contentPadding = PaddingValues(0.dp)) { Text(grade, fontSize = 10.sp) }
                        }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        grades.drop(3).forEach { grade ->
                            OutlinedButton(onClick = { updateRecord(record.studentId, "grade", if (record.grade == grade) "" else grade) }, colors = ButtonDefaults.outlinedButtonColors(containerColor = if (record.grade == grade) MaterialTheme.colorScheme.primary.copy(alpha=0.1f) else Color.Transparent), modifier = Modifier.weight(1f)) { Text(grade, fontSize = 10.sp) }
                        }
                    }
                    
                    Card(border = androidx.compose.foundation.BorderStroke(1.dp, Color.LightGray), colors = CardDefaults.cardColors(containerColor = Color.Transparent)) {
                        Column(Modifier.padding(8.dp)) {
                            Text("اختبار (اختياري)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = { updateRecord(record.studentId, "optTestType", if (record.optTestType == "اختبار رشيدي") "" else "اختبار رشيدي") }, colors = ButtonDefaults.buttonColors(containerColor = if (record.optTestType == "اختبار رشيدي") Color.DarkGray else Color.LightGray), modifier = Modifier.weight(1f), contentPadding = PaddingValues(0.dp)) { Text("رشيدي", fontSize = 10.sp) }
                                Button(onClick = { updateRecord(record.studentId, "optTestType", if (record.optTestType == "اختبار تلاوي") "" else "اختبار تلاوي") }, colors = ButtonDefaults.buttonColors(containerColor = if (record.optTestType == "اختبار تلاوي") Color.DarkGray else Color.LightGray), modifier = Modifier.weight(1f), contentPadding = PaddingValues(0.dp)) { Text("تلاوي", fontSize = 10.sp) }
                                Button(onClick = { updateRecord(record.studentId, "optTestType", if (record.optTestType == "قرآن غيباً") "" else "قرآن غيباً") }, colors = ButtonDefaults.buttonColors(containerColor = if (record.optTestType == "قرآن غيباً") Color.DarkGray else Color.LightGray), modifier = Modifier.weight(1f), contentPadding = PaddingValues(0.dp)) { Text("قرآن غيباً", fontSize = 10.sp) }
                            }
                            var optTestInfoText by remember { mutableStateOf(record.optTestInfo ?: "") }
                            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                                OutlinedTextField(
                                    value = optTestInfoText,
                                    onValueChange = { optTestInfoText = it },
                                    placeholder = { CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) { Text("معلومات الاختبار/الصفحة", fontSize = 12.sp) } },
                                    modifier = Modifier.fillMaxWidth().height(50.dp).onFocusChanged { focusState ->
                                        if (!focusState.isFocused) {
                                            updateRecord(record.studentId, "optTestInfo", optTestInfoText)
                                        }
                                    },
                                    textStyle = androidx.compose.ui.text.TextStyle(textAlign = TextAlign.Right, textDirection = androidx.compose.ui.text.style.TextDirection.Ltr)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
"""

with open('app/src/main/java/com/example/ui/LessonsTab.kt', 'r') as f:
    orig = f.read()
    
# Find the start of the bad @Composable
start_idx = orig.find("@Composable\nfun LessonRecordItem(")

new_orig = orig[:start_idx] + content

with open('app/src/main/java/com/example/ui/LessonsTab.kt', 'w') as f:
    f.write(new_orig)

