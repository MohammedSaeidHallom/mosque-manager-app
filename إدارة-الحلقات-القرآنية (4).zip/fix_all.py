import re

# 1. Write ic_launcher_foreground.xml
foreground_xml = """<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="108dp"
    android:height="108dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <group android:scaleX="0.75" android:scaleY="0.75" android:pivotX="12" android:pivotY="12">
        <group android:translateX="0.895" android:translateY="-0.895">
            <path
                android:fillColor="#DCA94D"
                android:pathData="M 7.185 2.895 A 10 10 0 1 0 21.105 16.815 A 10 10 0 1 1 7.185 2.895 Z" />
        </group>
    </group>
</vector>
"""

with open('app/src/main/res/drawable/ic_launcher_foreground.xml', 'w') as f:
    f.write(foreground_xml)

# 2. Write ic_mosque.xml
ic_mosque_xml = """<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <group android:translateX="0.895" android:translateY="-0.895">
        <path
            android:fillColor="#DCA94D"
            android:pathData="M 7.185 2.895 A 10 10 0 1 0 21.105 16.815 A 10 10 0 1 1 7.185 2.895 Z" />
    </group>
</vector>
"""

with open('app/src/main/res/drawable/ic_mosque.xml', 'w') as f:
    f.write(ic_mosque_xml)

# 3. Modify MosqueApp.kt
with open('app/src/main/java/com/example/ui/MosqueApp.kt', 'r') as f:
    content = f.read()

# Change splash screen icon to ic_mosque
content = content.replace('painterResource(id = R.drawable.ic_launcher_foreground)', 'painterResource(id = R.drawable.ic_mosque)')

# Change TopAppBar icon to use tint = Color.Unspecified
content = content.replace(
    'Icon(painter = painterResource(id = R.drawable.ic_mosque), contentDescription = null, modifier = Modifier.size(24.dp))',
    'Icon(painter = painterResource(id = R.drawable.ic_mosque), contentDescription = null, modifier = Modifier.size(24.dp), tint = Color.Unspecified)'
)

with open('app/src/main/java/com/example/ui/MosqueApp.kt', 'w') as f:
    f.write(content)

