import re

with open('app/src/main/java/com/example/ui/MosqueDashboard.kt', 'r') as f:
    content = f.read()

# Add isExporting state
old_vars = """    val context = LocalContext.current
    val openedTestId by viewModel.openedTestId.collectAsState()
    var present = 0
    var absent = 0
    var excused = 0
    var totalRecords = 0
    
    mosque.lessons.forEach { l ->
        l.records.forEach { r ->
            if (r.attendance.isNotEmpty()) {
                totalRecords++
                when (r.attendance) {
                    "حضور" -> present++
                    "غائب" -> absent++
                    "إذن" -> excused++
                }
            }
        }
    }
    
    val attendanceRate = if (totalRecords > 0) Math.round((present.toFloat() / totalRecords) * 100) else 0"""

new_vars = """    val context = LocalContext.current
    val openedTestId by viewModel.openedTestId.collectAsState()
    val isExporting by viewModel.isExporting.collectAsState()
    
    val attendanceRate = remember(mosque.lessons) {
        var present = 0
        var totalRecords = 0
        mosque.lessons.forEach { l ->
            l.records.forEach { r ->
                if (r.attendance.isNotEmpty()) {
                    totalRecords++
                    if (r.attendance == "حضور") present++
                }
            }
        }
        if (totalRecords > 0) Math.round((present.toFloat() / totalRecords) * 100) else 0
    }"""

content = content.replace(old_vars, new_vars)

# Replace buttons to call viewModel methods
old_buttons = """                    Button(onClick = {
                          PdfGenerator.generatePdf(context, mosque, currentTab.name, openedLessonId, reportStudentId)
                      }, colors = ButtonDefaults.buttonColors(containerColor = Color.Red), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)) {
                        Icon(Icons.Filled.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("حفظ PDF", fontSize = 12.sp)
                    }
                    Button(onClick = {
                          ExportUtils.shareWhatsApp(context, mosque, currentTab.name, openedLessonId, openedTestId, reportStudentId)
                    }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10b981)), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)) {
                        Icon(Icons.Filled.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("إرسال واتساب", fontSize = 12.sp)
                    }"""

new_buttons = """                    if (isExporting) {
                        CircularProgressIndicator(modifier = Modifier.size(24.dp), color = MaterialTheme.colorScheme.primary)
                    } else {
                        Button(onClick = {
                              viewModel.generatePdf(context, mosque, currentTab.name, openedLessonId, reportStudentId)
                          }, colors = ButtonDefaults.buttonColors(containerColor = Color.Red), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)) {
                            Icon(Icons.Filled.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("حفظ PDF", fontSize = 12.sp)
                        }
                        Button(onClick = {
                              viewModel.shareWhatsApp(context, mosque, currentTab.name, openedLessonId, openedTestId, reportStudentId)
                        }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10b981)), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)) {
                            Icon(Icons.Filled.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("إرسال واتساب", fontSize = 12.sp)
                        }
                    }"""
content = content.replace(old_buttons, new_buttons)

with open('app/src/main/java/com/example/ui/MosqueDashboard.kt', 'w') as f:
    f.write(content)
