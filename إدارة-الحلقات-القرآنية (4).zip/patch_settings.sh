cat << 'PATCH' > settings.patch
--- app/src/main/java/com/example/ui/SettingsTab.kt
+++ app/src/main/java/com/example/ui/SettingsTab.kt
@@ -187,24 +187,7 @@
             }
             itemsIndexed(filteredStudents, key = { _, student -> student.id }) { index, student ->
                 val isLast = index == filteredStudents.size - 1
-                Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White), shape = if (isLast) androidx.compose.foundation.shape.RoundedCornerShape(bottomStart = 12.dp, bottomEnd = 12.dp, topStart = 0.dp, topEnd = 0.dp) else androidx.compose.foundation.shape.RoundedCornerShape(0.dp)) {
-                    Column {
-                        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
-                            Text("\${index + 1}", modifier = Modifier.width(30.dp), color = Color.Gray)
-                            Text(student.fullName, modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
-                            Row(Modifier.width(100.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
-                                IconButton(onClick = {
-                                     editStudentName = student.fullName
-                                    showEditPrompt = student.id
-                                 }) {
-                                    Icon(Icons.Filled.Edit, contentDescription = "تعديل", tint = Color.Blue)
-                                }
-                                IconButton(onClick = { studentToDelete = student.id }) {
-                                    Icon(Icons.Filled.Delete, contentDescription = "حذف", tint = Color.Red)
-                                }
-                            }
-                        }
-                        if (!isLast) HorizontalDivider()
-                    }
-                }
+                StudentListItem(index, student, isLast, onEdit = {
+                    editStudentName = student.fullName
+                    showEditPrompt = student.id
+                }, onDelete = { studentToDelete = student.id })
             }
         }
     }
@@ -211,2 +194,27 @@
     }
 }
+
+@Composable
+fun StudentListItem(index: Int, student: com.example.data.Student, isLast: Boolean, onEdit: () -> Unit, onDelete: () -> Unit) {
+    Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White), shape = if (isLast) androidx.compose.foundation.shape.RoundedCornerShape(bottomStart = 12.dp, bottomEnd = 12.dp, topStart = 0.dp, topEnd = 0.dp) else androidx.compose.foundation.shape.RoundedCornerShape(0.dp)) {
+        Column {
+            Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
+                Text("\${index + 1}", modifier = Modifier.width(30.dp), color = Color.Gray)
+                Text(student.fullName, modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
+                Row(Modifier.width(100.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
+                    IconButton(onClick = onEdit) {
+                        Icon(Icons.Filled.Edit, contentDescription = "تعديل", tint = Color.Blue)
+                    }
+                    IconButton(onClick = onDelete) {
+                        Icon(Icons.Filled.Delete, contentDescription = "حذف", tint = Color.Red)
+                    }
+                }
+            }
+            if (!isLast) HorizontalDivider()
+        }
+    }
+}
PATCH
patch -p0 < settings.patch
