# Check if we can safely replace drawTable function
import re

with open("app/src/main/java/com/example/utils/PdfGenerator.kt", "r") as f:
    content = f.read()

print("StaticLayout in content:", "android.text.StaticLayout" in content)
