import re

with open("app/src/main/java/com/example/utils/PdfGenerator.kt", "r") as f:
    content = f.read()

# Add imports
if "import android.text.StaticLayout" not in content:
    content = content.replace("import android.graphics.Paint", "import android.graphics.Paint\nimport android.text.StaticLayout\nimport android.text.TextPaint\nimport android.text.Layout")


start_idx = content.find("fun drawTable(headers: List<String>")
end_idx = content.find("        when (currentTab) {", start_idx)

if start_idx != -1 and end_idx != -1:
    new_draw_table = """fun drawTable(headers: List<String>, data: List<List<String>>, weights: List<Float>) {
            val totalWeight = weights.sum()
            val availableWidth = PAGE_WIDTH - 2 * MARGIN
            val colWidths = weights.map { (it / totalWeight) * availableWidth }
            val defaultRowHeight = 25f
            
            checkNewPage(defaultRowHeight)
            val headerBgPaint = Paint().apply { color = Color.parseColor("#059669") }
            canvas.drawRect(MARGIN, yPos, PAGE_WIDTH - MARGIN, yPos + defaultRowHeight, headerBgPaint)
            
            var xPos = PAGE_WIDTH - MARGIN
            headers.forEachIndexed { i, header ->
                canvas.drawText(header, xPos - 5f, yPos + 17f, tableHeaderPaint)
                xPos -= colWidths[i]
            }
            yPos += defaultRowHeight
            val rowBgPaint1 = Paint().apply { color = Color.parseColor("#F9FAFB") }
            val rowBgPaint2 = Paint().apply { color = Color.WHITE }
            val borderPaint = Paint().apply { color = Color.parseColor("#E5E7EB"); style = Paint.Style.STROKE; strokeWidth = 1f }
            
            val textPaint = TextPaint(normalPaint)
            
            data.forEachIndexed { rowIndex, row ->
                var maxLines = 1
                val layouts = row.mapIndexed { colIndex, text ->
                    val width = colWidths[colIndex] - 10f
                    val layout = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                        StaticLayout.Builder.obtain(text, 0, text.length, textPaint, width.toInt())
                            .setAlignment(Layout.Alignment.ALIGN_OPPOSITE)
                            .setLineSpacing(0f, 1f)
                            .setIncludePad(false)
                            .build()
                    } else {
                        @Suppress("DEPRECATION")
                        StaticLayout(text, textPaint, width.toInt(), Layout.Alignment.ALIGN_OPPOSITE, 1f, 0f, false)
                    }
                    if (layout.lineCount > maxLines) maxLines = layout.lineCount
                    layout
                }
                
                val rowHeight = Math.max(defaultRowHeight, (maxLines * textPaint.textSize) + 15f)
                checkNewPage(rowHeight)
                
                val bgPaint = if (rowIndex % 2 == 0) rowBgPaint1 else rowBgPaint2
                canvas.drawRect(MARGIN, yPos, PAGE_WIDTH - MARGIN, yPos + rowHeight, bgPaint)
                canvas.drawRect(MARGIN, yPos, PAGE_WIDTH - MARGIN, yPos + rowHeight, borderPaint)
                
                var cX = PAGE_WIDTH - MARGIN
                row.forEachIndexed { colIndex, _ ->
                    val layout = layouts[colIndex]
                    canvas.save()
                    canvas.translate(cX - colWidths[colIndex] + 5f, yPos + 7f)
                    layout.draw(canvas)
                    canvas.restore()
                    
                    if (colIndex < row.size - 1) {
                        canvas.drawLine(cX - colWidths[colIndex], yPos, cX - colWidths[colIndex], yPos + rowHeight, borderPaint)
                    }
                    cX -= colWidths[colIndex]
                }
                yPos += rowHeight
            }
        }
"""
    content = content[:start_idx] + new_draw_table + content[end_idx:]
    with open("app/src/main/java/com/example/utils/PdfGenerator.kt", "w") as f:
        f.write(content)
    print("Replaced drawTable successfully")
else:
    print("Could not find boundaries")

