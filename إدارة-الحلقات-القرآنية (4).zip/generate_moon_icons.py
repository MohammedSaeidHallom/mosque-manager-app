# foreground for app icon (108x108 with 960x960 viewport)
foreground_xml = """<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="108dp"
    android:height="108dp"
    android:viewportWidth="960"
    android:viewportHeight="960">
    <group android:scaleX="0.9" android:scaleY="0.9" android:pivotX="480" android:pivotY="480">
        <!-- Moon -->
        <path
            android:fillColor="#DCA94D"
            android:pathData="M 640 150 A 350 350 0 1 0 760 820 A 300 300 0 1 1 640 150 Z" />
    </group>
</vector>
"""

with open('app/src/main/res/drawable/ic_launcher_foreground.xml', 'w') as f:
    f.write(foreground_xml)

# icon for top bar (24x24)
ic_mosque_xml = """<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="960"
    android:viewportHeight="960">
    <path
        android:fillColor="#DCA94D"
        android:pathData="M 640 150 A 350 350 0 1 0 760 820 A 300 300 0 1 1 640 150 Z" />
</vector>
"""

with open('app/src/main/res/drawable/ic_mosque.xml', 'w') as f:
    f.write(ic_mosque_xml)

