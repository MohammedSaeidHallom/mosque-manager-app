import sys

with open("app/src/main/java/com/example/ui/MosqueDashboard.kt", "r") as f:
    lines = f.readlines()

new_buttons = """                    Button(onClick = {
                          PdfGenerator.generatePdf(context, mosque, currentTab.name, openedLessonId, reportStudentId)
                      }, colors = ButtonDefaults.buttonColors(containerColor = Color.Red), contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)) {
                        Icon(Icons.Filled.PictureAsPdf, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(2.dp))
                        Text("PDF", fontSize = 11.sp)
                    }
                    
                    var showWhatsappMenu by remember { mutableStateOf(false) }
                    Box {
                        Button(onClick = { showWhatsappMenu = true }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)), contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)) {
                            Icon(Icons.Filled.Share, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(Modifier.width(2.dp))
                            Text("واتساب", fontSize = 11.sp)
                        }
                        DropdownMenu(expanded = showWhatsappMenu, onDismissRequest = { showWhatsappMenu = false }) {
                            DropdownMenuItem(text = { Text("كصورة") }, onClick = {
                                showWhatsappMenu = false
                                viewModel.shareAsImage(context, mosque, currentTab.name, openedLessonId, reportStudentId, "com.whatsapp")
                            })
                            DropdownMenuItem(text = { Text("كنص") }, onClick = {
                                showWhatsappMenu = false
                                ExportUtils.shareWhatsApp(context, mosque, currentTab.name, openedLessonId, openedTestId, reportStudentId)
                            })
                        }
                    }
"""

# Let's find the exact indices
start_idx = -1
end_idx = -1
for i, line in enumerate(lines):
    if "PdfGenerator.generatePdf(" in line and start_idx == -1:
        start_idx = i - 1 # the Button(onClick = { line
    if "إرسال واتساب" in line and end_idx == -1:
        end_idx = i + 2 # the line after closing brace of Button
        break

if start_idx != -1 and end_idx != -1:
    lines = lines[:start_idx] + [new_buttons] + lines[end_idx:]
    with open("app/src/main/java/com/example/ui/MosqueDashboard.kt", "w") as f:
        f.writelines(lines)
    print("Replaced successfully")
else:
    print(f"Could not find indices: {start_idx}, {end_idx}")

