import re

with open("app/src/main/java/com/example/utils/PdfGenerator.kt", "r") as f:
    content = f.read()

# 1. Update generatePdf signature
content = content.replace(
    "fun generatePdf(context: Context, mosque: Mosque, currentTab: String, openedLessonId: String?, reportStudentId: String?, shareAsImage: Boolean = false) {",
    "fun generatePdf(context: Context, mosque: Mosque, currentTab: String, openedLessonId: String?, reportStudentId: String?, shareAsImage: Boolean = false, targetPackage: String? = null) {"
)

# 2. Update intent handling
old_intent_block = """                val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                    type = "image/jpeg"
                    putExtra(android.content.Intent.EXTRA_STREAM, uri)
                    flags = android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                }
                context.startActivity(android.content.Intent.createChooser(intent, "مشاركة كصورة"))"""

new_intent_block = """                val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                    type = "image/jpeg"
                    putExtra(android.content.Intent.EXTRA_STREAM, uri)
                    flags = android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                    if (targetPackage != null) {
                        setPackage(targetPackage)
                    }
                }
                try {
                    context.startActivity(intent)
                } catch (e: Exception) {
                    context.startActivity(android.content.Intent.createChooser(intent, "مشاركة كصورة"))
                }"""

content = content.replace(old_intent_block, new_intent_block)

with open("app/src/main/java/com/example/utils/PdfGenerator.kt", "w") as f:
    f.write(content)


# 3. Update MosqueViewModel
with open("app/src/main/java/com/example/ui/MosqueViewModel.kt", "r") as f:
    vm_content = f.read()

old_share_method = """    fun shareAsImage(context: Context, mosque: Mosque, tab: String, lessonId: String?, studentId: String?) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            _isExporting.value = true
            try {
                PdfGenerator.generatePdf(context, mosque, tab, lessonId, studentId, shareAsImage = true)
            } finally {
                _isExporting.value = false
            }
        }
    }"""

new_share_method = """    fun shareAsImage(context: Context, mosque: Mosque, tab: String, lessonId: String?, studentId: String?, targetPackage: String? = null) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            _isExporting.value = true
            try {
                PdfGenerator.generatePdf(context, mosque, tab, lessonId, studentId, shareAsImage = true, targetPackage = targetPackage)
            } finally {
                _isExporting.value = false
            }
        }
    }"""

vm_content = vm_content.replace(old_share_method, new_share_method)

with open("app/src/main/java/com/example/ui/MosqueViewModel.kt", "w") as f:
    f.write(vm_content)


# 4. Update MosqueDashboard
with open("app/src/main/java/com/example/ui/MosqueDashboard.kt", "r") as f:
    dash_content = f.read()

old_buttons = """                        Button(onClick = {
                              viewModel.generatePdf(context, mosque, currentTab.name, openedLessonId, reportStudentId)
                          }, colors = ButtonDefaults.buttonColors(containerColor = Color.Red), contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)) {
                            Icon(Icons.Filled.PictureAsPdf, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(Modifier.width(2.dp))
                            Text("PDF", fontSize = 11.sp)
                        }
                        Button(onClick = {
                              viewModel.shareAsImage(context, mosque, currentTab.name, openedLessonId, reportStudentId)
                          }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)), contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)) {
                            Icon(Icons.Filled.Image, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(Modifier.width(2.dp))
                            Text("صورة", fontSize = 11.sp)
                        }
                        Button(onClick = {
                              viewModel.shareWhatsApp(context, mosque, currentTab.name, openedLessonId, openedTestId, reportStudentId)
                        }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10b981)), contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)) {
                            Icon(Icons.Filled.Share, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(Modifier.width(2.dp))
                            Text("واتساب", fontSize = 11.sp)
                        }"""

new_buttons = """                        Button(onClick = {
                              viewModel.generatePdf(context, mosque, currentTab.name, openedLessonId, reportStudentId)
                          }, colors = ButtonDefaults.buttonColors(containerColor = Color.Red), contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)) {
                            Icon(Icons.Filled.PictureAsPdf, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(Modifier.width(2.dp))
                            Text("PDF", fontSize = 11.sp)
                        }
                        Button(onClick = {
                              viewModel.shareAsImage(context, mosque, currentTab.name, openedLessonId, reportStudentId)
                          }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)), contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)) {
                            Icon(Icons.Filled.Image, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(Modifier.width(2.dp))
                            Text("صورة", fontSize = 11.sp)
                        }
                        Button(onClick = {
                              viewModel.shareAsImage(context, mosque, currentTab.name, openedLessonId, reportStudentId, "com.whatsapp")
                          }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)), contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)) {
                            Icon(Icons.Filled.Image, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(Modifier.width(2.dp))
                            Text("واتس(صورة)", fontSize = 10.sp)
                        }
                        Button(onClick = {
                              viewModel.shareWhatsApp(context, mosque, currentTab.name, openedLessonId, openedTestId, reportStudentId)
                        }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10b981)), contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)) {
                            Icon(Icons.Filled.Share, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(Modifier.width(2.dp))
                            Text("واتس(نص)", fontSize = 10.sp)
                        }"""

dash_content = dash_content.replace(old_buttons, new_buttons)

with open("app/src/main/java/com/example/ui/MosqueDashboard.kt", "w") as f:
    f.write(dash_content)
