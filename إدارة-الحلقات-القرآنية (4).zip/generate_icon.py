import re

svg_path = "M278-638q-21 0-29.5-8.5T240-676q0-40 19-74t51-56l125-84q20-14 45-14t45 14l125 84q32 22 51 56t19 74q0 21-8.5 29.5T682-638H278ZM40-200v-411q-18-11-29-28.5T0-680q0-23 24-56t56-64q32 31 56 64t24 56q0 23-11 40.5T120-611v171h80v-80q0-25 16-48t46-30h436q30 7 46 30t16 48v80h80v-171q-18-11-29-28.5T800-680q0-23 24-56t56-64q32 31 56 64t24 56q0 23-11 40.5T920-611v411q0 33-23.5 56.5T840-120H600q-17 0-28.5-11.5T560-160v-120q0-33-23.5-56.5T480-360q-33 0-56.5 23.5T400-280v120q0 17-11.5 28.5T360-120H120q-33 0-56.5-23.5T40-200Z"

# Let's write the foreground vector XML
foreground_xml = f"""<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="108dp"
    android:height="108dp"
    android:viewportWidth="960"
    android:viewportHeight="960">
    <group
        android:translateY="960"
        android:scaleX="0.6"
        android:scaleY="0.6"
        android:pivotX="480"
        android:pivotY="-480">
        <path
            android:fillColor="#DCA94D"
            android:pathData="{svg_path}" />
        <path
            android:fillColor="#DCA94D"
            android:pathData="M760-760q-21 0-41 5t-39 15q45 28 72.5 74.5T780-560q0 58-39 100t-97 54q30 19 65.5 22.5T780-380q75 0 127.5-52.5T960-560q0-75-52.5-127.5T760-760Z" />
    </group>
</vector>
"""

with open('app/src/main/res/drawable/ic_launcher_foreground.xml', 'w') as f:
    f.write(foreground_xml)

# Write the background vector XML
background_xml = """<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="108dp"
    android:height="108dp"
    android:viewportWidth="108"
    android:viewportHeight="108">
    <path
        android:fillColor="#1B4F35"
        android:pathData="M0,0h108v108h-108z" />
</vector>
"""

with open('app/src/main/res/drawable/ic_launcher_background.xml', 'w') as f:
    f.write(background_xml)

