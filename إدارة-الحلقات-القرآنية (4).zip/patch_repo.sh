sed -i 's/@JsonClass(generateAdapter = true)/@androidx.compose.runtime.Immutable\n@JsonClass(generateAdapter = true)/g' app/src/main/java/com/example/data/MosqueRepository.kt
