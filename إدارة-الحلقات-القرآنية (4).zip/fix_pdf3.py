import re

with open("app/src/main/java/com/example/utils/PdfGenerator.kt", "r") as f:
    content = f.read()

# 1. Fix textPaint alignment for StaticLayout
content = content.replace(
    "val textPaint = TextPaint(normalPaint)",
    "val textPaint = TextPaint(normalPaint).apply { textAlign = Paint.Align.LEFT }"
)

# 2. Use ALIGN_CENTER for table cells
content = content.replace("Layout.Alignment.ALIGN_OPPOSITE", "Layout.Alignment.ALIGN_CENTER")

with open("app/src/main/java/com/example/utils/PdfGenerator.kt", "w") as f:
    f.write(content)
