import re

# 1. Update MosqueViewModel
with open("app/src/main/java/com/example/ui/MosqueViewModel.kt", "r") as f:
    vm_content = f.read()

new_share_method = """    fun shareAsImage(context: Context, mosque: Mosque, tab: String, lessonId: String?, studentId: String?) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            _isExporting.value = true
            try {
                PdfGenerator.generatePdf(context, mosque, tab, lessonId, studentId, shareAsImage = true)
            } finally {
                _isExporting.value = false
            }
        }
    }
"""
vm_content = vm_content.replace(
    "fun importDb(json: String, onComplete: (Boolean) -> Unit) {",
    new_share_method + "\n    fun importDb(json: String, onComplete: (Boolean) -> Unit) {"
)

with open("app/src/main/java/com/example/ui/MosqueViewModel.kt", "w") as f:
    f.write(vm_content)


# 2. Update MosqueDashboard
with open("app/src/main/java/com/example/ui/MosqueDashboard.kt", "r") as f:
    dash_content = f.read()

old_buttons = """                        Button(onClick = {
                              viewModel.generatePdf(context, mosque, currentTab.name, openedLessonId, reportStudentId)
                          }, colors = ButtonDefaults.buttonColors(containerColor = Color.Red), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)) {
                            Icon(Icons.Filled.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("حفظ PDF", fontSize = 12.sp)
                        }
                        Button(onClick = {
                              viewModel.shareWhatsApp(context, mosque, currentTab.name, openedLessonId, openedTestId, reportStudentId)
                        }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10b981)), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)) {
                            Icon(Icons.Filled.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("إرسال واتساب", fontSize = 12.sp)
                        }"""

new_buttons = """                        Button(onClick = {
                              viewModel.generatePdf(context, mosque, currentTab.name, openedLessonId, reportStudentId)
                          }, colors = ButtonDefaults.buttonColors(containerColor = Color.Red), contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)) {
                            Icon(Icons.Filled.PictureAsPdf, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(Modifier.width(2.dp))
                            Text("PDF", fontSize = 11.sp)
                        }
                        Button(onClick = {
                              viewModel.shareAsImage(context, mosque, currentTab.name, openedLessonId, reportStudentId)
                          }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)), contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)) {
                            Icon(Icons.Filled.Image, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(Modifier.width(2.dp))
                            Text("صورة", fontSize = 11.sp)
                        }
                        Button(onClick = {
                              viewModel.shareWhatsApp(context, mosque, currentTab.name, openedLessonId, openedTestId, reportStudentId)
                        }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10b981)), contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)) {
                            Icon(Icons.Filled.Share, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(Modifier.width(2.dp))
                            Text("واتساب", fontSize = 11.sp)
                        }"""

dash_content = dash_content.replace(old_buttons, new_buttons)

with open("app/src/main/java/com/example/ui/MosqueDashboard.kt", "w") as f:
    f.write(dash_content)

