cat << 'PATCH' > splash.patch
--- app/src/main/java/com/example/ui/MosqueApp.kt
+++ app/src/main/java/com/example/ui/MosqueApp.kt
@@ -19,2 +19,3 @@
 import androidx.compose.ui.graphics.ColorFilter
+import androidx.compose.ui.graphics.Brush
 import androidx.compose.ui.platform.LocalContext
@@ -37,17 +38,15 @@
     }
+    val gradient = Brush.verticalGradient(
+        colors = listOf(Color(0xFF2E6F4A), Color(0xFF1B4F35))
+    )
     Box(
         modifier = Modifier
             .fillMaxSize()
-            .background(MaterialTheme.colorScheme.background),
+            .background(gradient),
         contentAlignment = Alignment.Center
     ) {
         Column(horizontalAlignment = Alignment.CenterHorizontally) {
-            Text(
-                text = "السلام عليكم ورحمة الله وبركاته",
-                style = MaterialTheme.typography.headlineSmall,
-                color = MaterialTheme.colorScheme.primary,
-                fontWeight = FontWeight.Bold
-            )
-            Spacer(modifier = Modifier.height(24.dp))
             Image(
                 painter = painterResource(id = R.drawable.ic_launcher_foreground),
                 contentDescription = null,
                 modifier = Modifier
-                    .size(120.dp)
-                    .background(MaterialTheme.colorScheme.primary, RoundedCornerShape(24.dp)),
-                colorFilter = ColorFilter.tint(Color.White)
+                    .size(180.dp)
+            )
+            Spacer(modifier = Modifier.height(24.dp))
+            Text(
+                text = "إدارة الحلقات القرآنية",
+                style = MaterialTheme.typography.headlineSmall,
+                color = Color(0xFFDCA94D),
+                fontWeight = FontWeight.Bold
             )
         }
     }
 }
PATCH
patch -p0 < splash.patch
