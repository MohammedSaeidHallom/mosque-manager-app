import re

with open('app/src/main/java/com/example/ui/MosqueViewModel.kt', 'r') as f:
    content = f.read()

# Add imports for Context, PdfGenerator, ExportUtils
if 'import android.content.Context' not in content:
    content = content.replace('import androidx.lifecycle.ViewModel', 'import android.content.Context\nimport androidx.lifecycle.ViewModel')
if 'import com.example.utils.PdfGenerator' not in content:
    content = content.replace('import androidx.lifecycle.viewModelScope', 'import com.example.utils.PdfGenerator\nimport com.example.utils.ExportUtils\nimport androidx.lifecycle.viewModelScope')

# Add isExporting flow and the functions
new_code = """
    private val _isExporting = MutableStateFlow(false)
    val isExporting: StateFlow<Boolean> = _isExporting.asStateFlow()

    fun generatePdf(context: Context, mosque: Mosque, tab: String, lessonId: String?, studentId: String?) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            _isExporting.value = true
            try {
                PdfGenerator.generatePdf(context, mosque, tab, lessonId, studentId)
            } finally {
                _isExporting.value = false
            }
        }
    }

    fun shareWhatsApp(context: Context, mosque: Mosque, tab: String, lessonId: String?, testId: String?, studentId: String?) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            _isExporting.value = true
            try {
                ExportUtils.shareWhatsApp(context, mosque, tab, lessonId, testId, studentId)
            } finally {
                _isExporting.value = false
            }
        }
    }

    fun importDb(json: String, onComplete: (Boolean) -> Unit) {
"""
content = content.replace('fun importDb(json: String, onComplete: (Boolean) -> Unit) {', new_code)

with open('app/src/main/java/com/example/ui/MosqueViewModel.kt', 'w') as f:
    f.write(content)
