import re

with open("app/src/main/java/com/example/utils/PdfGenerator.kt", "r") as f:
    content = f.read()

# Add method parameter shareAsImage
content = content.replace(
    "fun generatePdf(context: Context, mosque: Mosque, currentTab: String, openedLessonId: String?, reportStudentId: String?) {",
    "fun generatePdf(context: Context, mosque: Mosque, currentTab: String, openedLessonId: String?, reportStudentId: String?, shareAsImage: Boolean = false) {"
)

start_idx = content.find("        try {")
end_idx = content.find("        } catch (e: Exception) {", start_idx)

if start_idx != -1 and end_idx != -1:
    new_finish = """        try {
            val file = File(context.cacheDir, "Export_${mosque.name}.pdf")
            document.writeTo(FileOutputStream(file))
            document.close()
            
            if (shareAsImage) {
                val fd = android.os.ParcelFileDescriptor.open(file, android.os.ParcelFileDescriptor.MODE_READ_ONLY)
                val renderer = android.graphics.pdf.PdfRenderer(fd)
                val pageCount = renderer.pageCount
                var totalHeight = 0
                val bitmaps = mutableListOf<android.graphics.Bitmap>()
                for (i in 0 until pageCount) {
                    val p = renderer.openPage(i)
                    val w = p.width * 2
                    val h = p.height * 2
                    val bitmap = android.graphics.Bitmap.createBitmap(w, h, android.graphics.Bitmap.Config.ARGB_8888)
                    val bgCanvas = android.graphics.Canvas(bitmap)
                    bgCanvas.drawColor(android.graphics.Color.WHITE)
                    p.render(bitmap, null, null, android.graphics.pdf.PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    bitmaps.add(bitmap)
                    totalHeight += h
                    p.close()
                }
                renderer.close()
                fd.close()
                
                val finalWidth = bitmaps.firstOrNull()?.width ?: 0
                val finalBitmap = android.graphics.Bitmap.createBitmap(finalWidth, totalHeight, android.graphics.Bitmap.Config.ARGB_8888)
                val finalCanvas = android.graphics.Canvas(finalBitmap)
                var currentY = 0f
                for (b in bitmaps) {
                    finalCanvas.drawBitmap(b, 0f, currentY, null)
                    currentY += b.height
                    b.recycle()
                }
                
                val imgFile = java.io.File(context.cacheDir, "Export_${mosque.name}.jpg")
                val outStream = java.io.FileOutputStream(imgFile)
                finalBitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 90, outStream)
                outStream.close()
                finalBitmap.recycle()
                
                val uri = androidx.core.content.FileProvider.getUriForFile(context, "${context.packageName}.provider", imgFile)
                val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                    type = "image/jpeg"
                    putExtra(android.content.Intent.EXTRA_STREAM, uri)
                    flags = android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                }
                context.startActivity(android.content.Intent.createChooser(intent, "مشاركة كصورة"))
            } else {
                val uri = androidx.core.content.FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
                val intent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, "application/pdf")
                    flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
                }
                context.startActivity(Intent.createChooser(intent, "عرض PDF"))
            }
"""
    
    rest = content[end_idx:]
    rest = rest.replace('Toast.makeText(context, "خطأ في إنشاء PDF", Toast.LENGTH_SHORT).show()', 
                        'e.printStackTrace()\n            Toast.makeText(context, "خطأ في إنشاء أو مشاركة الملف", Toast.LENGTH_SHORT).show()')
    
    content = content[:start_idx] + new_finish + rest
    with open("app/src/main/java/com/example/utils/PdfGenerator.kt", "w") as f:
        f.write(content)
    print("Replaced finish block successfully")
else:
    print("Could not find boundaries")

