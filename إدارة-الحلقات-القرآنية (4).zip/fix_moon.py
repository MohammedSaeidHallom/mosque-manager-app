foreground_xml = """<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="108dp"
    android:height="108dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <group android:scaleX="0.75" android:scaleY="0.75" android:pivotX="12" android:pivotY="12">
        <path
            android:fillColor="#DCA94D"
            android:pathData="M 12 21 A 9 9 0 1 1 21 12 A 7.5 7.5 0 0 0 12 21 Z" />
    </group>
</vector>
"""

with open('app/src/main/res/drawable/ic_launcher_foreground.xml', 'w') as f:
    f.write(foreground_xml)

ic_mosque_xml = """<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <group android:scaleX="0.9" android:scaleY="0.9" android:pivotX="12" android:pivotY="12">
        <path
            android:fillColor="#DCA94D"
            android:pathData="M 12 21 A 9 9 0 1 1 21 12 A 7.5 7.5 0 0 0 12 21 Z" />
    </group>
</vector>
"""

with open('app/src/main/res/drawable/ic_mosque.xml', 'w') as f:
    f.write(ic_mosque_xml)

