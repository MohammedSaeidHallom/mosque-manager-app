cat << 'PATCH' > reports.patch
--- app/src/main/java/com/example/ui/ReportsTab.kt
+++ app/src/main/java/com/example/ui/ReportsTab.kt
@@ -56,12 +56,14 @@
                     if (reportStudentId == "all") {
+                        val allStudentLessons = remember(mosque.lessons, mosque.students) {
+                            mosque.students.associateWith { student ->
+                                mosque.lessons.mapNotNull { l ->
+                                    val r = l.records.find { it.studentId == student.id }
+                                    if (r != null) Pair(l, r) else null
+                                }
+                            }
+                        }
                         LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                             items(mosque.students, key = { it.id }) { student ->
-                                val studentLessons = mosque.lessons.mapNotNull { l ->
-                                    val r = l.records.find { it.studentId == student.id }
-                                    if (r != null) Pair(l, r) else null
-                                }
+                                val studentLessons = allStudentLessons[student] ?: emptyList()
                                 val presentCount = studentLessons.count { it.second.attendance == "حضور" }
PATCH
patch -p0 < reports.patch
