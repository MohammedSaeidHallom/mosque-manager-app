import re

with open("app/src/main/java/com/example/ui/MosqueApp.kt", "r") as f:
    content = f.read()

old_splash = """        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Image(
                painter = painterResource(id = R.drawable.ic_mosque),
                contentDescription = null,
                modifier = Modifier
                    .size(180.dp)
            )"""

new_splash = """        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = "السلام عليكم ورحمة الله وبركاته",
                style = MaterialTheme.typography.titleMedium,
                color = Color.White,
                fontWeight = FontWeight.Normal
            )
            Spacer(modifier = Modifier.height(16.dp))
            Image(
                painter = painterResource(id = R.drawable.ic_mosque),
                contentDescription = null,
                modifier = Modifier
                    .size(180.dp)
            )"""

content = content.replace(old_splash, new_splash)

with open("app/src/main/java/com/example/ui/MosqueApp.kt", "w") as f:
    f.write(content)

