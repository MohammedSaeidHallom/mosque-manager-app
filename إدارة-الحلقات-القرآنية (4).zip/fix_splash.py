import re

with open('app/src/main/java/com/example/ui/MosqueApp.kt', 'r') as f:
    content = f.read()

# add import
content = content.replace('import androidx.compose.ui.graphics.ColorFilter', 'import androidx.compose.ui.graphics.ColorFilter\nimport androidx.compose.ui.graphics.Brush')

splash_code = """@Composable
fun SplashScreen(onTimeout: () -> Unit) {
    LaunchedEffect(Unit) {
        delay(2500)
        onTimeout()
    }
    val gradient = Brush.verticalGradient(
        colors = listOf(Color(0xFF2E6F4A), Color(0xFF1B4F35))
    )
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(gradient),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Image(
                painter = painterResource(id = R.drawable.ic_launcher_foreground),
                contentDescription = null,
                modifier = Modifier
                    .size(180.dp)
            )
            Spacer(modifier = Modifier.height(24.dp))
            Text(
                text = "إدارة الحلقات القرآنية",
                style = MaterialTheme.typography.headlineSmall,
                color = Color(0xFFDCA94D),
                fontWeight = FontWeight.Bold
            )
        }
    }
}"""

# replace old splash screen
content = re.sub(r'@Composable\nfun SplashScreen\(onTimeout: \(\) -> Unit\) \{.*?\n\}\n\n@OptIn', splash_code + '\n\n@OptIn', content, flags=re.DOTALL)

with open('app/src/main/java/com/example/ui/MosqueApp.kt', 'w') as f:
    f.write(content)
