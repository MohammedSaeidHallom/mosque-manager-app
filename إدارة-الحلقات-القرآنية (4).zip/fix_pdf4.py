import re

with open("app/src/main/java/com/example/utils/PdfGenerator.kt", "r") as f:
    content = f.read()

# Change ALIGN_CENTER back to ALIGN_NORMAL so it aligns to right for Arabic text
content = content.replace("Layout.Alignment.ALIGN_CENTER", "Layout.Alignment.ALIGN_NORMAL")

with open("app/src/main/java/com/example/utils/PdfGenerator.kt", "w") as f:
    f.write(content)
