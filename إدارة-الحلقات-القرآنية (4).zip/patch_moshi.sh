sed -i 's/implementation(libs.moshi.kotlin)//g' app/build.gradle.kts
sed -i 's/import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory//g' app/src/main/java/com/example/data/MosqueRepository.kt
sed -i 's/.add(KotlinJsonAdapterFactory())//g' app/src/main/java/com/example/data/MosqueRepository.kt
