import re

with open('app/src/main/java/com/example/ui/LessonsTab.kt', 'r') as f:
    content = f.read()

# The start of the items block
start_str = "            items(filteredRecords, key = { it.studentId }) { record ->"
end_str = "            }\n            \n            item {"

start_idx = content.find(start_str)
end_idx = content.find(end_str, start_idx) + len("            }")

original_items_block = content[start_idx:end_idx]

extracted_items_block = """            items(filteredRecords, key = { it.studentId }) { record ->
                LessonRecordItem(
                    record = record,
                    lessonId = lesson.id,
                    updateRecord = { studentId, field, value ->
                        viewModel.updateLessonRecord(lesson.id, studentId, field, value)
                    }
                )
            }"""

# The extracted composable function to be placed at the bottom of the file
extracted_composable = """

@Composable
fun LessonRecordItem(
    record: com.example.data.LessonRecord,
    lessonId: String,
    updateRecord: (String, String, String) -> Unit
) {
""" + original_items_block.replace("            items(filteredRecords, key = { it.studentId }) { record ->", "").replace("            }", "") + "}"

# replace viewModel.updateLessonRecord(...) with updateRecord(...)
extracted_composable = re.sub(r'viewModel\.updateLessonRecord\(lesson\.id, record\.studentId, "([^"]+)", ([^)]+)\)', r'updateRecord(record.studentId, "\1", \2)', extracted_composable)

# fix indentation of extracted composable
lines = extracted_composable.split('\n')
indented_lines = []
for line in lines:
    if line.startswith('                '):
        indented_lines.append(line[12:])
    elif line.startswith('            '):
        indented_lines.append(line[12:])
    else:
        indented_lines.append(line)
        
extracted_composable = '\n'.join(indented_lines)

new_content = content[:start_idx] + extracted_items_block + content[end_idx:] + extracted_composable

with open('app/src/main/java/com/example/ui/LessonsTab.kt', 'w') as f:
    f.write(new_content)

