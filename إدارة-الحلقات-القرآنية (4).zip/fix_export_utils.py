import re

with open('app/src/main/java/com/example/utils/ExportUtils.kt', 'r') as f:
    content = f.read()

content = content.replace('" ص${r.page}"', '" ${r.page}"')
content = content.replace('" ص${r.optTestInfo}"', '" ${r.optTestInfo}"')
content = content.replace('" ص${test.info}"', '" ${test.info}"')
content = content.replace('" ص${t.info}"', '" ${t.info}"')

with open('app/src/main/java/com/example/utils/ExportUtils.kt', 'w') as f:
    f.write(content)
