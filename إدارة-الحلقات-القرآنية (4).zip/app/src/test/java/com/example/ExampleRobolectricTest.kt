package com.example

import androidx.test.core.app.ApplicationProvider
import com.example.data.*
import com.example.utils.StudentDuplicateDetector
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36], application = MosqueApplication::class)
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val app = ApplicationProvider.getApplicationContext<MosqueApplication>()
    val appName = app.getString(R.string.app_name)
    assertEquals("إدارة الحلقات", appName)
  }

  @Test
  fun `department normalization works as expected`() {
    assertEquals(StudentDepartments.TILAWA, StudentDepartments.normalize("تلاوة"))
    assertEquals(StudentDepartments.RASHIDI, StudentDepartments.normalize("رشيدي"))
    assertEquals(StudentDepartments.QURAN_GHAIBAN, StudentDepartments.normalize("قرآن غيباً"))
    assertEquals(StudentDepartments.QURAN_GHAIBAN, StudentDepartments.normalize("حفظ غيباً"))
    assertEquals(StudentDepartments.TAJWEED, StudentDepartments.normalize("تجويد"))
  }

  @Test
  fun `scopedStudents isolates current mosque students from other groups`() {
    val s1 = Student("s1", "أحمد", 1000L, StudentDepartments.TILAWA, "المجموعة الأولى")
    val s2 = Student("s2", "محمود", 1001L, StudentDepartments.TILAWA, "المجموعة الثانية")

    val mosque = Mosque(
      id = "m1",
      name = "المجموعة الأولى",
      students = listOf(s1, s2),
      lessons = emptyList(),
      tests = emptyList()
    )

    assertEquals(1, mosque.scopedStudents.size)
    assertEquals("أحمد", mosque.scopedStudents.first().fullName)
  }

  @Test
  fun `examAppointment empty date automatically defaults to لم يحدد`() {
    val appt = ExamAppointment(id = "e1", studentId = "s1", studentName = "خالد", appointmentDate = "")
    assertEquals("لم يحدد", appt.safeAppointmentDate)
  }

  @Test
  fun `duplicate detector finds duplicates and respects ignore and refresh`() {
    val s1 = Student("s1", "خالد محمد", 1000L, StudentDepartments.TILAWA, "مسجد 1")
    val s2 = Student("s2", "خالد محمد", 1001L, StudentDepartments.RASHIDI, "مسجد 1")
    val m1 = Mosque("m1", "مسجد 1", listOf(s1, s2), emptyList(), emptyList())

    val groups = StudentDuplicateDetector.findDuplicates(listOf(m1))
    assertEquals(1, groups.size)
    val key = groups.first().key

    val afterIgnore = StudentDuplicateDetector.findDuplicates(listOf(m1), setOf(key))
    assertTrue(afterIgnore.isEmpty())

    val afterRefresh = StudentDuplicateDetector.findDuplicates(listOf(m1), emptySet())
    assertEquals(1, afterRefresh.size)
  }
}
