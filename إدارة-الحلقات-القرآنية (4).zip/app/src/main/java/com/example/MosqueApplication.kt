package com.example

import android.app.Application
import com.example.data.MosqueRepository

class MosqueApplication : Application() {
    lateinit var repository: MosqueRepository
        private set

    override fun onCreate() {
        super.onCreate()
        repository = MosqueRepository(this)
    }
}
