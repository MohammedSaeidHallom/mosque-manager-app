package com.example

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.example.ui.MosqueApp
import com.example.ui.MosqueViewModel
import com.example.ui.theme.MosqueTheme

class MainActivity : ComponentActivity() {
    private val viewModel: MosqueViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // الرأس بتدرج داكن => أيقونات شريط الحالة فاتحة
        enableEdgeToEdge(statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT))
        setContent {
            MosqueTheme {
                MosqueApp(viewModel = viewModel)
            }
        }
    }

    override fun onStop() {
        // نضمن حفظ آخر تعديل حتى لو أغلق النظام التطبيق في الخلفية
        viewModel.flushSaveNow()
        super.onStop()
    }
}
