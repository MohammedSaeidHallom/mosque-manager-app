package com.example.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.outlined.DeleteSweep
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.PictureAsPdf
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

/**
 * شريحة اختيار خفيفة بديلة عن FilterChip: مكوّن واحد بدل طبقات Surface + حركات + ripple مركّبة.
 * تضمن عدم انكسار النص عمودياً عبر maxLines = 1 و softWrap = false.
 */
@Composable
fun LightChip(
    selected: Boolean,
    text: String,
    selectedColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val shape = RoundedCornerShape(8.dp)
    Box(
        modifier = modifier
            .height(28.dp)
            .clip(shape)
            .background(if (selected) selectedColor else Color.Transparent)
            .border(1.dp, if (selected) selectedColor else Slate300, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 9.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            color = if (selected) Color.White else Slate700,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            maxLines = 1,
            softWrap = false,
            overflow = TextOverflow.Ellipsis
        )
    }
}

/**
 * حقل نص خفيف بديل عن OutlinedTextField لسرعة التمرير والكتابة الفورية.
 */
@Composable
fun LightTextField(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier,
    trailing: (@Composable () -> Unit)? = null
) {
    val shape = RoundedCornerShape(8.dp)
    BasicTextField(
        value = value,
        onValueChange = onValueChange,
        singleLine = true,
        textStyle = MaterialTheme.typography.bodySmall.copy(textAlign = TextAlign.Right, color = Slate900),
        cursorBrush = SolidColor(Brand600),
        modifier = modifier,
        decorationBox = { inner ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .heightIn(min = 36.dp)
                    .clip(shape)
                    .background(Color.White)
                    .border(BorderStroke(1.dp, Slate300), shape)
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
                    if (value.isEmpty()) {
                        Text(
                            placeholder,
                            style = MaterialTheme.typography.labelSmall,
                            color = Slate400,
                            maxLines = 1,
                            softWrap = false,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    inner()
                }
                trailing?.invoke()
            }
        }
    )
}

/**
 * زر موحّد لشريط الأدوات العلوي يمنع انكسار الكلمات عمودياً (مثل واتساب / صورة / PDF / إضافة).
 */
@Composable
fun TopToolbarButton(
    text: String,
    icon: ImageVector,
    containerColor: Color,
    contentColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    FilledTonalButton(
        onClick = onClick,
        colors = ButtonDefaults.filledTonalButtonColors(
            containerColor = containerColor,
            contentColor = contentColor
        ),
        shape = RoundedCornerShape(8.dp),
        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp),
        modifier = modifier.height(36.dp)
    ) {
        Icon(icon, contentDescription = null, modifier = Modifier.size(14.dp))
        Spacer(Modifier.width(3.dp))
        Text(
            text = text,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            softWrap = false,
            overflow = TextOverflow.Visible
        )
    }
}

/**
 * بطاقة الرأس والأزرار العلوية الموحدة (مثل تبويب الجزء / السجل تماماً)
 * تجمع: زر الرجوع (اختياري) + الأيقونة + العنوان + التاريخ + زر الحفظ الأخضر البارز في الأعلى،
 * وتحتها مباشرة صف أزرار الإجراءات (إضافة، واتساب، PDF، صورة، مسح).
 */
@Composable
fun UnifiedTopActionCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    onSaveClick: (() -> Unit)? = null,
    saveButtonText: String = "حفظ",
    hasUnsavedChanges: Boolean = false,
    onBackClick: (() -> Unit)? = null,
    primaryActionText: String? = null,
    primaryActionIcon: ImageVector? = null,
    onPrimaryActionClick: (() -> Unit)? = null,
    onWhatsAppClick: (() -> Unit)? = null,
    onPdfClick: (() -> Unit)? = null,
    onImageClick: (() -> Unit)? = null,
    onClearClick: (() -> Unit)? = null
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            // الصف الأول: العنوان والتاريخ على اليمين + زر الحفظ الأخضر على اليسار
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .weight(1f)
                        .padding(end = 8.dp)
                ) {
                    if (onBackClick != null) {
                        IconButton(
                            onClick = onBackClick,
                            modifier = Modifier.size(34.dp)
                        ) {
                            Icon(
                                Icons.Filled.ArrowForward,
                                contentDescription = "رجوع",
                                tint = Slate700,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(Modifier.width(4.dp))
                    }
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier.size(38.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                icon,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }
                    Spacer(Modifier.width(8.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = title,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Slate900,
                            maxLines = 1,
                            softWrap = false,
                            overflow = TextOverflow.Ellipsis
                        )
                        if (subtitle.isNotBlank()) {
                            Text(
                                text = subtitle,
                                style = MaterialTheme.typography.labelSmall,
                                color = Slate500,
                                maxLines = 1,
                                softWrap = false,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }

                if (onSaveClick != null) {
                    Button(
                        onClick = onSaveClick,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (hasUnsavedChanges) Amber500 else Emerald500
                        ),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                        modifier = Modifier.height(38.dp)
                    ) {
                        Icon(Icons.Filled.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(
                            text = saveButtonText,
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            softWrap = false
                        )
                    }
                }
            }

            // الصف الثاني: شريط الأزرار الموحد (إضافة، واتساب، PDF، صورة، مسح)
            if (primaryActionText != null || onWhatsAppClick != null || onPdfClick != null || onImageClick != null || onClearClick != null) {
                Spacer(Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (primaryActionText != null && onPrimaryActionClick != null && primaryActionIcon != null) {
                        TopToolbarButton(
                            text = primaryActionText,
                            icon = primaryActionIcon,
                            containerColor = MaterialTheme.colorScheme.primaryContainer,
                            contentColor = MaterialTheme.colorScheme.primary,
                            onClick = onPrimaryActionClick,
                            modifier = Modifier.weight(1.25f)
                        )
                    }

                    if (onWhatsAppClick != null) {
                        TopToolbarButton(
                            text = "واتساب",
                            icon = Icons.Filled.Share,
                            containerColor = Emerald50,
                            contentColor = Emerald600,
                            onClick = onWhatsAppClick,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    if (onPdfClick != null) {
                        TopToolbarButton(
                            text = "PDF",
                            icon = Icons.Outlined.PictureAsPdf,
                            containerColor = Rose50,
                            contentColor = Rose500,
                            onClick = onPdfClick,
                            modifier = Modifier.weight(0.85f)
                        )
                    }

                    if (onImageClick != null) {
                        TopToolbarButton(
                            text = "صورة",
                            icon = Icons.Outlined.Image,
                            containerColor = Brand50,
                            contentColor = Brand600,
                            onClick = onImageClick,
                            modifier = Modifier.weight(0.95f)
                        )
                    }

                    if (onClearClick != null) {
                        IconButton(
                            onClick = onClearClick,
                            modifier = Modifier.size(34.dp)
                        ) {
                            Icon(
                                Icons.Outlined.DeleteSweep,
                                contentDescription = "مسح الكل",
                                tint = Rose500,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
