package com.example.ui

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.ExamAppointment
import com.example.data.ExamScheduleGroup
import com.example.data.Mosque
import com.example.ui.theme.*
import com.example.utils.toStandardDigits
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun ExamScheduleTab(
    viewModel: MosqueViewModel,
    mosque: Mosque,
    openedExamGroupId: String? = null
) {
    val context = LocalContext.current
    val groups = mosque.safeExamScheduleGroups
    var groupToDelete by remember { mutableStateOf<ExamScheduleGroup?>(null) }
    var searchQuery by remember { mutableStateOf("") }

    // إذا كانت هناك مجموعة مفتوحة، نعرض محرر المجموعة السريع (مع التحديد المتعدد وتخصيص كل اسم)
    if (openedExamGroupId != null) {
        val group = groups.find { it.id == openedExamGroupId }
        if (group != null) {
            ExamGroupEditor(
                viewModel = viewModel,
                mosque = mosque,
                group = group
            )
            return
        }
    }

    if (groupToDelete != null) {
        val grp = groupToDelete!!
        AlertDialog(
            onDismissRequest = { groupToDelete = null },
            shape = RoundedCornerShape(16.dp),
            containerColor = Color.White,
            title = { Text("حذف مجموعة المواعيد", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "هل أنت متأكد من حذف «${grp.title}» (${grp.day} ${grp.dateStr}) وجميع مواعيد الطلاب المسجلة بداخلها؟",
                    style = MaterialTheme.typography.bodyMedium
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteExamGroup(grp.id)
                        groupToDelete = null
                        Toast.makeText(context, "تم حذف مجموعة المواعيد", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Rose500),
                    shape = RoundedCornerShape(8.dp)
                ) { Text("نعم، حذف") }
            },
            dismissButton = {
                TextButton(onClick = { groupToDelete = null }) { Text("إلغاء", color = Slate500) }
            }
        )
    }

    val filteredGroups = remember(groups, searchQuery) {
        if (searchQuery.isBlank()) {
            groups.sortedByDescending { it.createdAt }
        } else {
            groups.sortedByDescending { it.createdAt }.filter { g ->
                g.title.contains(searchQuery, ignoreCase = true) ||
                    g.dateStr.contains(searchQuery, ignoreCase = true) ||
                    g.day.contains(searchQuery, ignoreCase = true) ||
                    g.appointments.any { it.studentName.contains(searchQuery, ignoreCase = true) }
            }
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(bottom = 28.dp)
    ) {
        // Header Card for Creating a New Exam Schedule Group Saved with Today's Date
        item(key = "exam_groups_header", contentType = "header") {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f).padding(end = 8.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.primaryContainer,
                            modifier = Modifier.size(40.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    Icons.Filled.EventAvailable,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }
                        Spacer(Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                "مجموعات مواعيد الاختبار",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Slate900,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                "تُحفظ كل مجموعة بتاريخ اليوم الذي صُممت فيه (${groups.size.toString().toStandardDigits()} مجموعة)",
                                style = MaterialTheme.typography.labelSmall,
                                color = Slate500,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    Button(
                        onClick = {
                            viewModel.createNewExamGroup()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Brand600),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(
                            "تحديد موعد",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            softWrap = false
                        )
                    }
                }
            }
        }

        if (groups.size > 1) {
            item(key = "exam_groups_search", contentType = "search") {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("بحث بتاريخ المجموعة أو اسم الطالب...", fontSize = 12.sp) },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, tint = Slate400, modifier = Modifier.size(18.dp)) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Filled.Close, contentDescription = "مسح", modifier = Modifier.size(16.dp))
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    singleLine = true
                )
            }
        }

        if (groups.isEmpty()) {
            item(key = "exam_groups_empty", contentType = "empty") {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 20.dp),
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(28.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = Slate100,
                            modifier = Modifier.size(60.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    Icons.Filled.CalendarMonth,
                                    contentDescription = null,
                                    tint = Slate400,
                                    modifier = Modifier.size(32.dp)
                                )
                            }
                        }
                        Spacer(Modifier.height(14.dp))
                        Text(
                            "لا توجد مجموعات مواعيد مسجلة حالياً",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Slate800
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "اضغط على زر «تحديد موعد» لإنشاء مجموعة مواعيد جديدة بتاريخ اليوم، ثم أضف الطلاب بالتحديد المتعدد وخصّص بيانات كل طالب بسهولة.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Slate500,
                            textAlign = TextAlign.Center
                        )
                        Spacer(Modifier.height(16.dp))
                        Button(
                            onClick = { viewModel.createNewExamGroup() },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("إنشاء مجموعة تحديد موعد بتاريخ اليوم", maxLines = 1, softWrap = false)
                        }
                    }
                }
            }
        } else {
            items(filteredGroups, key = { it.id }, contentType = { "exam_group_row" }) { group ->
                val rashidiCount = group.appointments.count { it.section == "رشيدي" }
                val tilawaCount = group.appointments.count { it.section != "رشيدي" }

                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.openExamGroup(group.id) },
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                if (group.day.isNotBlank()) {
                                    Text(
                                        text = group.day,
                                        color = Brand700,
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.labelMedium,
                                        maxLines = 1,
                                        softWrap = false,
                                        modifier = Modifier
                                            .background(Brand50, RoundedCornerShape(6.dp))
                                            .padding(horizontal = 8.dp, vertical = 2.dp)
                                    )
                                    Spacer(Modifier.width(8.dp))
                                }
                                Text(
                                    text = group.dateStr.ifBlank { group.title },
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Slate900,
                                    maxLines = 1,
                                    softWrap = false,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Spacer(Modifier.width(8.dp))
                                Surface(
                                    color = Slate100,
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        "${group.appointments.size.toString().toStandardDigits()} طالب",
                                        color = Slate600,
                                        style = MaterialTheme.typography.labelSmall,
                                        maxLines = 1,
                                        softWrap = false,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Spacer(Modifier.height(4.dp))
                            Text(
                                "تاريخ تصميم المجموعة: ${group.day} ${group.dateStr}".trim(),
                                style = MaterialTheme.typography.labelSmall,
                                color = Slate500,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(Modifier.height(4.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(
                                    "رشيدي: ${rashidiCount.toString().toStandardDigits()}",
                                    color = Emerald600,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    softWrap = false
                                )
                                Text(
                                    "تلاوة: ${tilawaCount.toString().toStandardDigits()}",
                                    color = Brand600,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    softWrap = false
                                )
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                            IconButton(
                                onClick = {
                                    viewModel.generatePdf(context, mosque, MosqueViewModel.Tab.EXAM_SCHEDULE.name, examGroupId = group.id)
                                },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(Icons.Outlined.PictureAsPdf, contentDescription = "PDF", tint = Rose500, modifier = Modifier.size(18.dp))
                            }
                            IconButton(
                                onClick = {
                                    viewModel.shareAsImage(context, mosque, MosqueViewModel.Tab.EXAM_SCHEDULE.name, targetPackage = null, examGroupId = group.id)
                                },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(Icons.Outlined.Image, contentDescription = "صورة", tint = Brand600, modifier = Modifier.size(18.dp))
                            }
                            IconButton(
                                onClick = {
                                    viewModel.shareWhatsApp(context, mosque, MosqueViewModel.Tab.EXAM_SCHEDULE.name, examGroupId = group.id)
                                },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(Icons.Outlined.Share, contentDescription = "واتساب", tint = Emerald600, modifier = Modifier.size(18.dp))
                            }
                            IconButton(
                                onClick = { groupToDelete = group },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(Icons.Outlined.DeleteOutline, contentDescription = "حذف المجموعة", tint = Rose500, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * محرر مجموعة المواعيد:
 * - أزرار الحفظ والمشاركة و PDF والصورة وإضافة الطلاب في الأعلى مثل تبويب الجزء تماماً
 * - إضافة طلاب بالتحديد المتعدد دفعة واحدة
 * - تخصيص سريع لكل طالب في بطاقته مباشرة (القسم، الأجزاء/الرشيدي، تاريخ وموعد الاختبار الذي يملأ تلقائياً بـ "لم يحدد" عند تركه فارغاً)
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ExamGroupEditor(
    viewModel: MosqueViewModel,
    mosque: Mosque,
    group: ExamScheduleGroup
) {
    val context = LocalContext.current
    var appointmentsList by remember(group.id, group.appointments) {
        mutableStateOf(
            group.appointments.map {
                if (it.appointmentDate.isBlank()) it.copy(appointmentDate = "لم يحدد") else it
            }
        )
    }

    var showMultiAddDialog by remember { mutableStateOf(false) }
    var showClearConfirm by remember { mutableStateOf(false) }
    var partPickerIndex by remember { mutableStateOf<Int?>(null) }
    var selectedSectionFilter by remember { mutableStateOf("الكل") }
    var searchQuery by remember { mutableStateOf("") }
    var hasUnsavedChanges by remember { mutableStateOf(false) }

    val todayFormatted = remember {
        val day = SimpleDateFormat("EEEE", Locale("ar", "EG")).format(Date())
        val dateStr = SimpleDateFormat("dd/MM/yyyy", Locale.US).format(Date()).toStandardDigits()
        "$day $dateStr"
    }

    fun persistAppointments(newList: List<ExamAppointment>, showToast: Boolean = false) {
        val normalized = newList.map { a ->
            a.copy(
                appointmentDate = if (a.appointmentDate.isBlank()) "لم يحدد" else a.appointmentDate.trim(),
                groupId = group.id,
                groupTitle = group.title,
                groupDateStr = group.dateStr
            )
        }
        appointmentsList = normalized
        hasUnsavedChanges = false
        viewModel.updateExamGroupAppointments(group.id, normalized)
        if (showToast) {
            viewModel.flushSaveNow()
            Toast.makeText(context, "تم حفظ مجموعة المواعيد بتاريخ (${group.day} ${group.dateStr}) بنجاح ✓", Toast.LENGTH_SHORT).show()
        }
    }

    // عند فتح مجموعة جديدة فارغة لأول مرة، نفتح نافذة التحديد المتعدد للطلاب لتسهيل الإدخال الفوري
    var autoOpenedOnce by remember(group.id) { mutableStateOf(false) }
    LaunchedEffect(group.id) {
        if (!autoOpenedOnce && appointmentsList.isEmpty() && mosque.scopedStudents.isNotEmpty()) {
            autoOpenedOnce = true
            showMultiAddDialog = true
        }
    }

    // منتقي الأجزاء (1..30) لطالب محدد
    if (partPickerIndex != null && partPickerIndex in appointmentsList.indices) {
        val idx = partPickerIndex!!
        val currentAppt = appointmentsList[idx]
        MultiPartPickerDialog(
            studentName = currentAppt.studentName,
            initialParts = currentAppt.safeJuzNumbers,
            onDismiss = { partPickerIndex = null },
            onConfirm = { selectedParts ->
                val updated = appointmentsList.toMutableList()
                updated[idx] = currentAppt.copy(juzNumbers = selectedParts.sorted())
                persistAppointments(updated)
                partPickerIndex = null
            }
        )
    }

    // تأكيد مسح أسماء المجموعة
    if (showClearConfirm) {
        AlertDialog(
            onDismissRequest = { showClearConfirm = false },
            shape = RoundedCornerShape(16.dp),
            containerColor = Color.White,
            title = { Text("مسح قائمة الطلاب في المجموعة", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) },
            text = { Text("هل أنت متأكد من مسح جميع مواعيد الطلاب في هذه المجموعة؟", style = MaterialTheme.typography.bodyMedium) },
            confirmButton = {
                Button(
                    onClick = {
                        persistAppointments(emptyList())
                        showClearConfirm = false
                        Toast.makeText(context, "تم مسح القائمة", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Rose500),
                    shape = RoundedCornerShape(8.dp)
                ) { Text("نعم، مسح") }
            },
            dismissButton = {
                TextButton(onClick = { showClearConfirm = false }) { Text("إلغاء", color = Slate500) }
            }
        )
    }

    // نافذة التحديد المتعدد السريع لإضافة الطلاب إلى المجموعة (مثل تبويب الجزء تماماً!)
    if (showMultiAddDialog) {
        AddStudentsToExamGroupDialog(
            mosque = mosque,
            currentAppointments = appointmentsList,
            group = group,
            onDismiss = { showMultiAddDialog = false },
            onAdd = { newAppointments ->
                persistAppointments(appointmentsList + newAppointments)
                showMultiAddDialog = false
                Toast.makeText(
                    context,
                    "تمت إضافة ${newAppointments.size.toString().toStandardDigits()} طالب للمجموعة؛ يمكنك الآن تخصيص بيانات كل طالب",
                    Toast.LENGTH_SHORT
                ).show()
            }
        )
    }

    val rashidiCount = appointmentsList.count { it.section == "رشيدي" }
    val tilawaCount = appointmentsList.count { it.section != "رشيدي" }

    val filteredAppointments = remember(appointmentsList, selectedSectionFilter, searchQuery) {
        appointmentsList.mapIndexed { idx, appt -> idx to appt }.filter { (_, appt) ->
            val matchesSection = when (selectedSectionFilter) {
                "رشيدي" -> appt.section == "رشيدي"
                "تلاوة" -> appt.section != "رشيدي"
                else -> true
            }
            val matchesQuery = searchQuery.isBlank() ||
                appt.studentName.contains(searchQuery, ignoreCase = true) ||
                appt.safeAppointmentDate.contains(searchQuery, ignoreCase = true)
            matchesSection && matchesQuery
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(bottom = 28.dp)
    ) {
        // 1. بطاقة الرأس والأزرار في الأعلى مثل تبويب الجزء (السجل) تماماً
        item(key = "exam_group_top_card", contentType = "header") {
            UnifiedTopActionCard(
                title = "مجموعة مواعيد الاختبار",
                subtitle = "تاريخ التصميم: ${group.day} ${group.dateStr}",
                icon = Icons.Filled.EventAvailable,
                onBackClick = {
                    persistAppointments(appointmentsList)
                    viewModel.closeExamGroup()
                },
                onSaveClick = {
                    persistAppointments(appointmentsList, showToast = true)
                },
                saveButtonText = if (hasUnsavedChanges) "حفظ التعديل" else "حفظ",
                hasUnsavedChanges = hasUnsavedChanges,
                primaryActionText = "إضافة طلاب",
                primaryActionIcon = Icons.Filled.GroupAdd,
                onPrimaryActionClick = { showMultiAddDialog = true },
                onWhatsAppClick = {
                    persistAppointments(appointmentsList)
                    viewModel.shareWhatsApp(context, mosque, MosqueViewModel.Tab.EXAM_SCHEDULE.name, examGroupId = group.id)
                },
                onPdfClick = {
                    persistAppointments(appointmentsList)
                    viewModel.generatePdf(context, mosque, MosqueViewModel.Tab.EXAM_SCHEDULE.name, examGroupId = group.id)
                },
                onImageClick = {
                    persistAppointments(appointmentsList)
                    viewModel.shareAsImage(context, mosque, MosqueViewModel.Tab.EXAM_SCHEDULE.name, targetPackage = null, examGroupId = group.id)
                },
                onClearClick = if (appointmentsList.isNotEmpty()) ({ showClearConfirm = true }) else null
            )
        }

        // 2. فلاتر الأقسام والبحث
        if (appointmentsList.isNotEmpty()) {
            item(key = "exam_group_filters", contentType = "filters") {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        FilterChip(
                            selected = selectedSectionFilter == "الكل",
                            onClick = { selectedSectionFilter = "الكل" },
                            label = {
                                Text(
                                    "الكل (${appointmentsList.size.toString().toStandardDigits()})",
                                    fontWeight = if (selectedSectionFilter == "الكل") FontWeight.Bold else FontWeight.Normal,
                                    maxLines = 1,
                                    softWrap = false
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                selectedLabelColor = MaterialTheme.colorScheme.primary
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(0.9f)
                        )

                        FilterChip(
                            selected = selectedSectionFilter == "رشيدي",
                            onClick = { selectedSectionFilter = "رشيدي" },
                            leadingIcon = {
                                Icon(Icons.Filled.MenuBook, contentDescription = null, modifier = Modifier.size(15.dp))
                            },
                            label = {
                                Text(
                                    "رشيدي (${rashidiCount.toString().toStandardDigits()})",
                                    fontWeight = if (selectedSectionFilter == "رشيدي") FontWeight.Bold else FontWeight.Normal,
                                    maxLines = 1,
                                    softWrap = false
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Emerald100,
                                selectedLabelColor = Emerald600
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1.1f)
                        )

                        FilterChip(
                            selected = selectedSectionFilter == "تلاوة",
                            onClick = { selectedSectionFilter = "تلاوة" },
                            leadingIcon = {
                                Icon(Icons.Filled.AutoStories, contentDescription = null, modifier = Modifier.size(15.dp))
                            },
                            label = {
                                Text(
                                    "تلاوة (${tilawaCount.toString().toStandardDigits()})",
                                    fontWeight = if (selectedSectionFilter == "تلاوة") FontWeight.Bold else FontWeight.Normal,
                                    maxLines = 1,
                                    softWrap = false
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Brand100,
                                selectedLabelColor = Brand600
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1.1f)
                        )
                    }

                    if (appointmentsList.size > 3) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("بحث عن اسم طالب في المجموعة...", fontSize = 12.sp) },
                            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, tint = Slate400, modifier = Modifier.size(18.dp)) },
                            trailingIcon = {
                                if (searchQuery.isNotEmpty()) {
                                    IconButton(onClick = { searchQuery = "" }) {
                                        Icon(Icons.Filled.Close, contentDescription = "مسح", modifier = Modifier.size(16.dp))
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp),
                            singleLine = true
                        )
                    }
                }
            }
        }

        // 3. قائمة الطلاب وتخصيص كل طالب مباشرة
        if (appointmentsList.isEmpty()) {
            item(key = "exam_group_empty_students", contentType = "empty") {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 20.dp),
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(28.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = Slate100,
                            modifier = Modifier.size(56.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Filled.GroupAdd, contentDescription = null, tint = Slate400, modifier = Modifier.size(30.dp))
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        Text(
                            "المجموعة فارغة حالياً",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Slate800
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "اضغط على «إضافة طلاب» لتحديد الطلاب دفعة واحدة بالتحديد المتعدد، ثم خصّص لكل طالب قسمه وأجزاءه وموعد اختباره بسهولة.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Slate500,
                            textAlign = TextAlign.Center
                        )
                        Spacer(Modifier.height(14.dp))
                        Button(
                            onClick = { showMultiAddDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Filled.GroupAdd, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("إضافة طلاب بالتحديد المتعدد", maxLines = 1, softWrap = false)
                        }
                    }
                }
            }
        } else {
            itemsIndexed(
                filteredAppointments,
                key = { _, pair -> pair.second.id },
                contentType = { _, _ -> "exam_student_card" }
            ) { displayIdx, (originalIndex, appt) ->
                ExamStudentCustomizationCard(
                    index = displayIdx + 1,
                    appointment = appt,
                    todayFormatted = todayFormatted,
                    onUpdate = { updated ->
                        val mutable = appointmentsList.toMutableList()
                        mutable[originalIndex] = updated
                        persistAppointments(mutable)
                    },
                    onRemove = {
                        val mutable = appointmentsList.toMutableList()
                        mutable.removeAt(originalIndex)
                        persistAppointments(mutable)
                    },
                    onOpenPartPicker = {
                        partPickerIndex = originalIndex
                    }
                )
            }
        }
    }
}

/**
 * بطاقة تخصيص سريعة ومباشرة لكل طالب داخل مجموعة المواعيد:
 * تتيح تعديل القسم (رشيدي/تلاوة)، نوع الرشيدي أو أجزاء التلاوة، وتاريخ وموعد الاختبار (الذي يُملأ تلقائياً بـ "لم يحدد" عند تركه فارغاً)
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ExamStudentCustomizationCard(
    index: Int,
    appointment: ExamAppointment,
    todayFormatted: String,
    onUpdate: (ExamAppointment) -> Unit,
    onRemove: () -> Unit,
    onOpenPartPicker: () -> Unit
) {
    val isRashidi = appointment.section == "رشيدي"
    var localDateInput by remember(appointment.id, appointment.appointmentDate) {
        mutableStateOf(if (appointment.appointmentDate == "لم يحدد") "" else appointment.appointmentDate)
    }
    var localNotesInput by remember(appointment.id, appointment.notes) {
        mutableStateOf(appointment.notes)
    }

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // 1. الرقم + اسم الطالب + اختيار القسم السريع + حذف
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f).padding(end = 6.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = if (isRashidi) Emerald50 else Brand50,
                        modifier = Modifier.size(26.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                index.toString().toStandardDigits(),
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = if (isRashidi) Emerald600 else Brand600,
                                maxLines = 1,
                                softWrap = false
                            )
                        }
                    }
                    Spacer(Modifier.width(8.dp))
                    Text(
                        appointment.studentName,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Slate900,
                        maxLines = 1,
                        softWrap = false,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                // تبديل القسم بضغطة واحدة (رشيدي / تلاوة)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    LightChip(
                        selected = isRashidi,
                        text = "رشيدي",
                        selectedColor = Emerald600,
                        onClick = { if (!isRashidi) onUpdate(appointment.copy(section = "رشيدي")) }
                    )
                    LightChip(
                        selected = !isRashidi,
                        text = "تلاوة",
                        selectedColor = Brand600,
                        onClick = { if (isRashidi) onUpdate(appointment.copy(section = "تلاوة")) }
                    )
                    IconButton(
                        onClick = onRemove,
                        modifier = Modifier.size(26.dp)
                    ) {
                        Icon(
                            Icons.Outlined.Close,
                            contentDescription = "إزالة",
                            tint = Slate400,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            // 2. تخصيص تفاصيل الاختبار حسب القسم (رشيدي أو أجزاء التلاوة)
            if (isRashidi) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Emerald50.copy(alpha = 0.6f),
                    border = BorderStroke(1.dp, Emerald200),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(
                            "تحديد نوع اختبار الرشيدي:",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = Emerald800
                        )
                        Spacer(Modifier.height(6.dp))
                        val rashidiOptions = listOf("رشيدي نهائي", "أول + نهائي", "رشيدي قسم أول")
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            rashidiOptions.forEach { opt ->
                                val isSelected = appointment.safeRashidiType == opt
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (isSelected) Emerald500 else Color.White,
                                    border = BorderStroke(1.dp, if (isSelected) Emerald500 else Emerald200),
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable { onUpdate(appointment.copy(rashidiType = opt)) }
                                ) {
                                    Box(
                                        modifier = Modifier.padding(vertical = 6.dp, horizontal = 4.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            opt,
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                            color = if (isSelected) Color.White else Emerald800,
                                            maxLines = 1,
                                            softWrap = false
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                val parts = appointment.safeJuzNumbers
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Brand50.copy(alpha = 0.5f),
                    border = BorderStroke(1.dp, Brand200),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "الأجزاء المحددة (${parts.size.toString().toStandardDigits()}):",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = Brand900,
                                maxLines = 1,
                                softWrap = false
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                val maxPart = parts.maxOrNull() ?: 0
                                if (maxPart in 1..29 && (maxPart + 1) !in parts) {
                                    FilledTonalButton(
                                        onClick = {
                                            onUpdate(appointment.copy(juzNumbers = (parts + (maxPart + 1)).sorted()))
                                        },
                                        shape = RoundedCornerShape(6.dp),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                        modifier = Modifier.height(26.dp)
                                    ) {
                                        Text("+ الجزء ${(maxPart + 1).toString().toStandardDigits()}", fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                                    }
                                }
                                FilledTonalButton(
                                    onClick = onOpenPartPicker,
                                    shape = RoundedCornerShape(6.dp),
                                    colors = ButtonDefaults.filledTonalButtonColors(
                                        containerColor = MaterialTheme.colorScheme.primaryContainer,
                                        contentColor = MaterialTheme.colorScheme.primary
                                    ),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    modifier = Modifier.height(26.dp)
                                ) {
                                    Icon(Icons.Filled.Edit, contentDescription = null, modifier = Modifier.size(12.dp))
                                    Spacer(Modifier.width(3.dp))
                                    Text("تحديد الأجزاء", fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                                }
                            }
                        }

                        Spacer(Modifier.height(6.dp))

                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(5.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            parts.forEach { partNum ->
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = Brand600,
                                    modifier = Modifier.clickable { onOpenPartPicker() }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            "الجزء ${partNum.toString().toStandardDigits()}",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White,
                                            maxLines = 1,
                                            softWrap = false
                                        )
                                        if (parts.size > 1) {
                                            Spacer(Modifier.width(4.dp))
                                            Icon(
                                                Icons.Filled.Close,
                                                contentDescription = "حذف الجزء",
                                                tint = Color.White.copy(alpha = 0.85f),
                                                modifier = Modifier
                                                    .size(13.dp)
                                                    .clickable {
                                                        onUpdate(appointment.copy(juzNumbers = parts.filter { it != partNum }))
                                                    }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 3. تاريخ وموعد الاختبار (عند تركها فارغة تملأ تلقائياً بكلمة "لم يحدد")
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.Event, contentDescription = null, tint = Slate600, modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(
                            "تاريخ وموعد الاختبار:",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = Slate700,
                            maxLines = 1,
                            softWrap = false
                        )
                    }
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = if (appointment.safeAppointmentDate == "لم يحدد") Amber50 else Emerald50,
                        border = BorderStroke(0.5.dp, if (appointment.safeAppointmentDate == "لم يحدد") Amber300 else Emerald300)
                    ) {
                        Text(
                            "الموعد الحالي: ${appointment.safeAppointmentDate}",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = if (appointment.safeAppointmentDate == "لم يحدد") Amber800 else Emerald700,
                            fontSize = 10.sp,
                            maxLines = 1,
                            softWrap = false,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                // أزرار سريعة لتحديد موعد الاختبار أو تركه "لم يحدد"
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    val quickDates = listOf(
                        "لم يحدد" to "لم يحدد",
                        "اليوم" to todayFormatted,
                        "السبت" to "السبت القادم",
                        "الخميس" to "الخميس القادم"
                    )
                    quickDates.forEach { (label, valStr) ->
                        val isSelected = appointment.safeAppointmentDate == valStr
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = if (isSelected) Brand600 else Slate100,
                            modifier = Modifier
                                .weight(1f)
                                .clickable {
                                    localDateInput = if (valStr == "لم يحدد") "" else valStr
                                    onUpdate(appointment.copy(appointmentDate = valStr))
                                }
                        ) {
                            Box(
                                modifier = Modifier.padding(vertical = 5.dp, horizontal = 4.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    label,
                                    fontSize = 10.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isSelected) Color.White else Slate700,
                                    maxLines = 1,
                                    softWrap = false
                                )
                            }
                        }
                    }
                }

                // حقل كتابة التاريخ والموعد (إذا تُرك فارغاً يُملأ تلقائياً بكلمة "لم يحدد")
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    LightTextField(
                        value = localDateInput,
                        onValueChange = { text ->
                            val clean = text.toStandardDigits()
                            localDateInput = clean
                            val effective = if (clean.isBlank()) "لم يحدد" else clean.trim()
                            onUpdate(appointment.copy(appointmentDate = effective))
                        },
                        placeholder = "تاريخ وموعد الاختبار (فارغ = لم يحدد)...",
                        modifier = Modifier.weight(1.3f)
                    )

                    LightTextField(
                        value = localNotesInput,
                        onValueChange = { text ->
                            localNotesInput = text
                            onUpdate(appointment.copy(notes = text))
                        },
                        placeholder = "ملاحظة (اختياري)...",
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // 4. شريط حالة الموعد والبيان النهائي
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "البيان: ${appointment.displayDetails} • الموعد: ${appointment.safeAppointmentDate}",
                    style = MaterialTheme.typography.labelSmall,
                    color = Slate600,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f).padding(end = 6.dp)
                )

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    listOf("مجدول", "تم الاختبار", "مؤجل").forEach { st ->
                        val isSelected = appointment.status == st
                        val chipColor = when (st) {
                            "تم الاختبار" -> Emerald600
                            "مؤجل" -> Rose500
                            else -> Amber600
                        }
                        LightChip(
                            selected = isSelected,
                            text = st,
                            selectedColor = chipColor,
                            onClick = { if (!isSelected) onUpdate(appointment.copy(status = st)) }
                        )
                    }
                }
            }
        }
    }
}

/**
 * نافذة إضافة الطلاب بالتحديد المتعدد إلى مجموعة المواعيد (سريعة وسهلة مثل تبويب الجزء + خيار إضافة اسم يدوي)
 */
@Composable
private fun AddStudentsToExamGroupDialog(
    mosque: Mosque,
    currentAppointments: List<ExamAppointment>,
    group: ExamScheduleGroup,
    onDismiss: () -> Unit,
    onAdd: (List<ExamAppointment>) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var customStudentName by remember { mutableStateOf("") }
    val scopedStudents = remember(mosque.students, mosque.name) { mosque.scopedStudents }
    val alreadyAddedIds = remember(currentAppointments) { currentAppointments.map { it.studentId }.toSet() }
    var selectedIds by remember { mutableStateOf(setOf<String>()) }

    val filteredStudents = remember(scopedStudents, searchQuery) {
        if (searchQuery.isBlank()) scopedStudents
        else scopedStudents.filter { it.fullName.contains(searchQuery, ignoreCase = true) }
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp,
            modifier = Modifier
                .fillMaxWidth()
                .padding(4.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    "إضافة طلاب لمجموعة المواعيد",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    "حدد عدة طلاب دفعة واحدة، وبعد الإضافة يمكنك تعديل وتخصيص معلومات كل طالب على حدة",
                    style = MaterialTheme.typography.bodySmall,
                    color = Slate500,
                    modifier = Modifier.padding(top = 2.dp, bottom = 10.dp)
                )

                // البحث
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("بحث عن اسم طالب...", fontSize = 13.sp) },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, tint = Slate400, modifier = Modifier.size(18.dp)) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    singleLine = true
                )

                Spacer(Modifier.height(6.dp))

                // تحديد الكل / إلغاء تحديد الكل
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val eligibleCount = filteredStudents.count { it.id !in alreadyAddedIds }
                    val allEligibleSelected = eligibleCount > 0 && filteredStudents.filter { it.id !in alreadyAddedIds }.all { it.id in selectedIds }

                    TextButton(
                        onClick = {
                            selectedIds = if (allEligibleSelected) {
                                emptySet()
                            } else {
                                filteredStudents.filter { it.id !in alreadyAddedIds }.map { it.id }.toSet()
                            }
                        },
                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 2.dp)
                    ) {
                        Icon(
                            if (allEligibleSelected) Icons.Filled.CheckBox else Icons.Filled.CheckBoxOutlineBlank,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp),
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(
                            if (allEligibleSelected) "إلغاء تحديد الكل" else "تحديد الكل (${eligibleCount.toString().toStandardDigits()})",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            softWrap = false
                        )
                    }

                    Text(
                        "المحدد: ${selectedIds.size.toString().toStandardDigits()}",
                        style = MaterialTheme.typography.labelSmall,
                        color = Slate500,
                        maxLines = 1,
                        softWrap = false
                    )
                }

                Spacer(Modifier.height(4.dp))

                // قائمة الطلاب للتحديد المتعدد
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 260.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(filteredStudents, key = { it.id }) { student ->
                        val isAlreadyAdded = student.id in alreadyAddedIds
                        val isChecked = student.id in selectedIds
                        val deptInfo = getDepartmentUiInfo(student.safeDepartment)

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isChecked) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f) else if (isAlreadyAdded) Slate50 else Color.Transparent,
                            border = BorderStroke(0.5.dp, if (isChecked) MaterialTheme.colorScheme.primary.copy(alpha = 0.5f) else Slate200),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable(enabled = !isAlreadyAdded) {
                                    selectedIds = if (isChecked) selectedIds - student.id else selectedIds + student.id
                                }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 10.dp, vertical = 7.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = isChecked,
                                    onCheckedChange = { checked ->
                                        selectedIds = if (checked) selectedIds + student.id else selectedIds - student.id
                                    },
                                    enabled = !isAlreadyAdded,
                                    modifier = Modifier.size(22.dp)
                                )
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    student.fullName,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = if (isChecked) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isAlreadyAdded) Slate400 else Slate900,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f)
                                )
                                if (isAlreadyAdded) {
                                    Surface(shape = RoundedCornerShape(6.dp), color = Slate200) {
                                        Text(
                                            "مضاف",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Slate600,
                                            maxLines = 1,
                                            softWrap = false,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                } else {
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = deptInfo.containerColor,
                                        border = BorderStroke(0.5.dp, deptInfo.borderColor)
                                    ) {
                                        Text(
                                            student.safeDepartment.replace("قسم ", ""),
                                            fontSize = 9.5.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = deptInfo.textColor,
                                            maxLines = 1,
                                            softWrap = false,
                                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(Modifier.height(8.dp))

                // خيار إضافة اسم يدوي سريع إن لم يكن في القائمة
                OutlinedTextField(
                    value = customStudentName,
                    onValueChange = { customStudentName = it },
                    placeholder = { Text("أو اكتب اسم طالب جديد مباشرة (اختياري)...", fontSize = 12.sp) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    singleLine = true
                )

                Spacer(Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    TextButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("إلغاء", color = Slate600)
                    }

                    Button(
                        onClick = {
                            val listToAdd = mutableListOf<ExamAppointment>()
                            selectedIds.forEach { sId ->
                                val student = scopedStudents.find { it.id == sId }
                                if (student != null) {
                                    val defaultSec = if (student.safeDepartment.contains("رشيدي")) "رشيدي" else "تلاوة"
                                    listToAdd.add(
                                        ExamAppointment(
                                            id = "_" + UUID.randomUUID().toString().substring(0, 9),
                                            studentId = student.id,
                                            studentName = student.fullName,
                                            section = defaultSec,
                                            rashidiType = "رشيدي نهائي",
                                            juzNumbers = listOf(1),
                                            appointmentDate = "لم يحدد", // يملأ تلقائياً بـ "لم يحدد"
                                            notes = "",
                                            status = "مجدول",
                                            createdAt = System.currentTimeMillis(),
                                            groupId = group.id,
                                            groupTitle = group.title,
                                            groupDateStr = group.dateStr
                                        )
                                    )
                                }
                            }
                            if (customStudentName.isNotBlank()) {
                                listToAdd.add(
                                    ExamAppointment(
                                        id = "_" + UUID.randomUUID().toString().substring(0, 9),
                                        studentId = "_" + UUID.randomUUID().toString().substring(0, 9),
                                        studentName = customStudentName.trim(),
                                        section = "تلاوة",
                                        rashidiType = "رشيدي نهائي",
                                        juzNumbers = listOf(1),
                                        appointmentDate = "لم يحدد",
                                        notes = "",
                                        status = "مجدول",
                                        createdAt = System.currentTimeMillis(),
                                        groupId = group.id,
                                        groupTitle = group.title,
                                        groupDateStr = group.dateStr
                                    )
                                )
                            }
                            onAdd(listToAdd)
                        },
                        enabled = selectedIds.isNotEmpty() || customStudentName.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1.5f)
                    ) {
                        val totalCount = selectedIds.size + (if (customStudentName.isNotBlank()) 1 else 0)
                        Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("إضافة وتخصيص (${totalCount.toString().toStandardDigits()})", maxLines = 1, softWrap = false)
                    }
                }
            }
        }
    }
}
