package com.example.ui

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import com.example.data.Mosque
import com.example.data.StudentDepartments
import com.example.data.Test
import com.example.data.TestRecord
import com.example.ui.theme.*
import com.example.utils.toStandardDigits

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TestsTab(viewModel: MosqueViewModel, mosque: Mosque, openedTestId: String? = null) {
    val context = LocalContext.current
    var testToDelete by remember { mutableStateOf<String?>(null) }
    var searchQuery by remember { mutableStateOf("") }
    var showNewTestDialog by remember { mutableStateOf(false) }

    val scopedStudents = remember(mosque.students, mosque.name) { mosque.scopedStudents }

    if (showNewTestDialog) {
        NewTestSectionSelectionDialog(
            mosque = mosque,
            onDismiss = { showNewTestDialog = false },
            onConfirm = { selectedSections ->
                showNewTestDialog = false
                viewModel.createNewTestWithSections(
                    selectedSections = selectedSections.toList(),
                    onNoStudents = {
                        Toast.makeText(context, "لا يوجد طلبة في الأقسام المحددة.", Toast.LENGTH_SHORT).show()
                    }
                )
            }
        )
    }

    if (testToDelete != null) {
        AlertDialog(
            onDismissRequest = { testToDelete = null },
            shape = RoundedCornerShape(16.dp),
            containerColor = Color.White,
            title = { Text("حذف الاختبار", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) },
            text = { Text("هل أنت متأكد من حذف هذا الاختبار وسجلات درجات الطلاب المرتبطة به نهائياً؟", style = MaterialTheme.typography.bodyMedium) },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteTest(testToDelete!!)
                        testToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Rose500),
                    shape = RoundedCornerShape(8.dp)
                ) { Text("نعم، حذف") }
            },
            dismissButton = {
                TextButton(onClick = { testToDelete = null }) { Text("إلغاء", color = Slate500) }
            }
        )
    }

    if (openedTestId != null) {
        val test = mosque.tests.find { it.id == openedTestId }
        if (test != null) {
            TestEditor(viewModel = viewModel, mosque = mosque, test = test)
            return
        }
    }

    val filteredTests = remember(mosque.tests, searchQuery) {
        mosque.tests.reversed().filter { test ->
            val day = test.displayDay
            val date = test.displayDate
            val title = test.title ?: ""
            day.contains(searchQuery, ignoreCase = true) ||
                date.contains(searchQuery) ||
                title.contains(searchQuery, ignoreCase = true)
        }
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        item(key = "tests_header", contentType = "header") {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                        Text(
                            "سجل الاختبارات والتقييمات",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Slate900,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            "${mosque.tests.size.toString().toStandardDigits()} اختبار مسجل",
                            style = MaterialTheme.typography.labelSmall,
                            color = Slate500,
                            maxLines = 1,
                            softWrap = false
                        )
                    }
                    Button(
                        onClick = {
                            if (scopedStudents.isEmpty()) {
                                Toast.makeText(context, "لا يوجد طلبة في المسجد. أضف طلبة أولاً من قسم الطلبة.", Toast.LENGTH_LONG).show()
                            } else {
                                showNewTestDialog = true
                            }
                        },
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Brand600)
                    ) {
                        Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("اختبار جديد", style = MaterialTheme.typography.labelLarge, maxLines = 1, softWrap = false)
                    }
                }
            }
        }

        if (mosque.tests.size > 1) {
            item(key = "tests_search", contentType = "search") {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("بحث باليوم أو التاريخ أو اسم الاختبار...", style = MaterialTheme.typography.bodySmall, color = Slate400) },
                    singleLine = true,
                    leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null, tint = Slate400, modifier = Modifier.size(18.dp)) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Outlined.Clear, contentDescription = "مسح", tint = Slate400, modifier = Modifier.size(16.dp))
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    textStyle = MaterialTheme.typography.bodyMedium.copy(textAlign = TextAlign.Right)
                )
            }
        }

        if (mosque.tests.isEmpty()) {
            item(key = "tests_empty", contentType = "empty") {
                Surface(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(
                        Modifier.fillMaxWidth().padding(36.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = Slate100,
                            modifier = Modifier.size(54.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Outlined.FactCheck, contentDescription = null, tint = Slate400, modifier = Modifier.size(28.dp))
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        Text("لا يوجد اختبارات مسجلة بعد", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, color = Slate700)
                        Spacer(Modifier.height(4.dp))
                        Text("اضغط على 'اختبار جديد' في الأعلى لإدراج الطلبة وتوثيق درجاتهم وسلوكهم", style = MaterialTheme.typography.bodySmall, color = Slate500, textAlign = TextAlign.Center)
                    }
                }
            }
        } else {
            items(filteredTests, key = { it.id }, contentType = { "test_row" }) { test ->
                val records = test.allRecords(mosque)
                val present = records.count { it.attendance == "حضور" }
                val excused = records.count { it.attendance == "إذن" }
                val absent = records.count { it.attendance == "غائب" }
                val fullMarks = records.count { (it.grade ?: "").contains("100") || (it.grade ?: "").contains("ممتاز") }

                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.openTest(test.id) },
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        // Left/Right content column with guaranteed horizontal text (fixes 73853.jpg vertical date bug!)
                        Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = test.displayDay,
                                    color = Brand700,
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.labelMedium,
                                    maxLines = 1,
                                    softWrap = false,
                                    modifier = Modifier
                                        .background(Brand50, RoundedCornerShape(6.dp))
                                        .padding(horizontal = 8.dp, vertical = 2.dp)
                                )
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    text = test.title?.ifBlank { "اختبار دوري" } ?: "اختبار دوري",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Slate900,
                                    maxLines = 1,
                                    softWrap = false,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }

                            Spacer(Modifier.height(4.dp))

                            // Date & Student Count on dedicated clean horizontal row
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                if (test.displayDate.isNotBlank()) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Outlined.CalendarToday, contentDescription = null, tint = Slate400, modifier = Modifier.size(12.dp))
                                        Spacer(Modifier.width(4.dp))
                                        Text(
                                            text = test.displayDate.toStandardDigits(),
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Slate600,
                                            fontWeight = FontWeight.Medium,
                                            maxLines = 1,
                                            softWrap = false
                                        )
                                    }
                                }
                                Surface(
                                    color = Slate100,
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        "${records.size.toString().toStandardDigits()} طالب",
                                        color = Slate600,
                                        style = MaterialTheme.typography.labelSmall,
                                        maxLines = 1,
                                        softWrap = false,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            Spacer(Modifier.height(6.dp))

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text("حضور: ${present.toString().toStandardDigits()}", color = Emerald600, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold, maxLines = 1, softWrap = false)
                                if (excused > 0) Text("إذن: ${excused.toString().toStandardDigits()}", color = Amber500, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold, maxLines = 1, softWrap = false)
                                if (absent > 0) Text("غائب: ${absent.toString().toStandardDigits()}", color = Rose500, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold, maxLines = 1, softWrap = false)
                                if (fullMarks > 0) {
                                    Text("💯 ممتاز: ${fullMarks.toString().toStandardDigits()}", color = Brand600, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                                }
                            }

                            if (test.safeSections.isNotEmpty()) {
                                Spacer(Modifier.height(6.dp))
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    test.safeSections.forEach { sec ->
                                        val info = getDepartmentUiInfo(sec)
                                        Surface(
                                            shape = RoundedCornerShape(4.dp),
                                            color = info.containerColor,
                                            border = BorderStroke(0.5.dp, info.borderColor)
                                        ) {
                                            Text(
                                                sec,
                                                style = MaterialTheme.typography.labelSmall,
                                                color = info.textColor,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 9.5.sp,
                                                maxLines = 1,
                                                softWrap = false,
                                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // Compact Action Icons
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                            IconButton(
                                onClick = { viewModel.generatePdf(context, mosque, "TESTS", null, test.id) },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(Icons.Outlined.PictureAsPdf, contentDescription = "PDF", tint = Rose500, modifier = Modifier.size(18.dp))
                            }
                            IconButton(
                                onClick = { viewModel.shareAsImage(context, mosque, "TESTS", null, test.id, null) },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(Icons.Outlined.Image, contentDescription = "صورة", tint = Brand600, modifier = Modifier.size(18.dp))
                            }
                            IconButton(
                                onClick = { viewModel.shareWhatsApp(context, mosque, "TESTS", null, test.id, null) },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(Icons.Outlined.Share, contentDescription = "واتساب", tint = Emerald600, modifier = Modifier.size(18.dp))
                            }
                            IconButton(
                                onClick = { testToDelete = test.id },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(Icons.Outlined.DeleteOutline, contentDescription = "حذف الاختبار", tint = Rose500, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TestEditor(viewModel: MosqueViewModel, mosque: Mosque, test: Test) {
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current
    var studentSearchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf("الكل") }

    val scopedStudents = remember(mosque.students, mosque.name) { mosque.scopedStudents }

    val initialRecords = remember(test.id, test.records.size) {
        val existing = test.allRecords(mosque)
        if (existing.isNotEmpty()) {
            existing
        } else {
            scopedStudents.map { s ->
                TestRecord(
                    studentId = s.id,
                    studentName = s.fullName,
                    attendance = "حضور",
                    behavior = "",
                    type = "تلاوة",
                    info = "",
                    grade = "",
                    studentDepartment = s.safeDepartment,
                    studentMosqueName = mosque.name
                )
            }
        }
    }

    var localRecords by remember(test.id, test.records.size) { mutableStateOf(initialRecords) }
    var testTitle by remember(test.id) { mutableStateOf(test.title ?: "اختبار دوري") }
    var hasUnsavedChanges by remember { mutableStateOf(false) }
    val coroutineScope = rememberCoroutineScope()
    var debounceSaveJob by remember { mutableStateOf<Job?>(null) }

    val saveRecordsState: (List<TestRecord>, Boolean) -> Unit = { updatedList, immediate ->
        localRecords = updatedList
        if (immediate) {
            focusManager.clearFocus()
            debounceSaveJob?.cancel()
            viewModel.updateAllTestRecords(test.id, updatedList)
            viewModel.flushSaveNow()
            hasUnsavedChanges = false
        } else {
            hasUnsavedChanges = true
            debounceSaveJob?.cancel()
            debounceSaveJob = coroutineScope.launch {
                delay(250)
                viewModel.updateAllTestRecords(test.id, updatedList)
            }
        }
    }

    val currentTestRecordsState = rememberUpdatedState(localRecords)
    DisposableEffect(test.id) {
        onDispose { viewModel.updateAllTestRecords(test.id, currentTestRecordsState.value) }
    }
    val onTestRecordUpdate: (TestRecord) -> Unit = remember(test.id) {
        { updatedRecord ->
            val updated = currentTestRecordsState.value.map {
                if (it.studentId == updatedRecord.studentId) updatedRecord else it
            }
            saveRecordsState(updated, false)
        }
    }

    val presentCount by remember { derivedStateOf { localRecords.count { it.attendance == "حضور" } } }
    val absentCount by remember { derivedStateOf { localRecords.count { it.attendance == "غائب" } } }
    val excusedCount by remember { derivedStateOf { localRecords.count { it.attendance == "إذن" } } }
    val fullMarksCount by remember { derivedStateOf { localRecords.count { (it.grade ?: "").contains("100") || (it.grade ?: "").contains("ممتاز") } } }
    val testedCount by remember { derivedStateOf { localRecords.count { it.attendance == "حضور" && !it.info.isNullOrBlank() } } }

    var showAddSectionDialog by remember { mutableStateOf(false) }
    var selectedDepartmentFilter by remember { mutableStateOf<String?>("الكل") }

    val presentDepartments by remember(test.sections, localRecords) {
        derivedStateOf {
            val list = mutableListOf<String>()
            (test.sections ?: emptyList()).forEach { sec ->
                if (sec.isNotBlank()) list.add(sec)
            }
            localRecords.forEach { r ->
                val d = r.studentDepartment?.takeIf { it.isNotBlank() }
                    ?: scopedStudents.find { it.id == r.studentId }?.safeDepartment
                if (d != null && d.isNotBlank() && !list.contains(d)) {
                    list.add(d)
                }
            }
            if (list.isEmpty()) StudentDepartments.ALL else list.distinct()
        }
    }

    if (showAddSectionDialog) {
        AddDepartmentToTestDialog(
            mosque = mosque,
            currentTestSections = presentDepartments,
            onDismiss = { showAddSectionDialog = false },
            onAddDepartment = { dept ->
                showAddSectionDialog = false
                viewModel.addSectionToTest(test.id, listOf(dept)) { count ->
                    if (count > 0) {
                        Toast.makeText(context, "تمت إضافة $count طالب من $dept للاختبار", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(context, "جميع طلاب $dept مضافون بالفعل", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        )
    }

    val filteredRecords by remember {
        derivedStateOf {
            localRecords.filter { record ->
                val matchesQuery = studentSearchQuery.isEmpty() || record.studentName.contains(studentSearchQuery, ignoreCase = true)
                val matchesFilter = when (selectedFilter) {
                    "لم يُختبر" -> record.attendance == "حضور" && record.info.isNullOrBlank()
                    "تم الاختبار" -> record.attendance == "حضور" && !record.info.isNullOrBlank()
                    "حضور" -> record.attendance == "حضور"
                    "غائب" -> record.attendance == "غائب"
                    "إذن" -> record.attendance == "إذن"
                    else -> true
                }
                val matchesDept = if (selectedDepartmentFilter == null || selectedDepartmentFilter == "الكل") true else {
                    val dept = record.studentDepartment?.takeIf { it.isNotBlank() }
                        ?: scopedStudents.find { it.id == record.studentId }?.safeDepartment ?: ""
                    dept == selectedDepartmentFilter
                }
                matchesQuery && matchesFilter && matchesDept
            }
        }
    }

    // التحميل التدريجي (Progressive Loading) لسلاسة التمرير
    val listState = rememberLazyListState()
    var visibleLimit by remember(selectedFilter, selectedDepartmentFilter, studentSearchQuery) { mutableStateOf(30) }
    val displayedRecords = remember(filteredRecords, visibleLimit) {
        filteredRecords.take(visibleLimit)
    }
    val shouldLoadMore by remember {
        derivedStateOf {
            val layoutInfo = listState.layoutInfo
            val totalItems = layoutInfo.totalItemsCount
            val lastVisible = layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
            totalItems > 0 && lastVisible >= totalItems - 6 && visibleLimit < filteredRecords.size
        }
    }
    LaunchedEffect(shouldLoadMore) {
        if (shouldLoadMore) {
            visibleLimit += 30
        }
    }

    LazyColumn(
        state = listState,
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // 1. الأزرار في الأعلى مثل صفحة الجزء (السجل) تماماً بدون أي كتابة عمودية!
        item(key = "test_top_action_card", contentType = "top_action_card") {
            UnifiedTopActionCard(
                title = "إجراء الاختبار والتقييم",
                subtitle = "${test.displayDay} - ${test.displayDate.toStandardDigits()}",
                icon = Icons.Filled.FactCheck,
                onBackClick = {
                    saveRecordsState(localRecords, true)
                    viewModel.closeTest()
                },
                onSaveClick = {
                    saveRecordsState(localRecords, true)
                    Toast.makeText(context, "تم حفظ بيانات الاختبار بنجاح ✓", Toast.LENGTH_SHORT).show()
                },
                saveButtonText = if (hasUnsavedChanges) "حفظ التعديل" else "حفظ",
                hasUnsavedChanges = hasUnsavedChanges,
                primaryActionText = "إضافة قسم",
                primaryActionIcon = Icons.Filled.GroupAdd,
                onPrimaryActionClick = { showAddSectionDialog = true },
                onWhatsAppClick = {
                    saveRecordsState(localRecords, true)
                    viewModel.shareWhatsApp(context, mosque, "TESTS", null, test.id, null)
                },
                onPdfClick = {
                    saveRecordsState(localRecords, true)
                    viewModel.generatePdf(context, mosque, "TESTS", null, test.id)
                },
                onImageClick = {
                    saveRecordsState(localRecords, true)
                    viewModel.shareAsImage(context, mosque, "TESTS", null, test.id, null)
                }
            )
        }

        // 2. العنوان وشريط الإحصائيات والفلترة
        item(key = "test_editor_header", contentType = "header") {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(Modifier.padding(12.dp)) {
                    // Test Title input
                    OutlinedTextField(
                        value = testTitle,
                        onValueChange = {
                            testTitle = it
                            viewModel.updateTestHeader(test.id, it, test.displayDay, test.displayDate)
                        },
                        label = { Text("عنوان / نوع الاختبار", style = MaterialTheme.typography.labelSmall) },
                        placeholder = { Text("مثال: اختبار دوري، اختبار تلاوة، اختبار نهاية جزء...", style = MaterialTheme.typography.bodySmall) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        textStyle = MaterialTheme.typography.bodyMedium.copy(textAlign = TextAlign.Right)
                    )

                    Spacer(Modifier.height(8.dp))

                    // Stats & Quick Summary
                    Surface(
                        color = Slate50,
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(0.5.dp, Slate200)
                    ) {
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("حضور: ${presentCount.toString().toStandardDigits()}", color = Emerald600, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                                Text("غياب: ${absentCount.toString().toStandardDigits()}", color = Rose500, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                                if (excusedCount > 0) Text("إذن: ${excusedCount.toString().toStandardDigits()}", color = Amber500, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                            }
                            Text("💯 ممتاز: ${fullMarksCount.toString().toStandardDigits()}", color = Brand700, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                        }
                    }

                    // Testing Progress Bar
                    val progressRatio = if (presentCount > 0) (testedCount.toFloat() / presentCount) else 0f
                    val progressPercent = Math.round(progressRatio * 100)
                    Spacer(Modifier.height(6.dp))
                    Surface(
                        color = Brand50.copy(alpha = 0.6f),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(0.5.dp, Brand200),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) {
                            Row(
                                Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Outlined.CheckCircle, contentDescription = null, tint = Emerald600, modifier = Modifier.size(15.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text(
                                        "إنجاز الاختبار: ${testedCount.toString().toStandardDigits()} من ${presentCount.toString().toStandardDigits()} طالباً",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = Brand900,
                                        maxLines = 1,
                                        softWrap = false
                                    )
                                }
                                Text("${progressPercent.toString().toStandardDigits()}%", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = Brand700, maxLines = 1, softWrap = false)
                            }
                            Spacer(Modifier.height(4.dp))
                            LinearProgressIndicator(
                                progress = { progressRatio },
                                modifier = Modifier.fillMaxWidth().height(4.dp),
                                color = Emerald600,
                                trackColor = Slate200,
                                strokeCap = androidx.compose.ui.graphics.StrokeCap.Round
                            )
                        }
                    }

                    Spacer(Modifier.height(8.dp))

                    // Attendance & Testing Filter Chips
                    LazyRow(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        val filterList = listOf("الكل", "لم يُختبر", "تم الاختبار", "حضور", "غائب", "إذن")
                        items(filterList) { filterOpt ->
                            val isSelected = selectedFilter == filterOpt
                            FilterChip(
                                selected = isSelected,
                                onClick = { selectedFilter = filterOpt },
                                label = { Text(filterOpt, style = MaterialTheme.typography.labelSmall, maxLines = 1, softWrap = false) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = if (filterOpt == "لم يُختبر") Amber500 else if (filterOpt == "تم الاختبار") Emerald600 else Brand600,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }

                    if (presentDepartments.size > 1) {
                        Spacer(Modifier.height(6.dp))
                        LazyRow(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            item {
                                FilterChip(
                                    selected = selectedDepartmentFilter == "الكل",
                                    onClick = { selectedDepartmentFilter = "الكل" },
                                    label = { Text("جميع الأقسام (${localRecords.size.toString().toStandardDigits()})", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = Brand600,
                                        selectedLabelColor = Color.White
                                    )
                                )
                            }
                            items(presentDepartments) { dept ->
                                val count = localRecords.count {
                                    val d = it.studentDepartment?.takeIf { s -> s.isNotBlank() }
                                        ?: scopedStudents.find { s -> s.id == it.studentId }?.safeDepartment ?: ""
                                    d == dept
                                }
                                val info = getDepartmentUiInfo(dept)
                                FilterChip(
                                    selected = selectedDepartmentFilter == dept,
                                    onClick = { selectedDepartmentFilter = dept },
                                    label = { Text("$dept (${count.toString().toStandardDigits()})", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false) },
                                    leadingIcon = {
                                        Icon(info.icon, contentDescription = null, tint = if (selectedDepartmentFilter == dept) info.textColor else Slate500, modifier = Modifier.size(13.dp))
                                    },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = info.containerColor,
                                        selectedLabelColor = info.textColor
                                    )
                                )
                            }
                        }
                    }

                    if (localRecords.size > 4) {
                        Spacer(Modifier.height(6.dp))
                        OutlinedTextField(
                            value = studentSearchQuery,
                            onValueChange = { studentSearchQuery = it },
                            placeholder = { Text("بحث عن طالب في هذا الاختبار...", style = MaterialTheme.typography.bodySmall, color = Slate400) },
                            singleLine = true,
                            leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null, tint = Slate400, modifier = Modifier.size(18.dp)) },
                            trailingIcon = {
                                if (studentSearchQuery.isNotEmpty()) {
                                    IconButton(onClick = { studentSearchQuery = "" }) {
                                        Icon(Icons.Outlined.Clear, contentDescription = "مسح", tint = Slate400, modifier = Modifier.size(16.dp))
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp),
                            textStyle = MaterialTheme.typography.bodyMedium.copy(textAlign = TextAlign.Right)
                        )
                    }
                }
            }
        }

        // Student Test Cards
        items(displayedRecords, key = { it.studentId }, contentType = { "test_record" }) { record ->
            TestRecordCard(
                record = record,
                onUpdate = onTestRecordUpdate
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TestRecordCard(
    record: TestRecord,
    onUpdate: (TestRecord) -> Unit
) {
    val isPresent = record.attendance == "حضور"
    val isAbsent = record.attendance == "غائب"
    val isExcused = record.attendance == "إذن"

    var localInfo by remember(record.studentId, record.info) {
        mutableStateOf(record.info ?: "")
    }

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        color = when {
            isPresent -> Color.White
            isAbsent -> Rose50.copy(alpha = 0.5f)
            else -> Amber50.copy(alpha = 0.5f)
        },
        border = BorderStroke(
            1.dp,
            when {
                isPresent -> Slate200
                isAbsent -> Rose500.copy(alpha = 0.4f)
                else -> Amber500.copy(alpha = 0.4f)
            }
        )
    ) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            // Row 1: Student Name (strictly horizontal, no vertical mosque name wrapping!) & Attendance Selectors
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .weight(1f)
                        .padding(end = 6.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = Brand50,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Outlined.Person, contentDescription = null, tint = Brand600, modifier = Modifier.size(16.dp))
                        }
                    }
                    Spacer(Modifier.width(8.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            record.studentName,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium,
                            color = Slate900,
                            maxLines = 1,
                            softWrap = false,
                            overflow = TextOverflow.Ellipsis
                        )
                        val dept = record.studentDepartment?.takeIf { it.isNotBlank() } ?: ""
                        if (dept.isNotBlank()) {
                            val info = getDepartmentUiInfo(dept)
                            Spacer(Modifier.height(2.dp))
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = info.containerColor,
                                border = BorderStroke(0.5.dp, info.borderColor)
                            ) {
                                Text(
                                    dept,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = info.textColor,
                                    fontSize = 9.5.sp,
                                    maxLines = 1,
                                    softWrap = false,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.dp)
                                )
                            }
                        }
                    }
                }

                // Attendance Chips
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    LightChip(
                        selected = isPresent,
                        text = "حضور",
                        selectedColor = Emerald600,
                        onClick = { onUpdate(record.copy(attendance = "حضور")) }
                    )
                    LightChip(
                        selected = isAbsent,
                        text = "غياب",
                        selectedColor = Rose500,
                        onClick = {
                            localInfo = ""
                            onUpdate(
                                record.copy(
                                    attendance = "غائب",
                                    type = "",
                                    info = "",
                                    grade = "",
                                    behavior = ""
                                )
                            )
                        }
                    )
                    LightChip(
                        selected = isExcused,
                        text = "إذن",
                        selectedColor = Amber500,
                        onClick = {
                            localInfo = ""
                            onUpdate(
                                record.copy(
                                    attendance = "إذن",
                                    type = "",
                                    info = "",
                                    grade = "",
                                    behavior = ""
                                )
                            )
                        }
                    )
                }
            }

            if (isPresent) {
                HorizontalDivider(color = Slate100, thickness = 0.5.dp)

                // Row 2: Curriculum Type & Info / Page
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    var typeExpanded by remember { mutableStateOf(false) }
                    val currentType = if (record.type.isNullOrBlank()) "-" else record.type
                    val isTypeSelected = currentType != "-"

                    Box(modifier = Modifier.weight(1.1f)) {
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { typeExpanded = true },
                            shape = RoundedCornerShape(8.dp),
                            color = Slate50,
                            border = BorderStroke(1.dp, if (isTypeSelected) Brand300 else Slate300)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 7.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    currentType,
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = if (isTypeSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isTypeSelected) Brand700 else Slate500,
                                    maxLines = 1,
                                    softWrap = false,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Icon(Icons.Filled.ArrowDropDown, contentDescription = null, tint = Slate500, modifier = Modifier.size(18.dp))
                            }
                        }

                        if (typeExpanded) {
                            DropdownMenu(
                                expanded = typeExpanded,
                                onDismissRequest = { typeExpanded = false },
                                modifier = Modifier.background(Color.White)
                            ) {
                                listOf("تلاوة", "رشيدي", "قرآن غيباً", "تجويد").forEach { t ->
                                    DropdownMenuItem(
                                        text = { Text(t, style = MaterialTheme.typography.bodyMedium) },
                                        onClick = {
                                            onUpdate(record.copy(type = t))
                                            typeExpanded = false
                                        }
                                    )
                                }
                                if (isTypeSelected) {
                                    HorizontalDivider(color = Slate200)
                                    DropdownMenuItem(
                                        text = { Text("إلغاء التحديد (-)", style = MaterialTheme.typography.bodySmall, color = Slate500) },
                                        onClick = {
                                            onUpdate(record.copy(type = ""))
                                            typeExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    // Info / Surah / Page text
                    LightTextField(
                        value = localInfo,
                        onValueChange = { newVal ->
                            val clean = newVal.toStandardDigits()
                            localInfo = clean
                            onUpdate(record.copy(info = clean))
                        },
                        placeholder = "المقطع / السورة / الصفحة...",
                        modifier = Modifier.weight(1.9f)
                    )
                }

                // Row 3: Grade Selector & Behavior Toggle
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    var gradeExpanded by remember { mutableStateOf(false) }
                    val currentGrade = if (record.grade.isNullOrBlank()) "-" else record.grade
                    val isGradeSelected = currentGrade != "-"

                    Box(modifier = Modifier.weight(1.7f)) {
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { gradeExpanded = true },
                            shape = RoundedCornerShape(8.dp),
                            color = when {
                                currentGrade.contains("100") || currentGrade.contains("ممتاز") -> Emerald50
                                isGradeSelected -> Brand50
                                else -> Slate50
                            },
                            border = BorderStroke(
                                1.dp,
                                when {
                                    currentGrade.contains("100") || currentGrade.contains("ممتاز") -> Emerald600
                                    isGradeSelected -> Brand300
                                    else -> Slate300
                                }
                            )
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 7.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    currentGrade,
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = if (isGradeSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = when {
                                        currentGrade.contains("100") || currentGrade.contains("ممتاز") -> Emerald700
                                        isGradeSelected -> Brand700
                                        else -> Slate500
                                    },
                                    maxLines = 1,
                                    softWrap = false
                                )
                                Icon(Icons.Filled.ArrowDropDown, contentDescription = null, tint = Slate500, modifier = Modifier.size(18.dp))
                            }
                        }

                        if (gradeExpanded) {
                            DropdownMenu(
                                expanded = gradeExpanded,
                                onDismissRequest = { gradeExpanded = false },
                                modifier = Modifier.background(Color.White)
                            ) {
                                listOf("ممتاز 100", "ممتاز 95", "ممتاز", "جيد جداً 85", "جيد جداً", "جيد 75", "مقبول 60", "ضعيف", "إعادة").forEach { g ->
                                    DropdownMenuItem(
                                        text = { Text(g, style = MaterialTheme.typography.bodyMedium) },
                                        onClick = {
                                            onUpdate(record.copy(grade = g))
                                            gradeExpanded = false
                                        }
                                    )
                                }
                                if (isGradeSelected) {
                                    HorizontalDivider(color = Slate200)
                                    DropdownMenuItem(
                                        text = { Text("إلغاء التحديد (-)", style = MaterialTheme.typography.bodySmall, color = Slate500) },
                                        onClick = {
                                            onUpdate(record.copy(grade = ""))
                                            gradeExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    // Behavior Selector
                    var behaviorExpanded by remember { mutableStateOf(false) }
                    val currentBehavior = record.behavior ?: ""
                    val behaviorLabel = when (currentBehavior) {
                        "مؤدب" -> "🌟 مؤدب"
                        "يحتاج هدوء" -> "يحتاج هدوء"
                        else -> "+ السلوك"
                    }
                    val isBehaviorActive = currentBehavior.isNotEmpty()

                    Box(modifier = Modifier.weight(1.3f)) {
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { behaviorExpanded = true },
                            shape = RoundedCornerShape(8.dp),
                            color = when (currentBehavior) {
                                "مؤدب" -> Emerald50
                                "يحتاج هدوء" -> Amber50
                                else -> Slate50
                            },
                            border = BorderStroke(
                                1.dp,
                                when (currentBehavior) {
                                    "مؤدب" -> Emerald600
                                    "يحتاج هدوء" -> Amber600
                                    else -> Slate300
                                }
                            )
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 7.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    behaviorLabel,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = if (isBehaviorActive) FontWeight.Bold else FontWeight.Normal,
                                    color = when (currentBehavior) {
                                        "مؤدب" -> Emerald700
                                        "يحتاج هدوء" -> Amber700
                                        else -> Slate700
                                    },
                                    maxLines = 1,
                                    softWrap = false
                                )
                                Icon(Icons.Filled.ArrowDropDown, contentDescription = null, tint = Slate500, modifier = Modifier.size(16.dp))
                            }
                        }

                        if (behaviorExpanded) {
                            DropdownMenu(
                                expanded = behaviorExpanded,
                                onDismissRequest = { behaviorExpanded = false },
                                modifier = Modifier.background(Color.White)
                            ) {
                                DropdownMenuItem(
                                    text = {
                                        Text("🌟 مؤدب", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = Emerald700)
                                    },
                                    onClick = {
                                        onUpdate(record.copy(behavior = if (currentBehavior == "مؤدب") "" else "مؤدب"))
                                        behaviorExpanded = false
                                    }
                                )
                                DropdownMenuItem(
                                    text = {
                                        Text("يحتاج هدوء", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = Amber700)
                                    },
                                    onClick = {
                                        onUpdate(record.copy(behavior = if (currentBehavior == "يحتاج هدوء") "" else "يحتاج هدوء"))
                                        behaviorExpanded = false
                                    }
                                )
                                if (isBehaviorActive) {
                                    HorizontalDivider(color = Slate200)
                                    DropdownMenuItem(
                                        text = { Text("إلغاء التحديد", style = MaterialTheme.typography.bodySmall, color = Slate500) },
                                        onClick = {
                                            onUpdate(record.copy(behavior = ""))
                                            behaviorExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun NewTestSectionSelectionDialog(
    mosque: Mosque,
    onDismiss: () -> Unit,
    onConfirm: (Set<String>) -> Unit
) {
    val scopedStudents = remember(mosque.students, mosque.name) { mosque.scopedStudents }
    var selectedSections by remember {
        mutableStateOf(
            setOf(
                StudentDepartments.TILAWA,
                StudentDepartments.RASHIDI,
                StudentDepartments.QURAN_GHAIBAN,
                StudentDepartments.TAJWEED
            )
        )
    }

    val studentCountFor: (String) -> Int = { dept ->
        scopedStudents.count { it.safeDepartment == dept }
    }

    val totalSelectedStudents = remember(selectedSections, scopedStudents) {
        scopedStudents.count { it.safeDepartment in selectedSections }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(18.dp),
        containerColor = Color.White,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Brand50,
                    modifier = Modifier.size(36.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(Icons.Filled.FactCheck, contentDescription = null, tint = Brand600, modifier = Modifier.size(20.dp))
                    }
                }
                Spacer(Modifier.width(10.dp))
                Column {
                    Text("اختيار أقسام الاختبار", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Slate900)
                    Text("اختر قسماً أو عدة أقسام لإدراج طلابها", style = MaterialTheme.typography.labelSmall, color = Slate500)
                }
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable {
                            if (selectedSections.size == StudentDepartments.ALL.size) {
                                selectedSections = emptySet()
                            } else {
                                selectedSections = StudentDepartments.ALL.toSet()
                            }
                        }
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "تحديد جميع الأقسام (${scopedStudents.size.toString().toStandardDigits()} طالب)",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = Brand700,
                        maxLines = 1,
                        softWrap = false
                    )
                    Checkbox(
                        checked = selectedSections.size == StudentDepartments.ALL.size,
                        onCheckedChange = { checked ->
                            selectedSections = if (checked) StudentDepartments.ALL.toSet() else emptySet()
                        }
                    )
                }

                HorizontalDivider(color = Slate200)

                StudentDepartments.ALL.forEach { dept ->
                    val isChecked = selectedSections.contains(dept)
                    val count = studentCountFor(dept)
                    val info = getDepartmentUiInfo(dept)

                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                selectedSections = if (isChecked) selectedSections - dept else selectedSections + dept
                            },
                        shape = RoundedCornerShape(10.dp),
                        color = if (isChecked) info.containerColor else Slate50,
                        border = BorderStroke(1.dp, if (isChecked) info.borderColor else Slate200)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(
                                    checked = isChecked,
                                    onCheckedChange = { checked ->
                                        selectedSections = if (checked) selectedSections + dept else selectedSections - dept
                                    }
                                )
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    dept,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = if (isChecked) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isChecked) info.textColor else Slate800,
                                    maxLines = 1,
                                    softWrap = false
                                )
                            }
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = if (isChecked) Color.White else Slate200
                            ) {
                                Text(
                                    "${count.toString().toStandardDigits()} طالب",
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isChecked) info.textColor else Slate600,
                                    maxLines = 1,
                                    softWrap = false
                                )
                            }
                        }
                    }
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Brand50,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        "سيتم إدراج ${totalSelectedStudents.toString().toStandardDigits()} طالب في الاختبار مرتبين حسب الأقسام.",
                        modifier = Modifier.padding(10.dp),
                        style = MaterialTheme.typography.labelSmall,
                        color = Brand700
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(selectedSections) },
                enabled = selectedSections.isNotEmpty() && totalSelectedStudents > 0,
                colors = ButtonDefaults.buttonColors(containerColor = Brand600),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(Icons.Filled.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("بدء الاختبار (${totalSelectedStudents.toString().toStandardDigits()})", maxLines = 1, softWrap = false)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء", color = Slate500)
            }
        }
    )
}

@Composable
fun AddDepartmentToTestDialog(
    mosque: Mosque,
    currentTestSections: List<String>,
    onDismiss: () -> Unit,
    onAddDepartment: (String) -> Unit
) {
    val scopedStudents = remember(mosque.students, mosque.name) { mosque.scopedStudents }
    val availableDepartments = StudentDepartments.ALL.filter { !currentTestSections.contains(it) }

    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(16.dp),
        containerColor = Color.White,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Add, contentDescription = null, tint = Brand600)
                Spacer(Modifier.width(8.dp))
                Text("إضافة قسم إضافي للاختبار", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("اختر قسماً لإدراج طلابه في سجل هذا الاختبار الحالي:", style = MaterialTheme.typography.bodySmall, color = Slate600)
                if (availableDepartments.isEmpty()) {
                    Text("جميع الأقسام مضافة بالفعل في هذا الاختبار.", color = Slate500, style = MaterialTheme.typography.bodyMedium)
                } else {
                    availableDepartments.forEach { dept ->
                        val count = scopedStudents.count { it.safeDepartment == dept }
                        val info = getDepartmentUiInfo(dept)
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onAddDepartment(dept) },
                            shape = RoundedCornerShape(10.dp),
                            color = info.containerColor,
                            border = BorderStroke(1.dp, info.borderColor)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(info.icon, contentDescription = null, tint = info.textColor, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(8.dp))
                                    Text(dept, fontWeight = FontWeight.Bold, color = info.textColor, style = MaterialTheme.typography.bodyMedium)
                                }
                                Text("${count.toString().toStandardDigits()} طالب", color = info.textColor, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إغلاق", color = Slate500) }
        }
    )
}
