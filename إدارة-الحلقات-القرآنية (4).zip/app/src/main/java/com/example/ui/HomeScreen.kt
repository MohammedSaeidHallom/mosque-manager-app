package com.example.ui

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Mosque
import com.example.ui.theme.*
import com.example.utils.toStandardDigits

@Composable
fun HomeScreen(viewModel: MosqueViewModel, mosques: List<Mosque>) {
    var newMosqueName by remember { mutableStateOf("") }
    val context = LocalContext.current
    var searchQuery by remember { mutableStateOf("") }

    var mosqueToDelete by remember { mutableStateOf<String?>(null) }
    var mosqueToEdit by remember { mutableStateOf<Mosque?>(null) }
    var editMosqueNameText by remember { mutableStateOf("") }
    var confirmRestore by remember { mutableStateOf<Uri?>(null) }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            viewModel.exportDbToUri(context, uri) { ok ->
                Toast.makeText(
                    context,
                    if (ok) "تم حفظ النسخة الاحتياطية بنجاح" else "فشل حفظ النسخة الاحتياطية",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            confirmRestore = uri
        }
    }

    if (mosqueToEdit != null) {
        AlertDialog(
            onDismissRequest = { mosqueToEdit = null },
            shape = RoundedCornerShape(16.dp),
            containerColor = Color.White,
            title = { Text("تعديل اسم المسجد", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) },
            text = {
                OutlinedTextField(
                    value = editMosqueNameText,
                    onValueChange = { editMosqueNameText = it },
                    singleLine = true,
                    label = { Text("اسم المسجد") },
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (editMosqueNameText.isNotBlank()) {
                            viewModel.editMosqueName(mosqueToEdit!!.id, editMosqueNameText.trim())
                            Toast.makeText(context, "تم تعديل اسم المسجد", Toast.LENGTH_SHORT).show()
                        }
                        mosqueToEdit = null
                    },
                    shape = RoundedCornerShape(8.dp)
                ) { Text("حفظ") }
            },
            dismissButton = {
                TextButton(onClick = { mosqueToEdit = null }) { Text("إلغاء", color = Slate500) }
            }
        )
    }

    if (confirmRestore != null) {
        AlertDialog(
            onDismissRequest = { confirmRestore = null },
            shape = RoundedCornerShape(16.dp),
            containerColor = Color.White,
            title = { Text("تأكيد الاستعادة", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) },
            text = { Text("تحذير: استعادة النسخة الاحتياطية ستمسح البيانات الحالية وتستبدلها بالبيانات المستوردة. هل أنت متأكد؟", style = MaterialTheme.typography.bodyMedium) },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.importDbFromUri(context, confirmRestore!!) { success ->
                            Toast.makeText(
                                context,
                                if (success) "تم استعادة البيانات بنجاح" else "فشل استعادة البيانات",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                        confirmRestore = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Rose500),
                    shape = RoundedCornerShape(8.dp)
                ) { Text("استعادة وتأكيد") }
            },
            dismissButton = {
                TextButton(onClick = { confirmRestore = null }) { Text("إلغاء", color = Slate500) }
            }
        )
    }

    if (mosqueToDelete != null) {
        AlertDialog(
            onDismissRequest = { mosqueToDelete = null },
            shape = RoundedCornerShape(16.dp),
            containerColor = Color.White,
            title = { Text("حذف المسجد", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) },
            text = { Text("هل أنت متأكد من حذف هذا المسجد بالكامل مع جميع طلابه وسجلات دروسه واختباراته؟", style = MaterialTheme.typography.bodyMedium) },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteMosque(mosqueToDelete!!)
                        mosqueToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Rose500),
                    shape = RoundedCornerShape(8.dp)
                ) { Text("نعم، حذف") }
            },
            dismissButton = {
                TextButton(onClick = { mosqueToDelete = null }) { Text("إلغاء", color = Slate500) }
            }
        )
    }

    val filteredMosques = remember(mosques, searchQuery) {
        if (searchQuery.isBlank()) mosques else mosques.filter { it.name.contains(searchQuery, ignoreCase = true) }
    }

    var showDuplicatesDialog by remember { mutableStateOf(false) }
    val duplicateGroups by viewModel.duplicateGroups.collectAsState()
    val duplicatesCount by viewModel.duplicatesCount.collectAsState()

    if (showDuplicatesDialog) {
        DuplicateStudentsDialog(
            viewModel = viewModel,
            duplicateGroups = duplicateGroups,
            onDismiss = { showDuplicatesDialog = false }
        )
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        // Notification Alert Card at the very top for Duplicates with Small Refresh Button
        item(key = "duplicate_notification_bar") {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showDuplicatesDialog = true },
                shape = RoundedCornerShape(14.dp),
                color = if (duplicatesCount > 0) Rose50 else Brand50.copy(alpha = 0.6f),
                border = BorderStroke(1.5.dp, if (duplicatesCount > 0) Rose300 else Brand200)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .weight(1f)
                            .padding(end = 6.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = if (duplicatesCount > 0) Rose600 else Brand600,
                            modifier = Modifier.size(38.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                BadgedBox(
                                    badge = {
                                        if (duplicatesCount > 0) {
                                            Badge(
                                                containerColor = Amber500,
                                                contentColor = Slate900
                                            ) {
                                                Text(
                                                    duplicatesCount.toString().toStandardDigits(),
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 10.sp,
                                                    maxLines = 1,
                                                    softWrap = false
                                                )
                                            }
                                        }
                                    }
                                ) {
                                    Icon(
                                        imageVector = if (duplicatesCount > 0) Icons.Filled.NotificationsActive else Icons.Filled.Notifications,
                                        contentDescription = "إشعارات التكرار",
                                        tint = Color.White,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }
                        Spacer(Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    "إشعارات الأسماء المكررة",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = if (duplicatesCount > 0) Rose900 else Brand900,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                if (duplicatesCount > 0) {
                                    Spacer(Modifier.width(6.dp))
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = Rose600
                                    ) {
                                        Text(
                                            "${duplicatesCount.toString().toStandardDigits()} تنبيه",
                                            color = Color.White,
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1,
                                            softWrap = false,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }
                            Text(
                                if (duplicatesCount > 0) "توجد أسماء مكررة؛ انقر لعرض مكان التكرار وتجاهل الإشعار أو اختيار النسخة المراد حذفها."
                                else "لا توجد أسماء مكررة حالياً. اضغط زر التحديث لإعادة الفحص وإظهار المتجاهل سابقاً.",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (duplicatesCount > 0) Rose700 else Slate600,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        // زر صغير لتحديث والبحث عن التكرارات
                        Surface(
                            onClick = {
                                viewModel.recheckDuplicates()
                                Toast.makeText(
                                    context,
                                    "تم تحديث حالة البحث عن التكرارات وإظهار الأسماء المتجاهلة سابقاً ✓",
                                    Toast.LENGTH_SHORT
                                ).show()
                            },
                            shape = RoundedCornerShape(8.dp),
                            color = Color.White,
                            border = BorderStroke(1.dp, if (duplicatesCount > 0) Rose300 else Brand300),
                            modifier = Modifier.size(34.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    Icons.Filled.Refresh,
                                    contentDescription = "تحديث وبحث عن التكرارات",
                                    tint = if (duplicatesCount > 0) Rose600 else Brand700,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        FilledTonalButton(
                            onClick = { showDuplicatesDialog = true },
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.filledTonalButtonColors(
                                containerColor = if (duplicatesCount > 0) Rose600 else Brand600,
                                contentColor = Color.White
                            ),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            modifier = Modifier.height(34.dp)
                        ) {
                            Text(
                                if (duplicatesCount > 0) "عرض" else "فحص",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                softWrap = false
                            )
                        }
                    }
                }
            }
        }

        // Add Mosque Card
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text(
                        "إضافة مسجد / حلقة جديدة",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = newMosqueName,
                            onValueChange = { newMosqueName = it },
                            modifier = Modifier.weight(1f),
                            placeholder = { Text("اسم المسجد أو الحلقة...", style = MaterialTheme.typography.bodyMedium, color = Slate400) },
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp),
                            textStyle = MaterialTheme.typography.bodyMedium.copy(textAlign = TextAlign.Right),
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                            keyboardActions = KeyboardActions(onDone = {
                                if (newMosqueName.isNotBlank()) {
                                    viewModel.addMosque(newMosqueName)
                                    Toast.makeText(context, "تم إضافة المسجد بنجاح", Toast.LENGTH_SHORT).show()
                                    newMosqueName = ""
                                } else {
                                    Toast.makeText(context, "يرجى كتابة اسم المسجد", Toast.LENGTH_SHORT).show()
                                }
                            })
                        )
                        Spacer(Modifier.width(8.dp))
                        Button(
                            onClick = {
                                if (newMosqueName.isNotBlank()) {
                                    viewModel.addMosque(newMosqueName)
                                    Toast.makeText(context, "تم إضافة المسجد بنجاح", Toast.LENGTH_SHORT).show()
                                    newMosqueName = ""
                                } else {
                                    Toast.makeText(context, "يرجى كتابة اسم المسجد", Toast.LENGTH_SHORT).show()
                                }
                            },
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.height(52.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("إضافة", style = MaterialTheme.typography.labelLarge, maxLines = 1, softWrap = false)
                        }
                    }
                }
            }
        }

        // Overall summary row
        if (mosques.isNotEmpty()) {
            val totalStudents = mosques.sumOf { it.scopedStudents.size }
            val totalLessons = mosques.sumOf { it.lessons.size }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatCard(value = mosques.size.toString().toStandardDigits(), label = "المساجد", icon = Icons.Outlined.Place, color = Brand600, modifier = Modifier.weight(1f))
                    StatCard(value = totalStudents.toString().toStandardDigits(), label = "إجمالي الطلبة", icon = Icons.Outlined.People, color = Slate700, modifier = Modifier.weight(1f))
                    StatCard(value = totalLessons.toString().toStandardDigits(), label = "إجمالي الدروس", icon = Icons.Outlined.MenuBook, color = Emerald500, modifier = Modifier.weight(1f))
                }
            }
        }

        // Section Header & Backup/Restore
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(Modifier.padding(14.dp)) {
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "المساجد والحلقات (${mosques.size.toString().toStandardDigits()})",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Slate900,
                            maxLines = 1
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            FilledTonalButton(
                                onClick = { exportLauncher.launch("mosque_backup.json") },
                                colors = ButtonDefaults.filledTonalButtonColors(
                                    containerColor = Slate100,
                                    contentColor = Slate700
                                ),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                modifier = Modifier.height(34.dp)
                            ) {
                                Icon(Icons.Outlined.FileDownload, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("نسخ احتياطي", style = MaterialTheme.typography.labelSmall, maxLines = 1, softWrap = false)
                            }
                            FilledTonalButton(
                                onClick = { importLauncher.launch(arrayOf("application/json", "*/*")) },
                                colors = ButtonDefaults.filledTonalButtonColors(
                                    containerColor = Brand50,
                                    contentColor = Brand700
                                ),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                modifier = Modifier.height(34.dp)
                            ) {
                                Icon(Icons.Outlined.FileUpload, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("استعادة", style = MaterialTheme.typography.labelSmall, maxLines = 1, softWrap = false)
                            }
                        }
                    }

                    if (mosques.size > 2) {
                        Spacer(Modifier.height(10.dp))
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            modifier = Modifier.fillMaxWidth(),
                            placeholder = { Text("بحث عن مسجد...", style = MaterialTheme.typography.bodySmall, color = Slate400) },
                            singleLine = true,
                            shape = RoundedCornerShape(8.dp),
                            textStyle = MaterialTheme.typography.bodyMedium.copy(textAlign = TextAlign.Right),
                            leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null, tint = Slate400, modifier = Modifier.size(18.dp)) }
                        )
                    }
                }
            }
        }

        // Mosques list or empty state
        if (mosques.isEmpty()) {
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(
                        Modifier.fillMaxWidth().padding(36.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = Slate100,
                            modifier = Modifier.size(54.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Outlined.Mosque, contentDescription = null, tint = Slate400, modifier = Modifier.size(28.dp))
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        Text("لا توجد مساجد أو حلقات مضافة حالياً", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, color = Slate700)
                        Spacer(Modifier.height(4.dp))
                        Text("أدخل اسم المسجد في الأعلى للبدء بتسجيل الطلاب والدروس", style = MaterialTheme.typography.bodySmall, color = Slate500)
                    }
                }
            }
        } else {
            items(filteredMosques, key = { it.id }) { mosque ->
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.openMosque(mosque.id) },
                    shape = RoundedCornerShape(18.dp),
                    color = MaterialTheme.colorScheme.surface,
                    shadowElevation = 2.dp,
                    border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(start = 8.dp, end = 4.dp, top = 12.dp, bottom = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = Brand50,
                            modifier = Modifier.padding(horizontal = 8.dp).size(46.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Outlined.Mosque, contentDescription = null, tint = Brand600, modifier = Modifier.size(26.dp))
                            }
                        }
                        Column(Modifier.weight(1f).padding(horizontal = 4.dp)) {
                            Text(
                                mosque.name,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Slate900,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(Modifier.height(6.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                MosqueChip("${mosque.scopedStudents.size.toString().toStandardDigits()} طالب", Brand50, Brand700)
                                MosqueChip("${mosque.lessons.size.toString().toStandardDigits()} درس", Slate100, Slate600)
                                MosqueChip("${mosque.tests.size.toString().toStandardDigits()} اختبار", Gold50, Amber700)
                            }
                        }
                        IconButton(onClick = {
                            editMosqueNameText = mosque.name
                            mosqueToEdit = mosque
                        }) {
                            Icon(Icons.Outlined.Edit, contentDescription = "تعديل", tint = Slate500, modifier = Modifier.size(18.dp))
                        }
                        IconButton(onClick = { mosqueToDelete = mosque.id }) {
                            Icon(Icons.Outlined.DeleteOutline, contentDescription = "حذف", tint = Rose500, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MosqueChip(text: String, bg: Color, fg: Color) {
    Surface(shape = RoundedCornerShape(8.dp), color = bg) {
        Text(
            text,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
            style = MaterialTheme.typography.labelSmall,
            color = fg,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            softWrap = false
        )
    }
}

@Composable
fun StatCard(value: String, label: String, icon: ImageVector? = null, color: Color = Brand600, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        color = color.copy(alpha = 0.08f),
        border = BorderStroke(0.5.dp, color.copy(alpha = 0.18f))
    ) {
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (icon != null) {
                Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(18.dp))
                Spacer(Modifier.height(2.dp))
            }
            Text(value, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = color, maxLines = 1, softWrap = false)
            Text(label, style = MaterialTheme.typography.labelSmall, color = Slate600, maxLines = 1, softWrap = false)
        }
    }
}
