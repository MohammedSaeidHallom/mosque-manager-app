package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val PrimaryColor = Brand600
val SecondaryColor = Slate600
val BackgroundColor = Slate50

private val BrandColorScheme = lightColorScheme(
    primary = Brand600,
    onPrimary = Color.White,
    primaryContainer = Brand50,
    onPrimaryContainer = Brand900,
    inversePrimary = Brand100,
    
    secondary = Slate600,
    onSecondary = Color.White,
    secondaryContainer = Slate100,
    onSecondaryContainer = Slate800,
    
    tertiary = Emerald500,
    onTertiary = Color.White,
    tertiaryContainer = Emerald50,
    onTertiaryContainer = Color(0xFF065F46),
    
    background = Slate50,
    onBackground = Slate900,
    
    surface = Color.White,
    onSurface = Slate900,
    surfaceVariant = Slate100,
    onSurfaceVariant = Slate600,
    
    outline = Slate200,
    outlineVariant = Slate300,
    
    error = Rose500,
    onError = Color.White,
    errorContainer = Rose50,
    onErrorContainer = Color(0xFF991B1B)
)

@Composable
fun MosqueTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = BrandColorScheme,
        typography = CairoModernTypography,
        content = content
    )
}
