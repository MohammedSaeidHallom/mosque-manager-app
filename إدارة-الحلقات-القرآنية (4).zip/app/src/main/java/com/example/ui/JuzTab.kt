package com.example.ui

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.JuzRecord
import com.example.data.Mosque
import com.example.ui.theme.*
import com.example.utils.toStandardDigits
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun JuzTab(viewModel: MosqueViewModel, mosque: Mosque) {
    val context = LocalContext.current
    val todayDate = remember {
        val day = SimpleDateFormat("EEEE", Locale("ar", "EG")).format(Date())
        val dateStr = SimpleDateFormat("dd/MM/yyyy", Locale.US).format(Date()).toStandardDigits()
        "$day $dateStr"
    }

    var recordsList by remember(mosque.juzRecords) {
        mutableStateOf(mosque.safeJuzRecords)
    }

    var showAddDialog by remember { mutableStateOf(false) }
    var showClearConfirm by remember { mutableStateOf(false) }
    var partPickerRecordIndex by remember { mutableStateOf<Int?>(null) }
    var hasUnsavedChanges by remember { mutableStateOf(false) }

    fun updateRecords(newList: List<JuzRecord>) {
        recordsList = newList
        hasUnsavedChanges = false
        viewModel.saveJuzRecords(newList)
    }

    fun saveChanges() {
        viewModel.saveJuzRecords(recordsList)
        viewModel.flushSaveNow()
        hasUnsavedChanges = false
        Toast.makeText(context, "تم حفظ قائمة الأجزاء بنجاح ✓", Toast.LENGTH_SHORT).show()
    }

    if (partPickerRecordIndex != null && partPickerRecordIndex in recordsList.indices) {
        val index = partPickerRecordIndex!!
        val currentRecord = recordsList[index]
        MultiPartPickerDialog(
            studentName = currentRecord.studentName,
            initialParts = currentRecord.safeJuzNumbers,
            onDismiss = { partPickerRecordIndex = null },
            onConfirm = { selectedParts ->
                val updated = recordsList.toMutableList()
                val sorted = selectedParts.sorted()
                updated[index] = currentRecord.copy(
                    juzNumbers = sorted,
                    juzNumber = sorted.firstOrNull() ?: 1
                )
                updateRecords(updated)
                partPickerRecordIndex = null
            }
        )
    }

    if (showClearConfirm) {
        AlertDialog(
            onDismissRequest = { showClearConfirm = false },
            shape = RoundedCornerShape(16.dp),
            containerColor = Color.White,
            title = { Text("مسح قائمة الأجزاء", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) },
            text = { Text("هل أنت متأكد من مسح جميع الأسماء الحالية في قائمة الأجزاء؟", style = MaterialTheme.typography.bodyMedium) },
            confirmButton = {
                Button(
                    onClick = {
                        updateRecords(emptyList())
                        viewModel.saveJuzRecords(emptyList())
                        showClearConfirm = false
                        Toast.makeText(context, "تم مسح القائمة", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Rose500),
                    shape = RoundedCornerShape(8.dp)
                ) { Text("نعم، مسح") }
            },
            dismissButton = {
                TextButton(onClick = { showClearConfirm = false }) { Text("إلغاء", color = Slate500) }
            }
        )
    }

    if (showAddDialog) {
        AddStudentsToJuzDialog(
            mosque = mosque,
            currentRecords = recordsList,
            onDismiss = { showAddDialog = false },
            onAdd = { newRecords ->
                updateRecords(recordsList + newRecords)
                showAddDialog = false
                Toast.makeText(context, "تمت إضافة ${newRecords.size} طالب إلى القائمة", Toast.LENGTH_SHORT).show()
            }
        )
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(bottom = 28.dp)
    ) {
        // Main Header & Action Card (Unified, non-wrapping toolbar buttons)
        item(key = "juz_header", contentType = "header") {
            UnifiedTopActionCard(
                title = "السجل",
                subtitle = todayDate,
                icon = Icons.Filled.BookmarkAdded,
                onSaveClick = { saveChanges() },
                saveButtonText = if (hasUnsavedChanges) "حفظ التعديل" else "حفظ",
                hasUnsavedChanges = hasUnsavedChanges,
                primaryActionText = "إضافة طلاب",
                primaryActionIcon = Icons.Filled.GroupAdd,
                onPrimaryActionClick = { showAddDialog = true },
                onWhatsAppClick = {
                    if (hasUnsavedChanges) saveChanges()
                    viewModel.shareWhatsApp(context, mosque, MosqueViewModel.Tab.JUZ.name)
                },
                onPdfClick = {
                    if (hasUnsavedChanges) saveChanges()
                    viewModel.generatePdf(context, mosque, MosqueViewModel.Tab.JUZ.name)
                },
                onImageClick = {
                    if (hasUnsavedChanges) saveChanges()
                    viewModel.shareAsImage(context, mosque, MosqueViewModel.Tab.JUZ.name, targetPackage = null)
                },
                onClearClick = if (recordsList.isNotEmpty()) ({ showClearConfirm = true }) else null
            )
        }

        // Empty state or list
        if (recordsList.isEmpty()) {
            item(key = "juz_empty", contentType = "empty") {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 24.dp),
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(28.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = Slate100,
                            modifier = Modifier.size(60.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    Icons.Filled.BookmarkAdded,
                                    contentDescription = null,
                                    tint = Slate400,
                                    modifier = Modifier.size(32.dp)
                                )
                            }
                        }
                        Spacer(Modifier.height(14.dp))
                        Text(
                            "قائمة الأجزاء فارغة حالياً",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Slate800
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "اضغط على زر «إضافة طلاب» لتحديد طالب أو عدة طلاب وتحديد الجزء أو المنهج المنجز.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Slate500,
                            textAlign = TextAlign.Center
                        )
                        Spacer(Modifier.height(16.dp))
                        Button(
                            onClick = { showAddDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Filled.GroupAdd, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("إضافة طلاب للقائمة", maxLines = 1, softWrap = false)
                        }
                    }
                }
            }
        } else {
            item(key = "juz_summary", contentType = "summary") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "الطلاب في السجل: ${recordsList.size.toString().toStandardDigits()}",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = Slate700,
                        maxLines = 1,
                        softWrap = false
                    )
                    Text(
                        "رشيدي: ${recordsList.count { it.curriculum == "رشيدي" }.toString().toStandardDigits()} | قرآن/تجويد: ${recordsList.count { it.curriculum != "رشيدي" }.toString().toStandardDigits()}",
                        style = MaterialTheme.typography.labelSmall,
                        color = Slate500,
                        maxLines = 1,
                        softWrap = false
                    )
                }
            }

            itemsIndexed(recordsList, key = { index, r -> "${r.studentId}_$index" }, contentType = { _, _ -> "juz_card" }) { index, record ->
                JuzStudentCard(
                    index = index + 1,
                    record = record,
                    onUpdate = { updated ->
                        val updatedList = recordsList.toMutableList()
                        updatedList[index] = updated
                        updateRecords(updatedList)
                    },
                    onRemove = {
                        val updatedList = recordsList.toMutableList()
                        updatedList.removeAt(index)
                        updateRecords(updatedList)
                    },
                    onOpenPartPicker = {
                        partPickerRecordIndex = index
                    }
                )
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun JuzStudentCard(
    index: Int,
    record: JuzRecord,
    onUpdate: (JuzRecord) -> Unit,
    onRemove: () -> Unit,
    onOpenPartPicker: () -> Unit
) {
    val curriculumOptions = listOf("قرآن", "رشيدي", "قرآن غيباً", "تجويد")

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f).padding(end = 6.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier.size(26.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                index.toString().toStandardDigits(),
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                maxLines = 1,
                                softWrap = false
                            )
                        }
                    }
                    Spacer(Modifier.width(8.dp))
                    Text(
                        record.studentName,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Slate900,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                IconButton(
                    onClick = onRemove,
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        Icons.Outlined.Close,
                        contentDescription = "إزالة",
                        tint = Slate400,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(Modifier.height(8.dp))

            Text(
                "اختر المنهج:",
                style = MaterialTheme.typography.labelSmall,
                color = Slate500,
                fontWeight = FontWeight.Medium
            )
            Spacer(Modifier.height(4.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                curriculumOptions.forEach { opt ->
                    val isSelected = record.curriculum == opt
                    LightChip(
                        selected = isSelected,
                        text = opt,
                        selectedColor = if (opt == "رشيدي") Emerald600 else Brand600,
                        onClick = { if (!isSelected) onUpdate(record.copy(curriculum = opt)) }
                    )
                }
            }

            Spacer(Modifier.height(8.dp))

            if (record.curriculum == "رشيدي") {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Emerald50,
                    border = BorderStroke(1.dp, Emerald200),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Filled.MenuBook,
                                contentDescription = null,
                                tint = Emerald600,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(
                                "تحديد قسم الرشيدي:",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = Emerald800
                            )
                        }

                        Spacer(Modifier.height(8.dp))

                        val rashidiOptions = listOf("رشيدي قسم أول", "رشيدي كامل")
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            rashidiOptions.forEach { opt ->
                                val isSelected = record.safeRashidiType == opt
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (isSelected) Emerald500 else Color.White,
                                    border = BorderStroke(1.dp, if (isSelected) Emerald500 else Emerald200),
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable {
                                            onUpdate(record.copy(rashidiType = opt))
                                        }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.Center
                                    ) {
                                        if (isSelected) {
                                            Icon(
                                                Icons.Filled.CheckCircle,
                                                contentDescription = null,
                                                tint = Color.White,
                                                modifier = Modifier.size(15.dp)
                                            )
                                            Spacer(Modifier.width(4.dp))
                                        }
                                        Text(
                                            opt,
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                            color = if (isSelected) Color.White else Emerald800,
                                            maxLines = 1,
                                            softWrap = false
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(Modifier.height(8.dp))

                        Text(
                            "البيان في التقرير: أنهى ${record.safeRashidiType}",
                            style = MaterialTheme.typography.labelSmall,
                            color = Emerald700,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            } else {
                val currentParts = record.safeJuzNumbers
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                    border = BorderStroke(1.dp, Slate200),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Filled.AutoStories,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(Modifier.width(6.dp))
                                Text(
                                    "الأجزاء المنجزة (${currentParts.size.toString().toStandardDigits()}):",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Slate800,
                                    maxLines = 1,
                                    softWrap = false
                                )
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                val maxPart = currentParts.maxOrNull() ?: 0
                                if (maxPart in 1..29 && (maxPart + 1) !in currentParts) {
                                    FilledTonalButton(
                                        onClick = {
                                            val nextList = (currentParts + (maxPart + 1)).sorted()
                                            onUpdate(record.copy(juzNumbers = nextList, juzNumber = nextList.first()))
                                        },
                                        shape = RoundedCornerShape(6.dp),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                        modifier = Modifier.height(28.dp)
                                    ) {
                                        Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(12.dp))
                                        Spacer(Modifier.width(2.dp))
                                        Text("+ الجزء ${(maxPart + 1).toString().toStandardDigits()}", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                                    }
                                }

                                FilledTonalButton(
                                    onClick = onOpenPartPicker,
                                    shape = RoundedCornerShape(6.dp),
                                    colors = ButtonDefaults.filledTonalButtonColors(
                                        containerColor = MaterialTheme.colorScheme.primaryContainer,
                                        contentColor = MaterialTheme.colorScheme.primary
                                    ),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    modifier = Modifier.height(28.dp)
                                ) {
                                    Icon(Icons.Filled.Edit, contentDescription = null, modifier = Modifier.size(12.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text("تحديد الأجزاء", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                                }
                            }
                        }

                        Spacer(Modifier.height(8.dp))

                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            currentParts.forEach { partNum ->
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.clickable { onOpenPartPicker() }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            "الجزء ${partNum.toString().toStandardDigits()}",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White,
                                            maxLines = 1,
                                            softWrap = false
                                        )
                                        if (currentParts.size > 1) {
                                            Spacer(Modifier.width(4.dp))
                                            Icon(
                                                Icons.Filled.Close,
                                                contentDescription = "حذف الجزء",
                                                tint = Color.White.copy(alpha = 0.8f),
                                                modifier = Modifier
                                                    .size(14.dp)
                                                    .clickable {
                                                        val updatedParts = currentParts.filter { it != partNum }
                                                        onUpdate(record.copy(juzNumbers = updatedParts, juzNumber = updatedParts.firstOrNull() ?: 1))
                                                    }
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        Spacer(Modifier.height(8.dp))
                        Text(
                            "البيان في التقرير: ${record.completionText} (${record.curriculum})",
                            style = MaterialTheme.typography.labelSmall,
                            color = Slate600
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AddStudentsToJuzDialog(
    mosque: Mosque,
    currentRecords: List<JuzRecord>,
    onDismiss: () -> Unit,
    onAdd: (List<JuzRecord>) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    val alreadyAddedIds = remember(currentRecords) { currentRecords.map { it.studentId }.toSet() }
    val scopedStudents = remember(mosque.students, mosque.name) { mosque.scopedStudents }

    var selectedIds by remember { mutableStateOf(setOf<String>()) }

    val filteredStudents = remember(scopedStudents, searchQuery) {
        if (searchQuery.isEmpty()) {
            scopedStudents
        } else {
            scopedStudents.filter { it.fullName.contains(searchQuery, ignoreCase = true) }
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp,
            modifier = Modifier
                .fillMaxWidth()
                .padding(4.dp)
        ) {
            Column(
                modifier = Modifier.padding(18.dp)
            ) {
                Text(
                    "إضافة طلاب إلى قائمة الأجزاء",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    "حدد طالباً واحداً أو اختر تحديداً متعدداً لإضافتهم دفعة واحدة",
                    style = MaterialTheme.typography.bodySmall,
                    color = Slate500,
                    modifier = Modifier.padding(top = 2.dp, bottom = 10.dp)
                )

                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("بحث عن اسم طالب...", fontSize = 13.sp) },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, tint = Slate400, modifier = Modifier.size(18.dp)) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    singleLine = true
                )

                Spacer(Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val eligibleCount = filteredStudents.count { it.id !in alreadyAddedIds }
                    val allEligibleSelected = eligibleCount > 0 && filteredStudents.filter { it.id !in alreadyAddedIds }.all { it.id in selectedIds }

                    TextButton(
                        onClick = {
                            if (allEligibleSelected) {
                                selectedIds = emptySet()
                            } else {
                                selectedIds = filteredStudents.filter { it.id !in alreadyAddedIds }.map { it.id }.toSet()
                            }
                        },
                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 2.dp)
                    ) {
                        Icon(
                            if (allEligibleSelected) Icons.Filled.CheckBox else Icons.Filled.CheckBoxOutlineBlank,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp),
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(
                            if (allEligibleSelected) "إلغاء تحديد الكل" else "تحديد الكل (${eligibleCount.toString().toStandardDigits()})",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            softWrap = false
                        )
                    }

                    Text(
                        "المحدد: ${selectedIds.size.toString().toStandardDigits()}",
                        style = MaterialTheme.typography.labelSmall,
                        color = Slate500,
                        maxLines = 1,
                        softWrap = false
                    )
                }

                Spacer(Modifier.height(6.dp))

                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 300.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    if (filteredStudents.isEmpty()) {
                        item {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 20.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("لا يوجد طلاب مطابقين للبحث", style = MaterialTheme.typography.bodySmall, color = Slate400)
                            }
                        }
                    } else {
                        items(filteredStudents, key = { it.id }) { student ->
                            val isAlreadyAdded = student.id in alreadyAddedIds
                            val isChecked = student.id in selectedIds

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (isChecked) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f) else if (isAlreadyAdded) Slate50 else Color.Transparent,
                                border = BorderStroke(0.5.dp, if (isChecked) MaterialTheme.colorScheme.primary.copy(alpha = 0.5f) else Slate200),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable(enabled = !isAlreadyAdded) {
                                        selectedIds = if (isChecked) selectedIds - student.id else selectedIds + student.id
                                    }
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 10.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Checkbox(
                                        checked = isChecked,
                                        onCheckedChange = { checked ->
                                            selectedIds = if (checked) selectedIds + student.id else selectedIds - student.id
                                        },
                                        enabled = !isAlreadyAdded,
                                        modifier = Modifier.size(24.dp)
                                    )
                                    Spacer(Modifier.width(8.dp))
                                    Text(
                                        student.fullName,
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = if (isChecked) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isAlreadyAdded) Slate400 else Slate900,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f)
                                    )
                                    if (isAlreadyAdded) {
                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = Slate200
                                        ) {
                                            Text(
                                                "مضاف مسبقاً",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = Slate600,
                                                maxLines = 1,
                                                softWrap = false,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    TextButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("إلغاء", color = Slate600)
                    }

                    Button(
                        onClick = {
                            val newRecords = selectedIds.mapNotNull { id ->
                                val student = scopedStudents.find { it.id == id }
                                student?.let {
                                    val defaultCurr = when {
                                        it.safeDepartment.contains("رشيدي") -> "رشيدي"
                                        it.safeDepartment.contains("غيب") -> "قرآن غيباً"
                                        it.safeDepartment.contains("تجويد") -> "تجويد"
                                        else -> "قرآن"
                                    }
                                    JuzRecord(
                                        studentId = it.id,
                                        studentName = it.fullName,
                                        curriculum = defaultCurr,
                                        juzNumber = 1,
                                        juzNumbers = listOf(1),
                                        rashidiType = "رشيدي كامل"
                                    )
                                }
                            }
                            onAdd(newRecords)
                        },
                        enabled = selectedIds.isNotEmpty(),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1.5f)
                    ) {
                        Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("إضافة (${selectedIds.size.toString().toStandardDigits()})", maxLines = 1, softWrap = false)
                    }
                }
            }
        }
    }
}

@Composable
fun MultiPartPickerDialog(
    studentName: String,
    initialParts: List<Int>,
    onDismiss: () -> Unit,
    onConfirm: (List<Int>) -> Unit
) {
    var selectedParts by remember {
        mutableStateOf(if (initialParts.isNotEmpty()) initialParts.toSet() else setOf(1))
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp,
            modifier = Modifier
                .fillMaxWidth()
                .padding(6.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    "تحديد الأجزاء (1 - 30)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    "للطالب: $studentName",
                    style = MaterialTheme.typography.bodySmall,
                    color = Slate500,
                    modifier = Modifier.padding(top = 2.dp, bottom = 4.dp)
                )

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp)
                ) {
                    Text(
                        if (selectedParts.isEmpty()) "لم يتم تحديد أي جزء بعد"
                        else "الأجزاء المحددة (${selectedParts.size.toString().toStandardDigits()}): " + selectedParts.sorted().joinToString("، ") { "جزء $it".toStandardDigits() },
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        textAlign = TextAlign.Center
                    )
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    FilledTonalButton(
                        onClick = { selectedParts = (1..5).toSet() },
                        modifier = Modifier.weight(1f).height(30.dp),
                        contentPadding = PaddingValues(0.dp),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text("1 - 5", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                    }
                    FilledTonalButton(
                        onClick = { selectedParts = (1..10).toSet() },
                        modifier = Modifier.weight(1f).height(30.dp),
                        contentPadding = PaddingValues(0.dp),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text("1 - 10", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                    }
                    FilledTonalButton(
                        onClick = { selectedParts = (1..30).toSet() },
                        modifier = Modifier.weight(1.2f).height(30.dp),
                        contentPadding = PaddingValues(0.dp),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text("ختم كامل", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                    }
                    TextButton(
                        onClick = { selectedParts = emptySet() },
                        modifier = Modifier.weight(0.9f).height(30.dp),
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Text("مسح", fontSize = 11.sp, color = Rose500, maxLines = 1, softWrap = false)
                    }
                }

                Spacer(Modifier.height(6.dp))

                LazyVerticalGrid(
                    columns = GridCells.Fixed(5),
                    horizontalArrangement = Arrangement.spacedBy(5.dp),
                    verticalArrangement = Arrangement.spacedBy(5.dp),
                    modifier = Modifier.heightIn(max = 240.dp)
                ) {
                    gridItems((1..30).toList()) { partNum ->
                        val isSelected = partNum in selectedParts
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isSelected) MaterialTheme.colorScheme.primary else Slate100,
                            border = if (isSelected) null else BorderStroke(0.5.dp, Slate300),
                            modifier = Modifier
                                .aspectRatio(1f)
                                .clickable {
                                    selectedParts = if (isSelected) {
                                        selectedParts - partNum
                                    } else {
                                        selectedParts + partNum
                                    }
                                }
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    partNum.toString().toStandardDigits(),
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isSelected) Color.White else Slate800,
                                    maxLines = 1,
                                    softWrap = false
                                )
                            }
                        }
                    }
                }

                Spacer(Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    TextButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("إلغاء", color = Slate600)
                    }

                    Button(
                        onClick = {
                            val finalParts = if (selectedParts.isEmpty()) listOf(1) else selectedParts.sorted()
                            onConfirm(finalParts)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1.5f)
                    ) {
                        Icon(Icons.Filled.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("تأكيد وحفظ", maxLines = 1, softWrap = false)
                    }
                }
            }
        }
    }
}
