package com.example.ui

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.outlined.AutoStories
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.People
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.Mosque
import com.example.ui.theme.*
import com.example.utils.toStandardDigits

@Composable
fun MosqueDashboard(
    viewModel: MosqueViewModel,
    mosque: Mosque,
    currentTab: MosqueViewModel.Tab,
    openedLessonId: String?
) {
    val context = LocalContext.current
    val openedTestId by viewModel.openedTestId.collectAsState()
    val openedExamGroupId by viewModel.openedExamGroupId.collectAsState()
    val isExporting by viewModel.isExporting.collectAsState()

    var reportStudentId by remember { mutableStateOf<String?>(null) }
    val isEditorOpen = openedLessonId != null || openedTestId != null || openedExamGroupId != null

    val scopedStudents = remember(mosque.students, mosque.name) { mosque.scopedStudents }
    val scopedStudentIds = remember(scopedStudents) { scopedStudents.map { it.id }.toSet() }

    val attendanceRate = remember(mosque.lessons, scopedStudentIds, isEditorOpen) {
        if (isEditorOpen || mosque.lessons.isEmpty()) {
            0
        } else {
            var present = 0
            var totalRecords = 0
            mosque.lessons.forEach { l ->
                l.records.forEach { r ->
                    if (r.studentId in scopedStudentIds && r.attendance.isNotEmpty()) {
                        totalRecords++
                        if (r.attendance == "حضور") present++
                    }
                }
            }
            if (totalRecords > 0) Math.round((present.toFloat() / totalRecords) * 100) else 0
        }
    }
    val rateColor = if (attendanceRate >= 80) Emerald500 else if (attendanceRate >= 50) Amber500 else Rose500

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            // في التبويبات العامة (الطلبة، قائمة الدروس، قائمة الاختبارات، التقارير) نعرض شريط الأزرار الموحد في الأعلى مثل تبويب الجزء
            if (!isEditorOpen && currentTab != MosqueViewModel.Tab.JUZ && currentTab != MosqueViewModel.Tab.EXAM_SCHEDULE) {
                UnifiedTopActionCard(
                    title = mosque.name,
                    subtitle = "إجمالي الطلاب في المجموعة: ${scopedStudents.size.toString().toStandardDigits()}",
                    icon = Icons.Filled.Place,
                    onSaveClick = {
                        viewModel.flushSaveNow()
                        Toast.makeText(context, "تم حفظ جميع البيانات بنجاح ✓", Toast.LENGTH_SHORT).show()
                    },
                    saveButtonText = "حفظ",
                    onWhatsAppClick = {
                        viewModel.shareWhatsApp(context, mosque, currentTab.name, openedLessonId, openedTestId, reportStudentId)
                    },
                    onPdfClick = {
                        viewModel.generatePdf(context, mosque, currentTab.name, openedLessonId, openedTestId, reportStudentId)
                    },
                    onImageClick = {
                        viewModel.shareAsImage(context, mosque, currentTab.name, openedLessonId, openedTestId, reportStudentId, null)
                    }
                )

                Spacer(Modifier.height(10.dp))

                // Stats row
                Row(
                    Modifier.fillMaxWidth().padding(bottom = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    StatCard(
                        value = scopedStudents.size.toString().toStandardDigits(),
                        label = "الطلبة",
                        icon = Icons.Outlined.People,
                        color = Brand600,
                        modifier = Modifier.weight(1f)
                    )
                    StatCard(
                        value = mosque.lessons.size.toString().toStandardDigits(),
                        label = "الدروس",
                        icon = Icons.Outlined.AutoStories,
                        color = Slate700,
                        modifier = Modifier.weight(1f)
                    )
                    StatCard(
                        value = "${attendanceRate.toString().toStandardDigits()}%",
                        label = "نسبة الحضور",
                        icon = Icons.Outlined.CheckCircle,
                        color = rateColor,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // Tab Content
            Box(Modifier.weight(1f)) {
                when (currentTab) {
                    MosqueViewModel.Tab.SETTINGS -> SettingsTab(viewModel, mosque)
                    MosqueViewModel.Tab.LESSONS -> LessonsTab(viewModel, mosque, openedLessonId)
                    MosqueViewModel.Tab.TESTS -> TestsTab(viewModel, mosque, openedTestId)
                    MosqueViewModel.Tab.JUZ -> JuzTab(viewModel, mosque)
                    MosqueViewModel.Tab.REPORTS -> ReportsTab(viewModel, mosque, reportStudentId, { reportStudentId = it })
                    MosqueViewModel.Tab.EXAM_SCHEDULE -> ExamScheduleTab(viewModel, mosque, openedExamGroupId)
                }
            }
        }

        // Exporting overlay
        if (isExporting) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Slate900.copy(alpha = 0.45f)),
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    color = Color.White,
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, Slate200),
                    shadowElevation = 6.dp
                ) {
                    Row(
                        Modifier.padding(horizontal = 24.dp, vertical = 20.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        CircularProgressIndicator(
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp),
                            strokeWidth = 2.5.dp
                        )
                        Text(
                            "جارٍ معالجة وتصدير البيانات...",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Slate900
                        )
                    }
                }
            }
        }
    }
}
