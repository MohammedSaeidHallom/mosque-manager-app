package com.example.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Mosque
import com.example.data.StudentDepartments
import com.example.ui.theme.*
import com.example.utils.ReportFilterUtils
import com.example.utils.ReportPeriodMode
import com.example.utils.toStandardDigits

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsTab(
    viewModel: MosqueViewModel,
    mosque: Mosque,
    reportStudentId: String?,
    onStudentSelect: (String?) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedDepartmentFilter by remember { mutableStateOf("الكل") }
    val filter by viewModel.reportFilter.collectAsState()

    // طلاب هذه المجموعة/المسجد فقط (دون تسرب طلاب المجموعات الأخرى!)
    val scopedStudents = remember(mosque.students, mosque.name) { mosque.scopedStudents }
    val scopedStudentIds = remember(scopedStudents) { scopedStudents.map { it.id }.toSet() }

    // الدروس المفلترة لطلاب هذه المجموعة فقط
    val mosqueScopedLessons = remember(mosque.lessons, scopedStudentIds) {
        mosque.lessons.map { l ->
            l.copy(records = l.records.filter { it.studentId in scopedStudentIds })
        }
    }

    val availableMonths = remember(mosqueScopedLessons) {
        ReportFilterUtils.getAvailableMonths(mosqueScopedLessons)
    }

    val (filteredLessons, periodTitle) = remember(mosqueScopedLessons, filter) {
        ReportFilterUtils.filterLessons(mosqueScopedLessons, filter)
    }

    val selectedStudentName = when (reportStudentId) {
        "all" -> "جميع طلبة المجموعة (${scopedStudents.size.toString().toStandardDigits()} طالب - تقرير شامل)"
        null -> "-- اختر طالباً أو تقريراً شاملاً للمجموعة --"
        else -> scopedStudents.find { it.id == reportStudentId }?.fullName ?: "-- اختر طالباً --"
    }

    Surface(
        Modifier.fillMaxSize(),
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .padding(14.dp)
        ) {
            // Period Filter Card
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 10.dp),
                shape = RoundedCornerShape(12.dp),
                color = Slate50,
                border = BorderStroke(1.dp, Slate200)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        "تحديد نطاق التقرير (${mosque.name} - ${scopedStudents.size.toString().toStandardDigits()} طالب):",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = Slate800,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(Modifier.height(8.dp))

                    // Mode Toggle: Weekly, Monthly, All
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        val isWeekly = filter.mode == ReportPeriodMode.WEEKLY
                        FilterChip(
                            selected = isWeekly,
                            onClick = {
                                viewModel.setReportFilter(filter.copy(mode = ReportPeriodMode.WEEKLY))
                            },
                            leadingIcon = {
                                Icon(Icons.Filled.DateRange, contentDescription = null, modifier = Modifier.size(16.dp))
                            },
                            label = {
                                Text(
                                    "أسبوعية",
                                    fontWeight = if (isWeekly) FontWeight.Bold else FontWeight.Normal,
                                    maxLines = 1,
                                    softWrap = false
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                selectedLabelColor = MaterialTheme.colorScheme.primary
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        )

                        val isMonthly = filter.mode == ReportPeriodMode.MONTHLY
                        FilterChip(
                            selected = isMonthly,
                            onClick = {
                                viewModel.setReportFilter(filter.copy(mode = ReportPeriodMode.MONTHLY))
                            },
                            leadingIcon = {
                                Icon(Icons.Filled.CalendarMonth, contentDescription = null, modifier = Modifier.size(16.dp))
                            },
                            label = {
                                Text(
                                    "شهرية",
                                    fontWeight = if (isMonthly) FontWeight.Bold else FontWeight.Normal,
                                    maxLines = 1,
                                    softWrap = false
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                selectedLabelColor = MaterialTheme.colorScheme.primary
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        )

                        val isAll = filter.mode == ReportPeriodMode.ALL
                        FilterChip(
                            selected = isAll,
                            onClick = {
                                viewModel.setReportFilter(filter.copy(mode = ReportPeriodMode.ALL))
                                if (reportStudentId == null) {
                                    onStudentSelect("all")
                                }
                            },
                            leadingIcon = {
                                Icon(Icons.Filled.Assessment, contentDescription = null, modifier = Modifier.size(16.dp))
                            },
                            label = {
                                Text(
                                    "شامل",
                                    fontWeight = if (isAll) FontWeight.Bold else FontWeight.Normal,
                                    maxLines = 1,
                                    softWrap = false
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                selectedLabelColor = MaterialTheme.colorScheme.primary
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(0.9f)
                        )
                    }

                    // Sub-controls based on mode
                    if (filter.mode == ReportPeriodMode.WEEKLY) {
                        Spacer(Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (filter.isWeeklyLast7Days) Brand600 else Color.White,
                                border = BorderStroke(1.dp, if (filter.isWeeklyLast7Days) Brand600 else Slate300),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable {
                                        viewModel.setReportFilter(filter.copy(isWeeklyLast7Days = true))
                                    }
                            ) {
                                Box(
                                    modifier = Modifier.padding(vertical = 7.dp, horizontal = 4.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        "آخر 7 أيام (تلقائي)",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = if (filter.isWeeklyLast7Days) FontWeight.Bold else FontWeight.Medium,
                                        color = if (filter.isWeeklyLast7Days) Color.White else Slate700,
                                        maxLines = 1,
                                        softWrap = false
                                    )
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (!filter.isWeeklyLast7Days) Brand600 else Color.White,
                                border = BorderStroke(1.dp, if (!filter.isWeeklyLast7Days) Brand600 else Slate300),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable {
                                        viewModel.setReportFilter(filter.copy(isWeeklyLast7Days = false))
                                    }
                            ) {
                                Box(
                                    modifier = Modifier.padding(vertical = 7.dp, horizontal = 4.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        "أسبوع محدد في شهر...",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = if (!filter.isWeeklyLast7Days) FontWeight.Bold else FontWeight.Medium,
                                        color = if (!filter.isWeeklyLast7Days) Color.White else Slate700,
                                        maxLines = 1,
                                        softWrap = false
                                    )
                                }
                            }
                        }

                        if (!filter.isWeeklyLast7Days) {
                            Spacer(Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                var monthMenuExpanded by remember { mutableStateOf(false) }
                                val currentMonthItem = availableMonths.find {
                                    it.year == filter.selectedYear && it.month == filter.selectedMonth
                                } ?: availableMonths.firstOrNull()

                                ExposedDropdownMenuBox(
                                    expanded = monthMenuExpanded,
                                    onExpandedChange = { monthMenuExpanded = it },
                                    modifier = Modifier.weight(1.3f)
                                ) {
                                    OutlinedTextField(
                                        value = currentMonthItem?.label ?: "اختر الشهر",
                                        onValueChange = {},
                                        readOnly = true,
                                        label = { Text("الشهر:", fontSize = 11.sp) },
                                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = monthMenuExpanded) },
                                        modifier = Modifier.menuAnchor().fillMaxWidth(),
                                        shape = RoundedCornerShape(8.dp),
                                        textStyle = MaterialTheme.typography.labelMedium
                                    )
                                    ExposedDropdownMenu(
                                        expanded = monthMenuExpanded,
                                        onDismissRequest = { monthMenuExpanded = false },
                                        modifier = Modifier.background(Color.White).heightIn(max = 240.dp)
                                    ) {
                                        availableMonths.forEach { mItem ->
                                            DropdownMenuItem(
                                                text = { Text(mItem.label, style = MaterialTheme.typography.bodySmall) },
                                                onClick = {
                                                    viewModel.setReportFilter(
                                                        filter.copy(
                                                            selectedYear = mItem.year,
                                                            selectedMonth = mItem.month
                                                        )
                                                    )
                                                    monthMenuExpanded = false
                                                }
                                            )
                                        }
                                    }
                                }

                                var weekMenuExpanded by remember { mutableStateOf(false) }
                                val currentWeekOpt = ReportFilterUtils.weekOptions.find {
                                    it.index == filter.selectedWeekIndex
                                } ?: ReportFilterUtils.weekOptions[0]

                                ExposedDropdownMenuBox(
                                    expanded = weekMenuExpanded,
                                    onExpandedChange = { weekMenuExpanded = it },
                                    modifier = Modifier.weight(1.4f)
                                ) {
                                    OutlinedTextField(
                                        value = currentWeekOpt.label,
                                        onValueChange = {},
                                        readOnly = true,
                                        label = { Text("الأسبوع:", fontSize = 11.sp) },
                                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = weekMenuExpanded) },
                                        modifier = Modifier.menuAnchor().fillMaxWidth(),
                                        shape = RoundedCornerShape(8.dp),
                                        textStyle = MaterialTheme.typography.labelMedium
                                    )
                                    ExposedDropdownMenu(
                                        expanded = weekMenuExpanded,
                                        onDismissRequest = { weekMenuExpanded = false },
                                        modifier = Modifier.background(Color.White)
                                    ) {
                                        ReportFilterUtils.weekOptions.forEach { wOpt ->
                                            DropdownMenuItem(
                                                text = { Text(wOpt.label, style = MaterialTheme.typography.bodySmall) },
                                                onClick = {
                                                    viewModel.setReportFilter(
                                                        filter.copy(selectedWeekIndex = wOpt.index)
                                                    )
                                                    weekMenuExpanded = false
                                                }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    } else if (filter.mode == ReportPeriodMode.MONTHLY) {
                        Spacer(Modifier.height(8.dp))
                        var monthMenuExpanded by remember { mutableStateOf(false) }
                        val currentMonthItem = availableMonths.find {
                            it.year == filter.selectedYear && it.month == filter.selectedMonth
                        } ?: availableMonths.firstOrNull()

                        ExposedDropdownMenuBox(
                            expanded = monthMenuExpanded,
                            onExpandedChange = { monthMenuExpanded = it },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            OutlinedTextField(
                                value = currentMonthItem?.label ?: "اختر الشهر المطلوب",
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("اختر الشهر لعرض بياناته:", fontSize = 11.sp) },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = monthMenuExpanded) },
                                modifier = Modifier.menuAnchor().fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp),
                                textStyle = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            ExposedDropdownMenu(
                                expanded = monthMenuExpanded,
                                onDismissRequest = { monthMenuExpanded = false },
                                modifier = Modifier.background(Color.White).heightIn(max = 240.dp)
                            ) {
                                availableMonths.forEach { mItem ->
                                    DropdownMenuItem(
                                        text = {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(Icons.Filled.CalendarToday, contentDescription = null, tint = Brand600, modifier = Modifier.size(16.dp))
                                                Spacer(Modifier.width(8.dp))
                                                Text(mItem.label, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                                            }
                                        },
                                        onClick = {
                                            viewModel.setReportFilter(
                                                filter.copy(
                                                    selectedYear = mItem.year,
                                                    selectedMonth = mItem.month
                                                )
                                            )
                                            monthMenuExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    Spacer(Modifier.height(8.dp))
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Filled.Info,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(
                                "$periodTitle - (طلاب المجموعة: ${scopedStudents.size.toString().toStandardDigits()} | الدروس: ${filteredLessons.size.toString().toStandardDigits()})",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }

            // Student Picker Dropdown
            var studentExpanded by remember { mutableStateOf(false) }
            ExposedDropdownMenuBox(
                expanded = studentExpanded,
                onExpandedChange = { studentExpanded = it },
                modifier = Modifier.padding(bottom = 10.dp)
            ) {
                OutlinedTextField(
                    value = selectedStudentName,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("اختر نوع التقرير:", style = MaterialTheme.typography.labelSmall) },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = studentExpanded) },
                    modifier = Modifier.menuAnchor().fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    textStyle = MaterialTheme.typography.bodyMedium
                )
                ExposedDropdownMenu(
                    expanded = studentExpanded,
                    onDismissRequest = { studentExpanded = false },
                    modifier = Modifier.background(Color.White).heightIn(max = 260.dp)
                ) {
                    DropdownMenuItem(
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Outlined.Groups, contentDescription = null, tint = Brand600, modifier = Modifier.size(20.dp))
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    "جميع طلبة المجموعة (${scopedStudents.size.toString().toStandardDigits()} طالب - تقرير شامل)",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                        },
                        onClick = {
                            onStudentSelect("all")
                            studentExpanded = false
                        }
                    )
                    HorizontalDivider(color = Slate200)
                    scopedStudents.sortedBy { it.fullName }.forEach { student ->
                        DropdownMenuItem(
                            text = {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                        Icon(Icons.Outlined.Person, contentDescription = null, tint = Slate400, modifier = Modifier.size(18.dp))
                                        Spacer(Modifier.width(8.dp))
                                        Text(student.fullName, style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    }
                                    val info = getDepartmentUiInfo(student.safeDepartment)
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = info.containerColor,
                                        border = BorderStroke(0.5.dp, info.borderColor)
                                    ) {
                                        Text(
                                            student.safeDepartment,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = info.textColor,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1,
                                            softWrap = false,
                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                        )
                                    }
                                }
                            },
                            onClick = {
                                onStudentSelect(student.id)
                                studentExpanded = false
                            }
                        )
                    }
                }
            }

            // Main Report Content
            if (reportStudentId == null) {
                Box(
                    Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = Slate100,
                            modifier = Modifier.size(54.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Outlined.Assessment, contentDescription = null, tint = Slate400, modifier = Modifier.size(28.dp))
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        Text(
                            "يرجى اختيار طالب أو اختيار 'جميع طلبة المجموعة'",
                            style = MaterialTheme.typography.titleMedium,
                            color = Slate700,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "لعرض سجلات الحضور والتسميع والسلوك والاختبارات لطلبة هذه المجموعة فقط",
                            style = MaterialTheme.typography.bodySmall,
                            color = Slate500,
                            textAlign = TextAlign.Center
                        )
                        Spacer(Modifier.height(12.dp))
                        Button(
                            onClick = { onStudentSelect("all") },
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Brand600)
                        ) {
                            Icon(Icons.Outlined.Groups, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("عرض التقرير الشامل للمجموعة (${scopedStudents.size.toString().toStandardDigits()} طالب)", maxLines = 1, softWrap = false)
                        }
                    }
                }
            } else if (reportStudentId == "all") {
                data class StudentReportItem(
                    val id: String,
                    val fullName: String,
                    val department: String,
                    val presentCount: Int,
                    val absentCount: Int,
                    val politeCount: Int,
                    val attendanceRate: Int,
                    val testsCount: Int
                )

                val precomputedReportItems = remember(filteredLessons, mosque.tests, scopedStudents) {
                    val lessonsByStudent = filteredLessons.flatMap { l ->
                        l.records.map { r -> r.studentId to r }
                    }.groupBy({ it.first }, { it.second })

                    val testsByStudent = mosque.tests.flatMap { t ->
                        t.allRecords(mosque).map { r -> r.studentId }
                    }.groupingBy { it }.eachCount()

                    // نأخذ طلاب هذه المجموعة فقط (scopedStudents) وليس كل طلاب البرنامج!
                    scopedStudents.map { student ->
                        val records = lessonsByStudent[student.id] ?: emptyList()
                        val present = records.count { it.attendance == "حضور" }
                        val absent = records.count { it.attendance == "غائب" }
                        val polite = records.count { it.behavior == "مؤدب" }
                        val rate = if (records.isNotEmpty()) Math.round((present.toFloat() / records.size) * 100) else 0
                        val tests = testsByStudent[student.id] ?: 0
                        StudentReportItem(
                            id = student.id,
                            fullName = student.fullName,
                            department = student.safeDepartment,
                            presentCount = present,
                            absentCount = absent,
                            politeCount = polite,
                            attendanceRate = rate,
                            testsCount = tests
                        )
                    }.sortedBy { it.fullName }
                }

                val filteredReportItems = remember(precomputedReportItems, searchQuery, selectedDepartmentFilter) {
                    precomputedReportItems.filter { item ->
                        val matchesDept = selectedDepartmentFilter == "الكل" || item.department == selectedDepartmentFilter
                        val matchesQuery = searchQuery.isBlank() || item.fullName.contains(searchQuery, ignoreCase = true)
                        matchesDept && matchesQuery
                    }
                }

                // فلتر الأقسام داخل التقرير الشامل
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp)
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val depts = listOf("الكل") + StudentDepartments.ALL
                    depts.forEach { dept ->
                        val cnt = if (dept == "الكل") precomputedReportItems.size else precomputedReportItems.count { it.department == dept }
                        if (dept == "الكل" || cnt > 0) {
                            FilterChip(
                                selected = selectedDepartmentFilter == dept,
                                onClick = { selectedDepartmentFilter = dept },
                                label = {
                                    Text(
                                        "$dept (${cnt.toString().toStandardDigits()})",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = if (selectedDepartmentFilter == dept) FontWeight.Bold else FontWeight.Normal,
                                        maxLines = 1,
                                        softWrap = false
                                    )
                                }
                            )
                        }
                    }
                }

                if (scopedStudents.size > 4) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("بحث في تقرير طلبة المجموعة...", style = MaterialTheme.typography.bodySmall, color = Slate400) },
                        singleLine = true,
                        leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null, tint = Slate400, modifier = Modifier.size(18.dp)) },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(Icons.Outlined.Clear, contentDescription = null, tint = Slate400, modifier = Modifier.size(16.dp))
                                }
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp),
                        shape = RoundedCornerShape(8.dp),
                        textStyle = MaterialTheme.typography.bodyMedium.copy(textAlign = TextAlign.Right)
                    )
                }

                // التحميل التدريجي (Progressive Loading) للتقرير الشامل
                val reportListState = rememberLazyListState()
                var visibleLimit by remember(selectedDepartmentFilter, searchQuery) { mutableStateOf(40) }
                val displayedReportItems = remember(filteredReportItems, visibleLimit) {
                    filteredReportItems.take(visibleLimit)
                }
                val shouldLoadMore by remember {
                    derivedStateOf {
                        val layoutInfo = reportListState.layoutInfo
                        val totalItems = layoutInfo.totalItemsCount
                        val lastVisible = layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
                        totalItems > 0 && lastVisible >= totalItems - 6 && visibleLimit < filteredReportItems.size
                    }
                }
                LaunchedEffect(shouldLoadMore) {
                    if (shouldLoadMore) {
                        visibleLimit += 40
                    }
                }

                LazyColumn(
                    state = reportListState,
                    contentPadding = PaddingValues(bottom = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(displayedReportItems, key = { it.id }, contentType = { "report_item" }) { item ->
                        val deptInfo = getDepartmentUiInfo(item.department)
                        Surface(
                            color = Slate50,
                            border = BorderStroke(1.dp, Slate200),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.clickable { onStudentSelect(item.id) }
                        ) {
                            Column(
                                Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp)
                            ) {
                                Row(
                                    Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.weight(1f).padding(end = 8.dp)
                                    ) {
                                        Text(
                                            item.fullName,
                                            fontWeight = FontWeight.Bold,
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = Slate900,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Spacer(Modifier.width(6.dp))
                                        Surface(
                                            shape = RoundedCornerShape(4.dp),
                                            color = deptInfo.containerColor,
                                            border = BorderStroke(0.5.dp, deptInfo.borderColor)
                                        ) {
                                            Text(
                                                item.department,
                                                style = MaterialTheme.typography.labelSmall,
                                                color = deptInfo.textColor,
                                                fontSize = 9.5.sp,
                                                fontWeight = FontWeight.Bold,
                                                maxLines = 1,
                                                softWrap = false,
                                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                                            )
                                        }
                                    }
                                    Text(
                                        "${item.attendanceRate.toString().toStandardDigits()}%",
                                        fontWeight = FontWeight.Bold,
                                        color = if (item.attendanceRate >= 80) Emerald500 else if (item.attendanceRate >= 50) Amber500 else Rose500,
                                        style = MaterialTheme.typography.titleMedium,
                                        maxLines = 1,
                                        softWrap = false
                                    )
                                }
                                Spacer(Modifier.height(6.dp))
                                Row(
                                    Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("حضور: ${item.presentCount.toString().toStandardDigits()}", style = MaterialTheme.typography.labelSmall, color = Emerald500, fontWeight = FontWeight.SemiBold, maxLines = 1, softWrap = false)
                                    Text("غياب: ${item.absentCount.toString().toStandardDigits()}", style = MaterialTheme.typography.labelSmall, color = Rose500, fontWeight = FontWeight.SemiBold, maxLines = 1, softWrap = false)
                                    if (item.politeCount > 0) {
                                        Text("🌟 ${item.politeCount.toString().toStandardDigits()}", style = MaterialTheme.typography.labelSmall, color = Emerald600, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                                    }
                                    Text("اختبارات: ${item.testsCount.toString().toStandardDigits()}", style = MaterialTheme.typography.labelSmall, color = Sky500, fontWeight = FontWeight.SemiBold, maxLines = 1, softWrap = false)
                                }
                            }
                        }
                    }
                }
            } else {
                val student = scopedStudents.find { it.id == reportStudentId }
                if (student != null) {
                    val studentLessons = remember(filteredLessons, reportStudentId) {
                        filteredLessons.mapNotNull { l ->
                            val r = l.records.find { it.studentId == reportStudentId }
                            if (r != null) Pair(l, r) else null
                        }
                    }
                    val studentTests = remember(mosque.tests, reportStudentId) {
                        mosque.tests.mapNotNull { t ->
                            val r = t.allRecords(mosque).find { it.studentId == reportStudentId }
                            if (r != null) Pair(t, r) else null
                        }.reversed()
                    }
                    val presentCount = studentLessons.count { it.second.attendance == "حضور" }
                    val politeCount = studentLessons.count { it.second.behavior == "مؤدب" }
                    val attendanceRate = if (studentLessons.isNotEmpty()) Math.round((presentCount.toFloat() / studentLessons.size) * 100) else 0
                    val rateColor = if (attendanceRate >= 80) Emerald500 else if (attendanceRate >= 50) Amber500 else Rose500

                    LazyColumn(
                        contentPadding = PaddingValues(bottom = 24.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        item {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Surface(
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(8.dp),
                                    color = Slate50,
                                    border = BorderStroke(1.dp, Slate200)
                                ) {
                                    Column(Modifier.fillMaxWidth().padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("${studentLessons.size}".toStandardDigits(), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Brand600, maxLines = 1, softWrap = false)
                                        Text("الدروس", style = MaterialTheme.typography.labelSmall, fontSize = 10.sp, color = Slate500, maxLines = 1, softWrap = false)
                                    }
                                }
                                Surface(
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(8.dp),
                                    color = Slate50,
                                    border = BorderStroke(1.dp, Slate200)
                                ) {
                                    Column(Modifier.fillMaxWidth().padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("$attendanceRate%".toStandardDigits(), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = rateColor, maxLines = 1, softWrap = false)
                                        Text("الحضور", style = MaterialTheme.typography.labelSmall, fontSize = 10.sp, color = Slate500, maxLines = 1, softWrap = false)
                                    }
                                }
                                Surface(
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(8.dp),
                                    color = Emerald50,
                                    border = BorderStroke(1.dp, Emerald200)
                                ) {
                                    Column(Modifier.fillMaxWidth().padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("$politeCount".toStandardDigits(), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Emerald600, maxLines = 1, softWrap = false)
                                        Text("مؤدب 🌟", style = MaterialTheme.typography.labelSmall, fontSize = 10.sp, color = Emerald700, maxLines = 1, softWrap = false)
                                    }
                                }
                                Surface(
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(8.dp),
                                    color = Slate50,
                                    border = BorderStroke(1.dp, Slate200)
                                ) {
                                    Column(Modifier.fillMaxWidth().padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("${studentTests.size}".toStandardDigits(), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Sky500, maxLines = 1, softWrap = false)
                                        Text("اختبارات", style = MaterialTheme.typography.labelSmall, fontSize = 10.sp, color = Slate500, maxLines = 1, softWrap = false)
                                    }
                                }
                            }
                        }

                        if (studentLessons.isNotEmpty()) {
                            item {
                                Text(
                                    "سجل الحضور والتسميع والسلوك في الفترة المحددة:",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Slate700,
                                    modifier = Modifier.padding(top = 4.dp)
                                )
                            }
                            item {
                                Surface(
                                    shape = RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp),
                                    color = Brand600,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        Modifier
                                            .fillMaxWidth()
                                            .padding(8.dp)
                                            .testTag("report_lessons_header")
                                    ) {
                                        Text("اليوم", modifier = Modifier.weight(1.1f), color = Color.White, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                                        Text("الحضور", modifier = Modifier.weight(0.9f), color = Color.White, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                                        Text("السلوك", modifier = Modifier.weight(0.9f), color = Color.White, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                                        Text("المنهج/الصفحة", modifier = Modifier.weight(1.6f), color = Color.White, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                                        Text("التقييم", modifier = Modifier.weight(0.9f), color = Color.White, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                                    }
                                }
                            }
                            items(studentLessons.reversed()) { (l, r) ->
                                Surface(
                                    color = Color.White,
                                    border = BorderStroke(0.5.dp, Slate200),
                                    shape = RoundedCornerShape(0.dp)
                                ) {
                                    Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Column(modifier = Modifier.weight(1.1f)) {
                                            Text(l.day, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.labelSmall, color = Slate900, maxLines = 1, softWrap = false)
                                            Text(l.dateStr, color = Slate400, fontSize = 9.sp, maxLines = 1, softWrap = false)
                                        }
                                        val attColor = if (r.attendance == "حضور") Emerald500 else if (r.attendance == "غائب") Rose500 else Amber500
                                        Text(r.attendance, modifier = Modifier.weight(0.9f), color = attColor, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall, maxLines = 1, softWrap = false)

                                        Box(modifier = Modifier.weight(0.9f)) {
                                            if (r.behavior == "مؤدب") {
                                                Text("🌟 مؤدب", style = MaterialTheme.typography.labelSmall, color = Emerald600, fontWeight = FontWeight.Bold, fontSize = 10.sp, maxLines = 1, softWrap = false)
                                            } else {
                                                Text("-", style = MaterialTheme.typography.labelSmall, color = Slate400)
                                            }
                                        }

                                        Column(modifier = Modifier.weight(1.6f)) {
                                            val typeText = if (!r.type.isNullOrEmpty()) r.type else "-"
                                            val pageText = if (!r.page.isNullOrEmpty()) " (${r.page})" else ""
                                            Text("$typeText$pageText", style = MaterialTheme.typography.labelSmall, color = Slate800, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                            if (!r.optTestType.isNullOrEmpty()) {
                                                Text("اختبار: ${r.optTestType}", fontSize = 9.sp, color = Sky500, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                            }
                                        }

                                        Text(r.grade ?: "-", modifier = Modifier.weight(0.9f), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold, color = Slate800, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    }
                                }
                            }
                        } else {
                            item {
                                Surface(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 16.dp),
                                    shape = RoundedCornerShape(8.dp),
                                    color = Slate50,
                                    border = BorderStroke(1.dp, Slate200)
                                ) {
                                    Box(modifier = Modifier.padding(16.dp), contentAlignment = Alignment.Center) {
                                        Text(
                                            "لا توجد دروس مسجلة لهذا الطالب في الفترة المحددة",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = Slate500
                                        )
                                    }
                                }
                            }
                        }

                        if (studentTests.isNotEmpty()) {
                            item {
                                Text(
                                    "سجل الاختبارات الخاصة:",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Slate700,
                                    modifier = Modifier.padding(top = 8.dp)
                                )
                            }
                            items(studentTests) { (test, rec) ->
                                Surface(
                                    color = Slate50,
                                    border = BorderStroke(1.dp, Slate200),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Row(
                                        Modifier
                                            .fillMaxWidth()
                                            .padding(10.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text("${test.displayDate} - ${rec.type ?: test.title ?: ""}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall, color = Slate900, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                            if (!rec.info.isNullOrEmpty()) {
                                                Text(rec.info, style = MaterialTheme.typography.labelSmall, color = Slate600, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                            }
                                        }
                                        Text(rec.grade?.ifBlank { "-" } ?: "-", fontWeight = FontWeight.Bold, color = Emerald500, style = MaterialTheme.typography.bodyMedium, maxLines = 1, softWrap = false)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
