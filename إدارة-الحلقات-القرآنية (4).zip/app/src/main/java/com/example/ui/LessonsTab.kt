package com.example.ui

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import com.example.data.Lesson
import com.example.data.LessonRecord
import com.example.data.Mosque
import com.example.data.StudentDepartments
import com.example.ui.theme.*
import com.example.utils.toStandardDigits

@Composable
fun LessonsTab(viewModel: MosqueViewModel, mosque: Mosque, openedLessonId: String?) {
    var searchQuery by remember { mutableStateOf("") }
    val context = LocalContext.current
    var lessonToDelete by remember { mutableStateOf<String?>(null) }
    var showNewLessonDialog by remember { mutableStateOf(false) }

    val scopedStudents = remember(mosque.students, mosque.name) { mosque.scopedStudents }

    if (lessonToDelete != null) {
        AlertDialog(
            onDismissRequest = { lessonToDelete = null },
            shape = RoundedCornerShape(16.dp),
            containerColor = Color.White,
            title = { Text("حذف الدرس", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) },
            text = { Text("هل أنت متأكد من حذف هذا الدرس وسجلات تسميع الطلاب المرتبطة به نهائياً؟", style = MaterialTheme.typography.bodyMedium) },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteLesson(lessonToDelete!!)
                        lessonToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Rose500),
                    shape = RoundedCornerShape(8.dp)
                ) { Text("نعم، حذف") }
            },
            dismissButton = {
                TextButton(onClick = { lessonToDelete = null }) { Text("إلغاء", color = Slate500) }
            }
        )
    }

    if (showNewLessonDialog) {
        NewLessonSectionSelectionDialog(
            mosque = mosque,
            onDismiss = { showNewLessonDialog = false },
            onConfirm = { sections ->
                showNewLessonDialog = false
                viewModel.createNewLessonWithSections(
                    selectedSections = sections,
                    onNoStudents = {
                        Toast.makeText(context, "لا يوجد طلبة مسجلين في الأقسام المحددة. يرجى تصنيف الطلبة من قسم الطلبة.", Toast.LENGTH_LONG).show()
                    }
                )
            }
        )
    }

    if (openedLessonId != null) {
        val lesson = mosque.lessons.find { it.id == openedLessonId }
        if (lesson != null) {
            LessonEditor(viewModel = viewModel, mosque = mosque, lesson = lesson)
            return
        }
    }

    val filteredLessons = remember(mosque.lessons, searchQuery) {
        mosque.lessons.reversed().filter {
            it.day.contains(searchQuery, ignoreCase = true) ||
                it.dateFull.contains(searchQuery, ignoreCase = true) ||
                it.dateStr.contains(searchQuery)
        }
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        item(key = "lessons_header", contentType = "header") {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                        Text(
                            "سجل الدروس اليومية",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Slate900,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            "${mosque.lessons.size.toString().toStandardDigits()} درس مسجل",
                            style = MaterialTheme.typography.labelSmall,
                            color = Slate500,
                            maxLines = 1,
                            softWrap = false
                        )
                    }
                    Button(
                        onClick = {
                            if (scopedStudents.isEmpty()) {
                                Toast.makeText(context, "لا يوجد طلبة في المسجد. أضف طلبة أولاً من قسم الطلبة.", Toast.LENGTH_LONG).show()
                            } else {
                                showNewLessonDialog = true
                            }
                        },
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Brand600)
                    ) {
                        Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("درس جديد", style = MaterialTheme.typography.labelLarge, maxLines = 1, softWrap = false)
                    }
                }
            }
        }

        if (mosque.lessons.size > 2) {
            item(key = "lessons_search", contentType = "search") {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("بحث باليوم أو التاريخ...", style = MaterialTheme.typography.bodySmall, color = Slate400) },
                    singleLine = true,
                    leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null, tint = Slate400, modifier = Modifier.size(18.dp)) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Outlined.Clear, contentDescription = "مسح", tint = Slate400, modifier = Modifier.size(16.dp))
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    textStyle = MaterialTheme.typography.bodyMedium.copy(textAlign = TextAlign.Right)
                )
            }
        }

        if (mosque.lessons.isEmpty()) {
            item(key = "lessons_empty", contentType = "empty") {
                Surface(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(
                        Modifier.fillMaxWidth().padding(36.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = Slate100,
                            modifier = Modifier.size(54.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Outlined.AutoStories, contentDescription = null, tint = Slate400, modifier = Modifier.size(28.dp))
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        Text("لا يوجد دروس مسجلة بعد", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, color = Slate700)
                        Spacer(Modifier.height(4.dp))
                        Text("اضغط على 'درس جديد' في الأعلى لبدء حلقة اليوم والتسميع", style = MaterialTheme.typography.bodySmall, color = Slate500)
                    }
                }
            }
        } else {
            items(filteredLessons, key = { it.id }, contentType = { "lesson_row" }) { lesson ->
                LessonListItem(
                    lesson = lesson,
                    onOpen = { viewModel.openLesson(lesson.id) },
                    onPdf = { viewModel.generatePdf(context, mosque, "LESSONS", lesson.id, null) },
                    onShareWhatsApp = { viewModel.shareWhatsApp(context, mosque, "LESSONS", lesson.id, null, null) },
                    onShareImage = { viewModel.shareAsImage(context, mosque, "LESSONS", lesson.id, null, null) },
                    onDelete = { lessonToDelete = lesson.id }
                )
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun LessonListItem(
    lesson: Lesson,
    onOpen: () -> Unit,
    onPdf: () -> Unit,
    onShareWhatsApp: () -> Unit,
    onShareImage: () -> Unit,
    onDelete: () -> Unit
) {
    val counts = remember(lesson.records) {
        Triple(
            lesson.records.count { it.attendance == "حضور" },
            lesson.records.count { it.attendance == "إذن" },
            lesson.records.count { it.attendance == "غائب" }
        )
    }
    val present = counts.first
    val excused = counts.second
    val absent = counts.third

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onOpen() },
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = lesson.day,
                        color = Brand700,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.labelMedium,
                        maxLines = 1,
                        softWrap = false,
                        modifier = Modifier
                            .background(Brand50, RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = lesson.dateStr.ifBlank { lesson.dateFull },
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Slate900,
                        maxLines = 1,
                        softWrap = false,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(Modifier.width(8.dp))
                    Surface(
                        color = Slate100,
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            "${lesson.records.size.toString().toStandardDigits()} طالب",
                            color = Slate600,
                            style = MaterialTheme.typography.labelSmall,
                            maxLines = 1,
                            softWrap = false,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("حضور: ${present.toString().toStandardDigits()}", color = Emerald500, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold, maxLines = 1, softWrap = false)
                    if (excused > 0) Text("إذن: ${excused.toString().toStandardDigits()}", color = Amber500, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold, maxLines = 1, softWrap = false)
                    if (absent > 0) Text("غائب: ${absent.toString().toStandardDigits()}", color = Rose500, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold, maxLines = 1, softWrap = false)
                }
                if (lesson.safeSections.isNotEmpty()) {
                    Spacer(Modifier.height(6.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        lesson.safeSections.forEach { sec ->
                            val info = getDepartmentUiInfo(sec)
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = info.containerColor,
                                border = BorderStroke(0.5.dp, info.borderColor)
                            ) {
                                Text(
                                    sec,
                                    color = info.textColor,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp,
                                    maxLines = 1,
                                    softWrap = false,
                                    modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                                )
                            }
                        }
                    }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                IconButton(onClick = onPdf, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Outlined.PictureAsPdf, contentDescription = "PDF", tint = Rose500, modifier = Modifier.size(18.dp))
                }
                IconButton(onClick = onShareImage, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Outlined.Image, contentDescription = "صورة", tint = Brand600, modifier = Modifier.size(18.dp))
                }
                IconButton(onClick = onShareWhatsApp, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Outlined.Share, contentDescription = "واتساب", tint = Emerald600, modifier = Modifier.size(18.dp))
                }
                IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Outlined.DeleteOutline, contentDescription = "حذف الدرس", tint = Rose500, modifier = Modifier.size(18.dp))
                }
            }
        }
    }
}

@Composable
fun LessonEditor(viewModel: MosqueViewModel, mosque: Mosque, lesson: Lesson) {
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current
    var studentSearchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf("الكل") }
    var selectedDepartmentFilter by remember { mutableStateOf("الكل") }
    var showAddSectionDialog by remember { mutableStateOf(false) }

    val scopedStudents = remember(mosque.students, mosque.name) { mosque.scopedStudents }
    var localRecords by remember(lesson.id, lesson.records.size) { mutableStateOf(lesson.records) }
    var hasUnsavedChanges by remember { mutableStateOf(false) }
    val coroutineScope = rememberCoroutineScope()
    var debounceSaveJob by remember { mutableStateOf<Job?>(null) }

    val performSave: (Boolean) -> Unit = { shouldClose ->
        focusManager.clearFocus()
        debounceSaveJob?.cancel()
        viewModel.updateAllLessonRecords(lesson.id, localRecords)
        viewModel.flushSaveNow()
        hasUnsavedChanges = false
        if (shouldClose) {
            viewModel.closeLesson()
        }
    }

    val currentRecordsState = rememberUpdatedState(localRecords)
    DisposableEffect(lesson.id) {
        onDispose { viewModel.updateAllLessonRecords(lesson.id, currentRecordsState.value) }
    }
    val onRecordUpdate: (LessonRecord) -> Unit = remember(lesson.id) {
        { updatedRecord ->
            val newRecords = currentRecordsState.value.map { if (it.studentId == updatedRecord.studentId) updatedRecord else it }
            localRecords = newRecords
            hasUnsavedChanges = true
            debounceSaveJob?.cancel()
            debounceSaveJob = coroutineScope.launch {
                delay(250)
                viewModel.updateAllLessonRecords(lesson.id, newRecords)
            }
        }
    }

    val presentDepartments by remember {
        derivedStateOf {
            val depts = localRecords.mapNotNull { rec ->
                rec.studentDepartment?.takeIf { it.isNotBlank() }
                    ?: scopedStudents.find { it.id == rec.studentId }?.safeDepartment
            }.distinct()
            if (depts.isNotEmpty()) depts else lesson.safeSections
        }
    }

    val presentCount by remember { derivedStateOf { localRecords.count { it.attendance == "حضور" } } }
    val absentCount by remember { derivedStateOf { localRecords.count { it.attendance == "غائب" } } }
    val excusedCount by remember { derivedStateOf { localRecords.count { it.attendance == "إذن" } } }
    val fullMarksCount by remember { derivedStateOf { localRecords.count { (it.grade ?: "").contains("100") || (it.grade ?: "").contains("ممتاز") } } }
    val recitedCount by remember { derivedStateOf { localRecords.count { it.attendance == "حضور" && !it.page.isNullOrBlank() } } }

    val filteredRecords by remember {
        derivedStateOf {
            localRecords.filter { record ->
                val matchesQuery = studentSearchQuery.isEmpty() || record.studentName.contains(studentSearchQuery, ignoreCase = true)
                val matchesFilter = when (selectedFilter) {
                    "لم يُسمّع" -> record.attendance == "حضور" && record.page.isNullOrBlank()
                    "تم التسميع" -> record.attendance == "حضور" && !record.page.isNullOrBlank()
                    "حضور" -> record.attendance == "حضور"
                    "غائب" -> record.attendance == "غائب"
                    "إذن" -> record.attendance == "إذن"
                    else -> true
                }
                val recDept = record.studentDepartment?.takeIf { it.isNotBlank() }
                    ?: scopedStudents.find { it.id == record.studentId }?.safeDepartment ?: ""
                val matchesDept = selectedDepartmentFilter == "الكل" || recDept == selectedDepartmentFilter
                matchesQuery && matchesFilter && matchesDept
            }
        }
    }

    // التحميل التدريجي (Progressive Loading) لسلاسة التمرير
    val listState = rememberLazyListState()
    var visibleLimit by remember(selectedFilter, selectedDepartmentFilter, studentSearchQuery) { mutableStateOf(30) }
    val displayedRecords = remember(filteredRecords, visibleLimit) {
        filteredRecords.take(visibleLimit)
    }
    val shouldLoadMore by remember {
        derivedStateOf {
            val layoutInfo = listState.layoutInfo
            val totalItems = layoutInfo.totalItemsCount
            val lastVisible = layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
            totalItems > 0 && lastVisible >= totalItems - 6 && visibleLimit < filteredRecords.size
        }
    }
    LaunchedEffect(shouldLoadMore) {
        if (shouldLoadMore) {
            visibleLimit += 30
        }
    }

    if (showAddSectionDialog) {
        val availableToAdd = StudentDepartments.ALL.filter { !presentDepartments.contains(it) }
        AlertDialog(
            onDismissRequest = { showAddSectionDialog = false },
            shape = RoundedCornerShape(16.dp),
            containerColor = Color.White,
            title = {
                Text("إضافة قسم آخر لهذا الدرس", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            },
            text = {
                if (availableToAdd.isEmpty()) {
                    Text("جميع الأقسام الأربعة مضافة بالفعل في هذا الدرس.", style = MaterialTheme.typography.bodyMedium, color = Slate600)
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("اختر قسماً لتحميل طلبته إلى هذا الدرس الحالي:", style = MaterialTheme.typography.bodySmall, color = Slate600)
                        availableToAdd.forEach { dept ->
                            val info = getDepartmentUiInfo(dept)
                            val count = scopedStudents.count { it.safeDepartment == dept }
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        viewModel.addDepartmentStudentsToLesson(lesson.id, dept)
                                        showAddSectionDialog = false
                                        Toast.makeText(context, "تمت إضافة طلاب $dept إلى الدرس", Toast.LENGTH_SHORT).show()
                                    },
                                shape = RoundedCornerShape(10.dp),
                                color = info.containerColor,
                                border = BorderStroke(1.dp, info.borderColor)
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(info.icon, contentDescription = null, tint = info.textColor, modifier = Modifier.size(18.dp))
                                        Spacer(Modifier.width(8.dp))
                                        Text(dept, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = info.textColor)
                                    }
                                    Text("${count.toString().toStandardDigits()} طالب", style = MaterialTheme.typography.labelSmall, color = Slate600)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showAddSectionDialog = false }) { Text("إغلاق", color = Slate500) }
            }
        )
    }

    LazyColumn(
        state = listState,
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // 1. الأزرار في الأعلى مثل صفحة الجزء (السجل) تماماً!
        item(key = "lesson_top_action_card", contentType = "top_action_card") {
            UnifiedTopActionCard(
                title = "تسجيل الدرس اليومي",
                subtitle = "${lesson.day} - ${lesson.dateStr}",
                icon = Icons.Filled.AutoStories,
                onBackClick = { performSave(true) },
                onSaveClick = {
                    performSave(false)
                    Toast.makeText(context, "تم حفظ بيانات الدرس بنجاح ✓", Toast.LENGTH_SHORT).show()
                },
                saveButtonText = if (hasUnsavedChanges) "حفظ التعديل" else "حفظ",
                hasUnsavedChanges = hasUnsavedChanges,
                primaryActionText = "إضافة قسم",
                primaryActionIcon = Icons.Filled.GroupAdd,
                onPrimaryActionClick = { showAddSectionDialog = true },
                onWhatsAppClick = {
                    performSave(false)
                    viewModel.shareWhatsApp(context, mosque, "LESSONS", lesson.id, null, null)
                },
                onPdfClick = {
                    performSave(false)
                    viewModel.generatePdf(context, mosque, "LESSONS", lesson.id, null)
                },
                onImageClick = {
                    performSave(false)
                    viewModel.shareAsImage(context, mosque, "LESSONS", lesson.id, null, null)
                }
            )
        }

        // 2. شريط الإحصائيات والفلترة
        item(key = "lesson_editor_stats_and_filters", contentType = "filters") {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(Modifier.padding(12.dp)) {
                    // Stats & Quick Summary Bar
                    Surface(
                        color = Slate50,
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(0.5.dp, Slate200)
                    ) {
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("حضور: ${presentCount.toString().toStandardDigits()}", color = Emerald600, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                                Text("غياب: ${absentCount.toString().toStandardDigits()}", color = Rose500, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                                if (excusedCount > 0) Text("إذن: ${excusedCount.toString().toStandardDigits()}", color = Amber500, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                            }
                            Text("💯 ممتاز: ${fullMarksCount.toString().toStandardDigits()}", color = Brand700, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                        }
                    }

                    // Recitation Progress Bar
                    val progressRatio = if (presentCount > 0) (recitedCount.toFloat() / presentCount) else 0f
                    val progressPercent = Math.round(progressRatio * 100)
                    Spacer(Modifier.height(6.dp))
                    Surface(
                        color = Brand50.copy(alpha = 0.6f),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(0.5.dp, Brand200),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) {
                            Row(
                                Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Outlined.CheckCircle, contentDescription = null, tint = Emerald600, modifier = Modifier.size(15.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text(
                                        "إنجاز التسميع: ${recitedCount.toString().toStandardDigits()} من ${presentCount.toString().toStandardDigits()} طالباً",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = Brand900,
                                        maxLines = 1,
                                        softWrap = false
                                    )
                                }
                                Text("${progressPercent.toString().toStandardDigits()}%", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = Brand700, maxLines = 1, softWrap = false)
                            }
                            Spacer(Modifier.height(4.dp))
                            LinearProgressIndicator(
                                progress = { progressRatio },
                                modifier = Modifier.fillMaxWidth().height(4.dp),
                                color = Emerald600,
                                trackColor = Slate200,
                                strokeCap = androidx.compose.ui.graphics.StrokeCap.Round
                            )
                        }
                    }

                    // Department Filter Chips inside Lesson
                    if (presentDepartments.size > 1) {
                        Spacer(Modifier.height(8.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            FilterChip(
                                selected = selectedDepartmentFilter == "الكل",
                                onClick = { selectedDepartmentFilter = "الكل" },
                                label = { Text("جميع الأقسام (${localRecords.size.toString().toStandardDigits()})", style = MaterialTheme.typography.labelSmall, maxLines = 1, softWrap = false) }
                            )
                            presentDepartments.forEach { dept ->
                                val count = localRecords.count {
                                    val d = it.studentDepartment?.takeIf { s -> s.isNotBlank() }
                                        ?: scopedStudents.find { s -> s.id == it.studentId }?.safeDepartment ?: ""
                                    d == dept
                                }
                                val info = getDepartmentUiInfo(dept)
                                FilterChip(
                                    selected = selectedDepartmentFilter == dept,
                                    onClick = { selectedDepartmentFilter = dept },
                                    label = { Text("$dept (${count.toString().toStandardDigits()})", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false) },
                                    leadingIcon = {
                                        Icon(info.icon, contentDescription = null, tint = if (selectedDepartmentFilter == dept) info.textColor else Slate500, modifier = Modifier.size(13.dp))
                                    },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = info.containerColor,
                                        selectedLabelColor = info.textColor
                                    )
                                )
                            }
                        }
                    }

                    Spacer(Modifier.height(8.dp))

                    // Attendance & Recitation Filter Chips
                    LazyRow(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        val filterList = listOf("الكل", "لم يُسمّع", "تم التسميع", "حضور", "غائب", "إذن")
                        items(filterList) { filterOpt ->
                            val isSelected = selectedFilter == filterOpt
                            FilterChip(
                                selected = isSelected,
                                onClick = { selectedFilter = filterOpt },
                                label = { Text(filterOpt, style = MaterialTheme.typography.labelSmall, maxLines = 1, softWrap = false) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = if (filterOpt == "لم يُسمّع") Amber500 else if (filterOpt == "تم التسميع") Emerald600 else Brand600,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }

                    if (localRecords.size > 3) {
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(
                            value = studentSearchQuery,
                            onValueChange = { studentSearchQuery = it },
                            placeholder = { Text("بحث عن اسم طالب في الدرس...", style = MaterialTheme.typography.bodySmall, color = Slate400) },
                            singleLine = true,
                            leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = "بحث", tint = Slate400, modifier = Modifier.size(18.dp)) },
                            trailingIcon = {
                                if (studentSearchQuery.isNotEmpty()) {
                                    IconButton(onClick = { studentSearchQuery = "" }) {
                                        Icon(Icons.Outlined.Clear, contentDescription = null, tint = Slate400, modifier = Modifier.size(16.dp))
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp),
                            textStyle = MaterialTheme.typography.bodyMedium.copy(textAlign = TextAlign.Right)
                        )
                    }
                }
            }
        }

        if (filteredRecords.isEmpty()) {
            item(key = "empty_filtered_records", contentType = "empty") {
                Text(
                    "لا يوجد طلبة يطابقون الفلتر المحدد.",
                    color = Slate500,
                    modifier = Modifier.fillMaxWidth().padding(24.dp),
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        } else {
            items(displayedRecords, key = { it.studentId }, contentType = { "lesson_record" }) { record ->
                LessonRecordItem(
                    record = record,
                    onUpdate = onRecordUpdate
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LessonRecordItem(
    record: LessonRecord,
    onUpdate: (LessonRecord) -> Unit
) {
    val isPresent = record.attendance == "حضور"
    val isAbsent = record.attendance == "غائب"
    val isExcused = record.attendance == "إذن"

    var localPage by remember(record.studentId, record.page) {
        mutableStateOf(record.page ?: "")
    }

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        color = when {
            isPresent -> Color.White
            isAbsent -> Rose50.copy(alpha = 0.5f)
            else -> Amber50.copy(alpha = 0.5f)
        },
        border = BorderStroke(
            1.dp,
            when {
                isPresent -> Slate200
                isAbsent -> Rose500.copy(alpha = 0.4f)
                else -> Amber500.copy(alpha = 0.4f)
            }
        )
    ) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            // Row 1: Student Name (strictly horizontal, no vertical mosque name wrapping!) & Attendance Chips
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .weight(1f)
                        .padding(end = 6.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = Brand50,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Outlined.Person, contentDescription = null, tint = Brand600, modifier = Modifier.size(16.dp))
                        }
                    }
                    Spacer(Modifier.width(8.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            record.studentName,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium,
                            color = Slate900,
                            maxLines = 1,
                            softWrap = false,
                            overflow = TextOverflow.Ellipsis
                        )
                        val dept = record.studentDepartment?.takeIf { it.isNotBlank() } ?: ""
                        if (dept.isNotBlank()) {
                            val info = getDepartmentUiInfo(dept)
                            Spacer(Modifier.height(2.dp))
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = info.containerColor,
                                border = BorderStroke(0.5.dp, info.borderColor)
                            ) {
                                Text(
                                    dept,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = info.textColor,
                                    fontSize = 9.5.sp,
                                    maxLines = 1,
                                    softWrap = false,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.dp)
                                )
                            }
                        }
                    }
                }

                // Attendance Chips
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    LightChip(
                        selected = isPresent,
                        text = "حضور",
                        selectedColor = Emerald600,
                        onClick = { onUpdate(record.copy(attendance = "حضور")) }
                    )
                    LightChip(
                        selected = isAbsent,
                        text = "غياب",
                        selectedColor = Rose500,
                        onClick = {
                            localPage = ""
                            onUpdate(
                                record.copy(
                                    attendance = "غائب",
                                    type = "",
                                    page = "",
                                    grade = "",
                                    behavior = "",
                                    optTestType = null,
                                    optTestInfo = null
                                )
                            )
                        }
                    )
                    LightChip(
                        selected = isExcused,
                        text = "إذن",
                        selectedColor = Amber500,
                        onClick = {
                            localPage = ""
                            onUpdate(
                                record.copy(
                                    attendance = "إذن",
                                    type = "",
                                    page = "",
                                    grade = "",
                                    behavior = "",
                                    optTestType = null,
                                    optTestInfo = null
                                )
                            )
                        }
                    )
                }
            }

            if (isPresent) {
                HorizontalDivider(color = Slate100, thickness = 0.5.dp)

                // Row 2: Curriculum Dropdown & Page/Ayat Input
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    var typeExpanded by remember { mutableStateOf(false) }
                    val currentType = if (record.type.isNullOrBlank()) "-" else record.type
                    val isTypeSelected = currentType != "-"

                    Box(modifier = Modifier.weight(1.1f)) {
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { typeExpanded = true },
                            shape = RoundedCornerShape(8.dp),
                            color = Slate50,
                            border = BorderStroke(1.dp, if (isTypeSelected) Brand300 else Slate300)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 7.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    currentType,
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = if (isTypeSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isTypeSelected) Brand700 else Slate500,
                                    maxLines = 1,
                                    softWrap = false,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Icon(Icons.Filled.ArrowDropDown, contentDescription = null, tint = Slate500, modifier = Modifier.size(18.dp))
                            }
                        }

                        if (typeExpanded) {
                            DropdownMenu(
                                expanded = typeExpanded,
                                onDismissRequest = { typeExpanded = false },
                                modifier = Modifier.background(Color.White)
                            ) {
                                listOf("تلاوة", "رشيدي", "قرآن غيباً", "تجويد").forEach { t ->
                                    DropdownMenuItem(
                                        text = { Text(t, style = MaterialTheme.typography.bodyMedium) },
                                        onClick = {
                                            onUpdate(record.copy(type = t))
                                            typeExpanded = false
                                        }
                                    )
                                }
                                if (isTypeSelected) {
                                    HorizontalDivider(color = Slate200)
                                    DropdownMenuItem(
                                        text = { Text("إلغاء التحديد (-)", style = MaterialTheme.typography.bodySmall, color = Slate500) },
                                        onClick = {
                                            onUpdate(record.copy(type = ""))
                                            typeExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    // Page / Surah / Verses TextField
                    LightTextField(
                        value = localPage,
                        onValueChange = { newVal ->
                            val clean = newVal.toStandardDigits()
                            localPage = clean
                            onUpdate(record.copy(page = clean))
                        },
                        placeholder = "الصفحة / الجزء / الآيات...",
                        modifier = Modifier.weight(1.9f),
                        trailing = {
                            val num = localPage.toIntOrNull()
                            if (num != null) {
                                Box(
                                    Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(Brand50)
                                        .border(0.5.dp, Brand200, RoundedCornerShape(4.dp))
                                        .clickable {
                                            val next = (num + 1).toString()
                                            localPage = next
                                            onUpdate(record.copy(page = next))
                                        }
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text("+1", style = MaterialTheme.typography.labelSmall, color = Brand700, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                                }
                            }
                        }
                    )
                }

                // Row 3: Grade Selector Dropdown & Behavior Toggle
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    var gradeExpanded by remember { mutableStateOf(false) }
                    val currentGrade = if (record.grade.isNullOrBlank()) "-" else record.grade
                    val isGradeSelected = currentGrade != "-"

                    Box(modifier = Modifier.weight(1.7f)) {
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { gradeExpanded = true },
                            shape = RoundedCornerShape(8.dp),
                            color = when {
                                currentGrade.contains("100") || currentGrade.contains("ممتاز") -> Emerald50
                                isGradeSelected -> Brand50
                                else -> Slate50
                            },
                            border = BorderStroke(
                                1.dp,
                                when {
                                    currentGrade.contains("100") || currentGrade.contains("ممتاز") -> Emerald600
                                    isGradeSelected -> Brand300
                                    else -> Slate300
                                }
                            )
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 7.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    currentGrade,
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = if (isGradeSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = when {
                                        currentGrade.contains("100") || currentGrade.contains("ممتاز") -> Emerald700
                                        isGradeSelected -> Brand700
                                        else -> Slate500
                                    },
                                    maxLines = 1,
                                    softWrap = false
                                )
                                Icon(Icons.Filled.ArrowDropDown, contentDescription = null, tint = Slate500, modifier = Modifier.size(18.dp))
                            }
                        }

                        if (gradeExpanded) {
                            DropdownMenu(
                                expanded = gradeExpanded,
                                onDismissRequest = { gradeExpanded = false },
                                modifier = Modifier.background(Color.White)
                            ) {
                                listOf("ممتاز 100", "ممتاز 95", "ممتاز", "جيد جداً 85", "جيد جداً", "جيد 75", "مقبول 60", "ضعيف", "إعادة").forEach { g ->
                                    DropdownMenuItem(
                                        text = { Text(g, style = MaterialTheme.typography.bodyMedium) },
                                        onClick = {
                                            onUpdate(record.copy(grade = g))
                                            gradeExpanded = false
                                        }
                                    )
                                }
                                if (isGradeSelected) {
                                    HorizontalDivider(color = Slate200)
                                    DropdownMenuItem(
                                        text = { Text("إلغاء التحديد (-)", style = MaterialTheme.typography.bodySmall, color = Slate500) },
                                        onClick = {
                                            onUpdate(record.copy(grade = ""))
                                            gradeExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    // Behavior Selector
                    var behaviorExpanded by remember { mutableStateOf(false) }
                    val currentBehavior = record.behavior ?: ""
                    val behaviorLabel = when (currentBehavior) {
                        "مؤدب" -> "🌟 مؤدب"
                        "يحتاج هدوء" -> "يحتاج هدوء"
                        else -> "+ السلوك"
                    }
                    val isBehaviorActive = currentBehavior.isNotEmpty()

                    Box(modifier = Modifier.weight(1.3f)) {
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { behaviorExpanded = true },
                            shape = RoundedCornerShape(8.dp),
                            color = when (currentBehavior) {
                                "مؤدب" -> Emerald50
                                "يحتاج هدوء" -> Amber50
                                else -> Slate50
                            },
                            border = BorderStroke(
                                1.dp,
                                when (currentBehavior) {
                                    "مؤدب" -> Emerald600
                                    "يحتاج هدوء" -> Amber600
                                    else -> Slate300
                                }
                            )
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 7.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    behaviorLabel,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = if (isBehaviorActive) FontWeight.Bold else FontWeight.Normal,
                                    color = when (currentBehavior) {
                                        "مؤدب" -> Emerald700
                                        "يحتاج هدوء" -> Amber700
                                        else -> Slate700
                                    },
                                    maxLines = 1,
                                    softWrap = false
                                )
                                Icon(Icons.Filled.ArrowDropDown, contentDescription = null, tint = Slate500, modifier = Modifier.size(16.dp))
                            }
                        }

                        if (behaviorExpanded) {
                            DropdownMenu(
                                expanded = behaviorExpanded,
                                onDismissRequest = { behaviorExpanded = false },
                                modifier = Modifier.background(Color.White)
                            ) {
                                DropdownMenuItem(
                                    text = {
                                        Text("🌟 مؤدب", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = Emerald700)
                                    },
                                    onClick = {
                                        onUpdate(record.copy(behavior = if (currentBehavior == "مؤدب") "" else "مؤدب"))
                                        behaviorExpanded = false
                                    }
                                )
                                DropdownMenuItem(
                                    text = {
                                        Text("يحتاج هدوء", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = Amber700)
                                    },
                                    onClick = {
                                        onUpdate(record.copy(behavior = if (currentBehavior == "يحتاج هدوء") "" else "يحتاج هدوء"))
                                        behaviorExpanded = false
                                    }
                                )
                                if (isBehaviorActive) {
                                    HorizontalDivider(color = Slate200)
                                    DropdownMenuItem(
                                        text = { Text("إلغاء التحديد", style = MaterialTheme.typography.bodySmall, color = Slate500) },
                                        onClick = {
                                            onUpdate(record.copy(behavior = ""))
                                            behaviorExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun NewLessonSectionSelectionDialog(
    mosque: Mosque,
    onDismiss: () -> Unit,
    onConfirm: (List<String>) -> Unit
) {
    var selectedSections by remember { mutableStateOf<Set<String>>(emptySet()) }
    val context = LocalContext.current
    val scopedStudents = remember(mosque.students, mosque.name) { mosque.scopedStudents }

    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(16.dp),
        containerColor = Color.White,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Brand50,
                    modifier = Modifier.size(36.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(Icons.Outlined.AutoStories, contentDescription = null, tint = Brand600, modifier = Modifier.size(20.dp))
                    }
                }
                Spacer(Modifier.width(10.dp))
                Column {
                    Text("إضافة درس جديد", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Slate900)
                    Text("تحديد الأقسام وتحميل أسماء الطلبة تلقائياً", style = MaterialTheme.typography.labelSmall, color = Slate500)
                }
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    "انقر على أي قسم لفتح الدرس وتحميل طلبته فوراً، أو حدد عدة أقسام:",
                    style = MaterialTheme.typography.bodySmall,
                    color = Slate700
                )

                StudentDepartments.ALL.forEach { dept ->
                    val studentCount = scopedStudents.count { it.safeDepartment == dept }
                    val isChecked = selectedSections.contains(dept)
                    val info = getDepartmentUiInfo(dept)

                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                selectedSections = if (isChecked) selectedSections - dept else selectedSections + dept
                            },
                        shape = RoundedCornerShape(12.dp),
                        color = if (isChecked) info.containerColor else Slate50,
                        border = BorderStroke(
                            if (isChecked) 1.5.dp else 1.dp,
                            if (isChecked) info.borderColor else Slate200
                        )
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Checkbox(
                                    checked = isChecked,
                                    onCheckedChange = { checked ->
                                        selectedSections = if (checked) selectedSections + dept else selectedSections - dept
                                    },
                                    colors = CheckboxDefaults.colors(
                                        checkedColor = info.textColor,
                                        checkmarkColor = Color.White
                                    ),
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(Modifier.width(8.dp))
                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(info.icon, contentDescription = null, tint = info.textColor, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text(
                                            dept,
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isChecked) info.textColor else Slate900,
                                            maxLines = 1,
                                            softWrap = false
                                        )
                                    }
                                    Text(
                                        "${studentCount.toString().toStandardDigits()} طالب مسجل",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (studentCount > 0) Slate600 else Rose500,
                                        maxLines = 1,
                                        softWrap = false
                                    )
                                }
                            }

                            Button(
                                onClick = {
                                    if (studentCount == 0) {
                                        Toast.makeText(context, "لا يوجد طلاب مسجلين في $dept حالياً", Toast.LENGTH_SHORT).show()
                                    } else {
                                        onConfirm(listOf(dept))
                                    }
                                },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isChecked) info.textColor else Brand600
                                ),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                modifier = Modifier.height(32.dp)
                            ) {
                                Text("فتح فوري", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                            }
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(
                        onClick = {
                            selectedSections = if (selectedSections.size == StudentDepartments.ALL.size) emptySet() else StudentDepartments.ALL.toSet()
                        }
                    ) {
                        Text(
                            if (selectedSections.size == StudentDepartments.ALL.size) "إلغاء تحديد الكل" else "تحديد جميع الأقسام",
                            style = MaterialTheme.typography.labelMedium,
                            color = Brand700,
                            maxLines = 1,
                            softWrap = false
                        )
                    }

                    val totalSelectedStudents = scopedStudents.count { selectedSections.contains(it.safeDepartment) }
                    Text(
                        "الطلبة المحددون: ${totalSelectedStudents.toString().toStandardDigits()}",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = Slate700,
                        maxLines = 1,
                        softWrap = false
                    )
                }
            }
        },
        confirmButton = {
            val totalSelectedStudents = scopedStudents.count { selectedSections.contains(it.safeDepartment) }
            Button(
                onClick = {
                    if (selectedSections.isEmpty()) {
                        Toast.makeText(context, "يرجى تحديد قسم واحد على الأقل أو الضغط على فتح فوري", Toast.LENGTH_SHORT).show()
                    } else if (totalSelectedStudents == 0) {
                        Toast.makeText(context, "الأقسام المحددة لا تحتوي على طلبة مسجلين", Toast.LENGTH_SHORT).show()
                    } else {
                        onConfirm(selectedSections.toList())
                    }
                },
                enabled = selectedSections.isNotEmpty(),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Brand600)
            ) {
                Text(
                    "بدء الدرس (${totalSelectedStudents.toString().toStandardDigits()} طالب)",
                    maxLines = 1,
                    softWrap = false
                )
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء", color = Slate500)
            }
        }
    )
}
