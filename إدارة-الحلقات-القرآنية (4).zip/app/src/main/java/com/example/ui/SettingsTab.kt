package com.example.ui

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Mosque
import com.example.data.Student
import com.example.data.StudentDepartments
import com.example.ui.theme.*
import com.example.utils.toStandardDigits

data class DepartmentUiInfo(
    val title: String,
    val containerColor: Color,
    val textColor: Color,
    val borderColor: Color,
    val icon: androidx.compose.ui.graphics.vector.ImageVector
)

fun getDepartmentUiInfo(dept: String): DepartmentUiInfo {
    return when (StudentDepartments.normalize(dept)) {
        StudentDepartments.RASHIDI -> DepartmentUiInfo(
            title = StudentDepartments.RASHIDI,
            containerColor = Amber50,
            textColor = Color(0xFFB45309),
            borderColor = Amber500.copy(alpha = 0.5f),
            icon = Icons.Outlined.AutoStories
        )
        StudentDepartments.QURAN_GHAIBAN -> DepartmentUiInfo(
            title = StudentDepartments.QURAN_GHAIBAN,
            containerColor = Color(0xFFF0F9FF),
            textColor = Color(0xFF0369A1),
            borderColor = Color(0xFF38BDF8).copy(alpha = 0.5f),
            icon = Icons.Outlined.Psychology
        )
        StudentDepartments.TAJWEED -> DepartmentUiInfo(
            title = StudentDepartments.TAJWEED,
            containerColor = Color(0xFFFAF5FF),
            textColor = Color(0xFF7E22CE),
            borderColor = Color(0xFFA855F7).copy(alpha = 0.5f),
            icon = Icons.Outlined.GraphicEq
        )
        else -> DepartmentUiInfo(
            title = StudentDepartments.TILAWA,
            containerColor = Emerald50,
            textColor = Color(0xFF047857),
            borderColor = Emerald500.copy(alpha = 0.5f),
            icon = Icons.Outlined.MenuBook
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsTab(viewModel: MosqueViewModel, mosque: Mosque) {
    var newStudentName by remember { mutableStateOf("") }
    var newStudentDepartment by remember { mutableStateOf(StudentDepartments.TILAWA) }
    var searchQuery by remember { mutableStateOf("") }
    var selectedDepartmentFilter by remember { mutableStateOf("الكل") }
    val context = LocalContext.current

    var showDuplicateWarning by remember { mutableStateOf<String?>(null) }
    var showEditPrompt by remember { mutableStateOf<String?>(null) }
    var editStudentName by remember { mutableStateOf("") }
    var editStudentDepartment by remember { mutableStateOf(StudentDepartments.TILAWA) }
    var studentToDelete by remember { mutableStateOf<String?>(null) }
    var viewingStudentDetail by remember { mutableStateOf<Student?>(null) }
    var changingDepartmentForStudent by remember { mutableStateOf<Student?>(null) }
    var showBulkAddDialog by remember { mutableStateOf(false) }

    val scopedStudents = remember(mosque.students, mosque.name) { mosque.scopedStudents }

    if (showBulkAddDialog) {
        var bulkNamesText by remember { mutableStateOf("") }
        var bulkDept by remember { mutableStateOf(newStudentDepartment) }
        AlertDialog(
            onDismissRequest = { showBulkAddDialog = false },
            shape = RoundedCornerShape(16.dp),
            containerColor = Color.White,
            title = {
                Text("إضافة متعددة سريعة للطلاب", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("أدخل أسماء الطلاب (كل اسم في سطر مستقل):", style = MaterialTheme.typography.bodySmall, color = Slate600)
                    OutlinedTextField(
                        value = bulkNamesText,
                        onValueChange = { bulkNamesText = it },
                        placeholder = { Text("محمد أحمد\nخالد محمود\nعبدالله سعيد", fontSize = 12.sp) },
                        modifier = Modifier.fillMaxWidth().height(130.dp),
                        shape = RoundedCornerShape(10.dp)
                    )
                    Text("القسم:", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = Slate700)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        StudentDepartments.ALL.forEach { dept ->
                            val isSelected = bulkDept == dept
                            val info = getDepartmentUiInfo(dept)
                            Surface(
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { bulkDept = dept },
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSelected) info.containerColor else Slate100,
                                border = BorderStroke(if (isSelected) 1.5.dp else 0.5.dp, if (isSelected) info.borderColor else Slate300)
                            ) {
                                Text(
                                    dept.replace("قسم ", ""),
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) info.textColor else Slate700,
                                    textAlign = TextAlign.Center,
                                    maxLines = 1,
                                    softWrap = false,
                                    modifier = Modifier.padding(vertical = 6.dp, horizontal = 2.dp)
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val lines = bulkNamesText.lines().map { it.trim() }.filter { it.isNotBlank() }
                        if (lines.isNotEmpty()) {
                            viewModel.bulkAddStudents(lines, bulkDept) { count ->
                                Toast.makeText(context, "تمت إضافة $count طالب بنجاح ✓", Toast.LENGTH_SHORT).show()
                            }
                            showBulkAddDialog = false
                        }
                    },
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Brand600)
                ) {
                    Text("إضافة الجميع", maxLines = 1, softWrap = false)
                }
            },
            dismissButton = {
                TextButton(onClick = { showBulkAddDialog = false }) {
                    Text("إلغاء", color = Slate500)
                }
            }
        )
    }

    // Dialog for changing student department quickly
    if (changingDepartmentForStudent != null) {
        val s = changingDepartmentForStudent!!
        AlertDialog(
            onDismissRequest = { changingDepartmentForStudent = null },
            shape = RoundedCornerShape(16.dp),
            containerColor = Color.White,
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.Category, contentDescription = null, tint = Brand600, modifier = Modifier.size(22.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("تغيير قسم الطالب", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "اختر القسم الجديد للطالب ${s.fullName}:",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Slate700
                    )
                    Spacer(Modifier.height(4.dp))
                    StudentDepartments.ALL.forEach { dept ->
                        val info = getDepartmentUiInfo(dept)
                        val isSelected = s.safeDepartment == dept
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.updateStudentDepartment(s.id, dept)
                                    Toast.makeText(context, "تم تغيير قسم الطالب إلى $dept", Toast.LENGTH_SHORT).show()
                                    changingDepartmentForStudent = null
                                },
                            shape = RoundedCornerShape(10.dp),
                            color = if (isSelected) info.containerColor else Slate50,
                            border = BorderStroke(
                                if (isSelected) 1.5.dp else 1.dp,
                                if (isSelected) info.borderColor else Slate200
                            )
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(info.icon, contentDescription = null, tint = info.textColor, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(10.dp))
                                    Text(
                                        dept,
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                        color = if (isSelected) info.textColor else Slate800,
                                        maxLines = 1,
                                        softWrap = false
                                    )
                                }
                                if (isSelected) {
                                    Icon(Icons.Filled.Check, contentDescription = null, tint = info.textColor, modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { changingDepartmentForStudent = null }) {
                    Text("إلغاء", color = Slate500)
                }
            }
        )
    }

    if (viewingStudentDetail != null) {
        val s = viewingStudentDetail!!
        val studentLessons = mosque.lessons.mapNotNull { l ->
            val r = l.records.find { it.studentId == s.id }
            if (r != null) Pair(l, r) else null
        }
        val presentCount = studentLessons.count { it.second.attendance == "حضور" }
        val attendanceRate = if (studentLessons.isNotEmpty()) Math.round((presentCount.toFloat() / studentLessons.size) * 100) else 0
        val studentTests = mosque.tests.filter { t -> t.studentId == s.id || t.records.any { r -> r.studentId == s.id } }
        val deptInfo = getDepartmentUiInfo(s.safeDepartment)

        AlertDialog(
            onDismissRequest = { viewingStudentDetail = null },
            shape = RoundedCornerShape(16.dp),
            containerColor = Color.White,
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = deptInfo.containerColor,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(deptInfo.icon, contentDescription = null, tint = deptInfo.textColor, modifier = Modifier.size(20.dp))
                        }
                    }
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text(s.fullName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Slate900)
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = deptInfo.containerColor,
                            border = BorderStroke(1.dp, deptInfo.borderColor),
                            modifier = Modifier.padding(top = 2.dp)
                        ) {
                            Text(
                                s.safeDepartment,
                                color = deptInfo.textColor,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                softWrap = false,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("ملخص أداء الطالب:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold, color = Slate700)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Surface(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            color = Slate50,
                            border = BorderStroke(1.dp, Slate200)
                        ) {
                            Column(Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("$attendanceRate%".toStandardDigits(), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Brand600)
                                Text("نسبة الحضور", style = MaterialTheme.typography.labelSmall, color = Slate500, maxLines = 1, softWrap = false)
                            }
                        }
                        Surface(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            color = Slate50,
                            border = BorderStroke(1.dp, Slate200)
                        ) {
                            Column(Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("${studentLessons.size}".toStandardDigits(), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Slate800)
                                Text("الدروس", style = MaterialTheme.typography.labelSmall, color = Slate500, maxLines = 1, softWrap = false)
                            }
                        }
                        Surface(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            color = Slate50,
                            border = BorderStroke(1.dp, Slate200)
                        ) {
                            Column(Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("${studentTests.size}".toStandardDigits(), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Slate800)
                                Text("الاختبارات", style = MaterialTheme.typography.labelSmall, color = Slate500, maxLines = 1, softWrap = false)
                            }
                        }
                    }
                    if (studentLessons.isNotEmpty()) {
                        val lastLesson = studentLessons.last()
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Brand50,
                            modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
                        ) {
                            Text(
                                "آخر درس: ${lastLesson.first.day} (${lastLesson.second.attendance} - ${lastLesson.second.type ?: "بدون"} - ${lastLesson.second.grade ?: ""})",
                                style = MaterialTheme.typography.bodySmall,
                                color = Brand900,
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { viewingStudentDetail = null },
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Brand600)
                ) {
                    Text("إغلاق")
                }
            }
        )
    }

    if (showDuplicateWarning != null) {
        AlertDialog(
            onDismissRequest = { showDuplicateWarning = null },
            shape = RoundedCornerShape(16.dp),
            containerColor = Color.White,
            title = { Text("تحذير تكرار الاسم", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) },
            text = { Text("يوجد طالب مسجل بهذا الاسم مسبقاً في هذه الحلقة. هل تريد إضافة الطالب بنفس الاسم؟", style = MaterialTheme.typography.bodyMedium) },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.forceAddStudent(showDuplicateWarning!!, newStudentDepartment)
                        Toast.makeText(context, "تم إضافة الطالب بنجاح", Toast.LENGTH_SHORT).show()
                        newStudentName = ""
                        showDuplicateWarning = null
                    },
                    shape = RoundedCornerShape(8.dp)
                ) { Text("نعم، إضافة") }
            },
            dismissButton = {
                TextButton(onClick = { showDuplicateWarning = null }) { Text("إلغاء", color = Slate500) }
            }
        )
    }

    if (showEditPrompt != null) {
        AlertDialog(
            onDismissRequest = { showEditPrompt = null },
            shape = RoundedCornerShape(16.dp),
            containerColor = Color.White,
            title = { Text("تعديل بيانات الطالب", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = editStudentName,
                        onValueChange = { editStudentName = it },
                        singleLine = true,
                        label = { Text("الاسم والكنية") },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Text("قسم الطالب:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold, color = Slate700)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        StudentDepartments.ALL.forEach { dept ->
                            val isSelected = editStudentDepartment == dept
                            val info = getDepartmentUiInfo(dept)
                            Surface(
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { editStudentDepartment = dept },
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSelected) info.containerColor else Slate100,
                                border = BorderStroke(if (isSelected) 1.5.dp else 0.5.dp, if (isSelected) info.borderColor else Slate300)
                            ) {
                                Text(
                                    dept.replace("قسم ", ""),
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) info.textColor else Slate700,
                                    textAlign = TextAlign.Center,
                                    maxLines = 1,
                                    softWrap = false,
                                    modifier = Modifier.padding(vertical = 8.dp)
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (editStudentName.isNotBlank()) {
                            viewModel.editStudent(showEditPrompt!!, editStudentName.trim(), editStudentDepartment)
                            Toast.makeText(context, "تم حفظ تعديلات الطالب", Toast.LENGTH_SHORT).show()
                        }
                        showEditPrompt = null
                    },
                    shape = RoundedCornerShape(8.dp)
                ) { Text("حفظ التعديل") }
            },
            dismissButton = {
                TextButton(onClick = { showEditPrompt = null }) { Text("إلغاء", color = Slate500) }
            }
        )
    }

    if (studentToDelete != null) {
        AlertDialog(
            onDismissRequest = { studentToDelete = null },
            shape = RoundedCornerShape(16.dp),
            containerColor = Color.White,
            title = { Text("حذف الطالب", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) },
            text = { Text("هل أنت متأكد من حذف هذا الطالب من قاعدة الطلبة؟", style = MaterialTheme.typography.bodyMedium) },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteStudent(studentToDelete!!)
                        Toast.makeText(context, "تم حذف الطالب", Toast.LENGTH_SHORT).show()
                        studentToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Rose500),
                    shape = RoundedCornerShape(8.dp)
                ) { Text("حذف") }
            },
            dismissButton = {
                TextButton(onClick = { studentToDelete = null }) { Text("إلغاء", color = Slate500) }
            }
        )
    }

    // Counts per department
    val departmentCounts = remember(scopedStudents) {
        mapOf(
            "الكل" to scopedStudents.size,
            StudentDepartments.TILAWA to scopedStudents.count { it.safeDepartment == StudentDepartments.TILAWA },
            StudentDepartments.RASHIDI to scopedStudents.count { it.safeDepartment == StudentDepartments.RASHIDI },
            StudentDepartments.QURAN_GHAIBAN to scopedStudents.count { it.safeDepartment == StudentDepartments.QURAN_GHAIBAN },
            StudentDepartments.TAJWEED to scopedStudents.count { it.safeDepartment == StudentDepartments.TAJWEED }
        )
    }

    val filteredStudents = remember(scopedStudents, searchQuery, selectedDepartmentFilter) {
        var list = scopedStudents.sortedBy { it.fullName }
        if (selectedDepartmentFilter != "الكل") {
            list = list.filter { it.safeDepartment == selectedDepartmentFilter }
        }
        if (searchQuery.isNotBlank()) {
            list = list.filter { it.fullName.contains(searchQuery, ignoreCase = true) }
        }
        list
    }

    // التحميل التدريجي (Progressive Loading) لضمان سلاسة وسرعة القائمة
    val listState = rememberLazyListState()
    var visibleLimit by remember(selectedDepartmentFilter, searchQuery) { mutableStateOf(40) }
    val displayedStudents = remember(filteredStudents, visibleLimit) {
        filteredStudents.take(visibleLimit)
    }

    val shouldLoadMore by remember {
        derivedStateOf {
            val layoutInfo = listState.layoutInfo
            val totalItems = layoutInfo.totalItemsCount
            val lastVisible = layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
            totalItems > 0 && lastVisible >= totalItems - 6 && visibleLimit < filteredStudents.size
        }
    }

    LaunchedEffect(shouldLoadMore) {
        if (shouldLoadMore) {
            visibleLimit += 40
        }
    }

    LazyColumn(
        state = listState,
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        // Add Student Form (With Department Selection)
        item(key = "add_student_form", contentType = "form") {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "إضافة طالب جديد وتحديد قسمه",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Brand600,
                            maxLines = 1
                        )
                        FilledTonalButton(
                            onClick = { showBulkAddDialog = true },
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.filledTonalButtonColors(
                                containerColor = Brand50,
                                contentColor = Brand700
                            ),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            modifier = Modifier.height(30.dp)
                        ) {
                            Icon(Icons.Filled.GroupAdd, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("إضافة متعددة", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = newStudentName,
                            onValueChange = { newStudentName = it },
                            modifier = Modifier.weight(1f),
                            placeholder = { Text("الاسم والكنية (مثال: أحمد خالد)", style = MaterialTheme.typography.bodyMedium, color = Slate400) },
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp),
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                            keyboardActions = KeyboardActions(onDone = {
                                if (newStudentName.isNotBlank()) {
                                    viewModel.addStudent(
                                        fullName = newStudentName,
                                        department = newStudentDepartment,
                                        onDuplicate = { showDuplicateWarning = newStudentName },
                                        onSuccess = {
                                            Toast.makeText(context, "تم إضافة الطالب بنجاح في $newStudentDepartment", Toast.LENGTH_SHORT).show()
                                            newStudentName = ""
                                        }
                                    )
                                } else {
                                    Toast.makeText(context, "يرجى إدخال اسم الطالب", Toast.LENGTH_SHORT).show()
                                }
                            }),
                            textStyle = MaterialTheme.typography.bodyMedium.copy(textAlign = TextAlign.Right)
                        )
                        Spacer(Modifier.width(8.dp))
                        Button(
                            onClick = {
                                if (newStudentName.isNotBlank()) {
                                    viewModel.addStudent(
                                        fullName = newStudentName,
                                        department = newStudentDepartment,
                                        onDuplicate = { showDuplicateWarning = newStudentName },
                                        onSuccess = {
                                            Toast.makeText(context, "تم إضافة الطالب بنجاح في $newStudentDepartment", Toast.LENGTH_SHORT).show()
                                            newStudentName = ""
                                        }
                                    )
                                } else {
                                    Toast.makeText(context, "يرجى إدخال اسم الطالب", Toast.LENGTH_SHORT).show()
                                }
                            },
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.height(52.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Brand600)
                        ) {
                            Icon(Icons.Filled.PersonAdd, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("حفظ", style = MaterialTheme.typography.labelLarge, maxLines = 1, softWrap = false)
                        }
                    }

                    Spacer(Modifier.height(8.dp))
                    Text("اختيار القسم للطالب الجديد:", style = MaterialTheme.typography.labelSmall, color = Slate600, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(4.dp))

                    // Row of departments
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        StudentDepartments.ALL.forEach { dept ->
                            val isSelected = newStudentDepartment == dept
                            val info = getDepartmentUiInfo(dept)
                            Surface(
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { newStudentDepartment = dept },
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSelected) info.containerColor else Slate50,
                                border = BorderStroke(if (isSelected) 1.5.dp else 0.5.dp, if (isSelected) info.borderColor else Slate200)
                            ) {
                                Row(
                                    modifier = Modifier.padding(vertical = 6.dp, horizontal = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    Icon(info.icon, contentDescription = null, tint = if (isSelected) info.textColor else Slate500, modifier = Modifier.size(14.dp))
                                    Spacer(Modifier.width(3.dp))
                                    Text(
                                        dept.replace("قسم ", ""),
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSelected) info.textColor else Slate700,
                                        maxLines = 1,
                                        softWrap = false
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Header and Department Filter Chips (تم حذف ميزة الفرز التلقائي للأقسام نهائياً)
        item(key = "students_header", contentType = "header") {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(Modifier.padding(14.dp)) {
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Outlined.People, contentDescription = null, tint = Brand600, modifier = Modifier.size(20.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(
                                "قاعدة بيانات الطلبة (${scopedStudents.size.toString().toStandardDigits()})",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Slate900,
                                maxLines = 1
                            )
                        }
                    }

                    Spacer(Modifier.height(10.dp))

                    // Department Filter Bar (Scrollable chips)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        val filterOptions = listOf("الكل") + StudentDepartments.ALL
                        filterOptions.forEach { option ->
                            val isSelected = selectedDepartmentFilter == option
                            val count = departmentCounts[option] ?: 0
                            val info = if (option == "الكل") null else getDepartmentUiInfo(option)

                            Surface(
                                modifier = Modifier.clickable { selectedDepartmentFilter = option },
                                shape = RoundedCornerShape(20.dp),
                                color = when {
                                    isSelected && info != null -> info.containerColor
                                    isSelected -> Brand100
                                    else -> Slate100
                                },
                                border = BorderStroke(
                                    if (isSelected) 1.5.dp else 0.5.dp,
                                    when {
                                        isSelected && info != null -> info.borderColor
                                        isSelected -> Brand600
                                        else -> Slate200
                                    }
                                )
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    if (info != null) {
                                        Icon(
                                            info.icon,
                                            contentDescription = null,
                                            tint = if (isSelected) info.textColor else Slate500,
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Spacer(Modifier.width(4.dp))
                                    }
                                    Text(
                                        option,
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                        color = when {
                                            isSelected && info != null -> info.textColor
                                            isSelected -> Brand700
                                            else -> Slate700
                                        },
                                        maxLines = 1,
                                        softWrap = false
                                    )
                                    Spacer(Modifier.width(6.dp))
                                    Surface(
                                        shape = CircleShape,
                                        color = when {
                                            isSelected && info != null -> info.textColor.copy(alpha = 0.15f)
                                            isSelected -> Brand600.copy(alpha = 0.15f)
                                            else -> Slate200
                                        }
                                    ) {
                                        Text(
                                            count.toString().toStandardDigits(),
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = when {
                                                isSelected && info != null -> info.textColor
                                                isSelected -> Brand700
                                                else -> Slate600
                                            },
                                            maxLines = 1,
                                            softWrap = false,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    if (scopedStudents.size > 3) {
                        Spacer(Modifier.height(10.dp))
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("بحث باسم الطالب...", style = MaterialTheme.typography.bodySmall, color = Slate400) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp),
                            textStyle = MaterialTheme.typography.bodySmall.copy(textAlign = TextAlign.Right),
                            leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null, tint = Slate400, modifier = Modifier.size(16.dp)) },
                            trailingIcon = {
                                if (searchQuery.isNotEmpty()) {
                                    IconButton(onClick = { searchQuery = "" }) {
                                        Icon(Icons.Outlined.Clear, contentDescription = "مسح", tint = Slate400, modifier = Modifier.size(14.dp))
                                    }
                                }
                            }
                        )
                    }
                }
            }
        }

        if (scopedStudents.isEmpty()) {
            item(key = "empty_students", contentType = "empty") {
                Surface(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(Modifier.fillMaxWidth().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            "لا يوجد طلبة مسجلين حالياً. أضف أسماء الطلاب أعلاه.",
                            color = Slate500,
                            style = MaterialTheme.typography.bodyMedium,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        } else if (filteredStudents.isEmpty()) {
            item(key = "empty_filter_students", contentType = "empty") {
                Surface(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            "لا يوجد طلبة مطابقين للبحث في $selectedDepartmentFilter.",
                            color = Slate500,
                            style = MaterialTheme.typography.bodyMedium,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        } else {
            item(key = "table_header", contentType = "table_header") {
                Surface(
                    shape = RoundedCornerShape(topStart = 10.dp, topEnd = 10.dp),
                    color = Slate100,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("م", modifier = Modifier.width(32.dp), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall, color = Slate600, maxLines = 1, softWrap = false)
                        Text("الاسم والكنية", modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall, color = Slate600, maxLines = 1, softWrap = false)
                        Text("القسم", modifier = Modifier.width(105.dp), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall, color = Slate600, maxLines = 1, softWrap = false)
                        Text("إجراءات", modifier = Modifier.width(68.dp), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall, color = Slate600, maxLines = 1, softWrap = false)
                    }
                }
            }
            itemsIndexed(displayedStudents, key = { _, student -> student.id }, contentType = { _, _ -> "student_row" }) { index, student ->
                val info = getDepartmentUiInfo(student.safeDepartment)
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(0.5.dp, Slate200),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "${index + 1}".toStandardDigits(),
                            modifier = Modifier.width(32.dp),
                            color = Slate400,
                            style = MaterialTheme.typography.labelMedium,
                            maxLines = 1,
                            softWrap = false
                        )

                        // Student Name (clickable to view details, strictly horizontal)
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .padding(end = 6.dp)
                                .clickable { viewingStudentDetail = student }
                        ) {
                            Text(
                                student.fullName,
                                fontWeight = FontWeight.SemiBold,
                                style = MaterialTheme.typography.bodyMedium,
                                color = Slate900,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        // Interactive Department Badge (Click to quickly change department)
                        Surface(
                            modifier = Modifier
                                .width(105.dp)
                                .clickable { changingDepartmentForStudent = student },
                            shape = RoundedCornerShape(8.dp),
                            color = info.containerColor,
                            border = BorderStroke(1.dp, info.borderColor)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(info.icon, contentDescription = null, tint = info.textColor, modifier = Modifier.size(13.dp))
                                Spacer(Modifier.width(3.dp))
                                Text(
                                    student.safeDepartment,
                                    color = info.textColor,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    softWrap = false,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }

                        // Action buttons
                        Row(Modifier.width(68.dp), horizontalArrangement = Arrangement.End) {
                            IconButton(
                                onClick = {
                                    editStudentName = student.fullName
                                    editStudentDepartment = student.safeDepartment
                                    showEditPrompt = student.id
                                },
                                modifier = Modifier.size(30.dp)
                            ) {
                                Icon(Icons.Outlined.Edit, contentDescription = "تعديل", tint = Slate500, modifier = Modifier.size(15.dp))
                            }
                            IconButton(
                                onClick = { studentToDelete = student.id },
                                modifier = Modifier.size(30.dp)
                            ) {
                                Icon(Icons.Outlined.DeleteOutline, contentDescription = "حذف", tint = Rose500, modifier = Modifier.size(15.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}
