package com.example.ui

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.R
import com.example.ui.theme.*
import com.example.utils.toStandardDigits
import kotlinx.coroutines.delay

@Composable
fun SplashScreen() {
    val gradient = Brush.verticalGradient(colors = listOf(Brand900, Brand800, Brand700))
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(gradient),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(24.dp)
        ) {
            Text(
                text = "السلام عليكم ورحمة الله وبركاته",
                style = MaterialTheme.typography.titleMedium,
                color = Gold500,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(28.dp))
            Surface(
                color = Color.White.copy(alpha = 0.10f),
                shape = CircleShape,
                modifier = Modifier.size(124.dp),
                border = BorderStroke(1.dp, Gold500.copy(alpha = 0.55f))
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Image(
                        painter = painterResource(id = R.drawable.ic_mosque),
                        contentDescription = null,
                        modifier = Modifier.size(68.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(28.dp))
            Text(
                text = "إدارة الحلقات القرآنية",
                style = MaterialTheme.typography.headlineMedium,
                color = Color.White,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "نظام المتابعة والتسميع والتقارير",
                style = MaterialTheme.typography.bodyMedium,
                color = Brand100
            )
        }
    }
}

private data class NavItem(
    val tab: MosqueViewModel.Tab,
    val label: String,
    val selectedIcon: ImageVector,
    val icon: ImageVector
)

private val navItems = listOf(
    NavItem(MosqueViewModel.Tab.SETTINGS, "الطلبة", Icons.Filled.PeopleAlt, Icons.Outlined.PeopleOutline),
    NavItem(MosqueViewModel.Tab.LESSONS, "الدروس", Icons.Filled.AutoStories, Icons.Outlined.AutoStories),
    NavItem(MosqueViewModel.Tab.TESTS, "الاختبارات", Icons.Filled.FactCheck, Icons.Outlined.FactCheck),
    NavItem(MosqueViewModel.Tab.JUZ, "الجزء", Icons.Filled.BookmarkAdded, Icons.Outlined.BookmarkBorder),
    NavItem(MosqueViewModel.Tab.REPORTS, "التقارير", Icons.Filled.Assessment, Icons.Outlined.Assessment),
    NavItem(MosqueViewModel.Tab.EXAM_SCHEDULE, "المواعيد", Icons.Filled.EventAvailable, Icons.Outlined.EventAvailable)
)

private fun subtitleFor(tab: MosqueViewModel.Tab, lessonOpen: Boolean, testOpen: Boolean, examGroupOpen: Boolean): String = when (tab) {
    MosqueViewModel.Tab.SETTINGS -> "قاعدة بيانات الطلاب"
    MosqueViewModel.Tab.LESSONS -> if (lessonOpen) "تسجيل الدرس اليومي" else "سجل الدروس اليومية"
    MosqueViewModel.Tab.TESTS -> if (testOpen) "إجراء الاختبار" else "سجل الاختبارات الدورية"
    MosqueViewModel.Tab.JUZ -> "السجل"
    MosqueViewModel.Tab.REPORTS -> "التقرير الأسبوعي والتراكمي"
    MosqueViewModel.Tab.EXAM_SCHEDULE -> if (examGroupOpen) "تخصيص مجموعة مواعيد الاختبار" else "مجموعات مواعيد الاختبارات"
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MosqueApp(viewModel: MosqueViewModel = viewModel()) {
    val isLoaded by viewModel.isLoaded.collectAsState()
    var minSplashDone by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay(120)
        minSplashDone = true
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        if (!isLoaded || !minSplashDone) {
            SplashScreen()
        } else {
            MosqueScaffold(viewModel)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MosqueScaffold(viewModel: MosqueViewModel) {
    val context = LocalContext.current
    val currentMosqueId by viewModel.currentMosqueId.collectAsState()
    val mosqueName by viewModel.currentMosqueName.collectAsState()
    val currentTab by viewModel.currentTab.collectAsState()
    val openedLessonId by viewModel.openedLessonId.collectAsState()
    val openedTestId by viewModel.openedTestId.collectAsState()
    val openedExamGroupId by viewModel.openedExamGroupId.collectAsState()

    val inMosque = currentMosqueId != null
    val isSubEditorOpen = openedLessonId != null || openedTestId != null || openedExamGroupId != null

    // زر الرجوع: يغلق المحرر المفتوح، ثم يعود للتبويب الأول، ثم للرئيسية
    BackHandler(enabled = inMosque) {
        when {
            openedLessonId != null -> viewModel.closeLesson()
            openedTestId != null -> viewModel.closeTest()
            openedExamGroupId != null -> viewModel.closeExamGroup()
            currentTab != MosqueViewModel.Tab.SETTINGS -> viewModel.switchTab(MosqueViewModel.Tab.SETTINGS)
            else -> viewModel.goHome()
        }
    }

    var showDuplicatesDialog by remember { mutableStateOf(false) }
    val duplicateGroups by viewModel.duplicateGroups.collectAsState()
    val duplicatesCount by viewModel.duplicatesCount.collectAsState()

    if (showDuplicatesDialog) {
        DuplicateStudentsDialog(
            viewModel = viewModel,
            duplicateGroups = duplicateGroups,
            onDismiss = { showDuplicatesDialog = false }
        )
    }

    Scaffold(
        topBar = {
            Box(
                Modifier
                    .fillMaxWidth()
                    .background(Brush.horizontalGradient(listOf(Brand800, Brand600)))
            ) {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                color = Color.White.copy(alpha = 0.16f),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.size(38.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        painter = painterResource(id = R.drawable.ic_mosque),
                                        contentDescription = null,
                                        modifier = Modifier.size(22.dp),
                                        tint = Color.Unspecified
                                    )
                                }
                            }
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = mosqueName ?: "إدارة الحلقات القرآنية",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    maxLines = 1,
                                    softWrap = false,
                                    overflow = TextOverflow.Ellipsis
                                )
                                if (inMosque) {
                                    Text(
                                        text = subtitleFor(
                                            currentTab,
                                            openedLessonId != null,
                                            openedTestId != null,
                                            openedExamGroupId != null
                                        ),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Brand100,
                                        maxLines = 1,
                                        softWrap = false,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color.Transparent,
                        titleContentColor = Color.White,
                        actionIconContentColor = Color.White
                    ),
                    actions = {
                        if (!inMosque) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                modifier = Modifier.padding(end = 8.dp)
                            ) {
                                // زر صغير لتحديث والبحث عن التكرارات في أعلى الصفحة الرئيسية
                                Surface(
                                    onClick = {
                                        viewModel.recheckDuplicates()
                                        Toast.makeText(
                                            context,
                                            "تم تحديث البحث عن الأسماء المكررة وإظهار أي إشعارات متجاهلة سابقاً ✓",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                    },
                                    shape = RoundedCornerShape(10.dp),
                                    color = Color.White.copy(alpha = 0.18f),
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            Icons.Filled.Refresh,
                                            contentDescription = "تحديث البحث عن التكرارات",
                                            tint = Color.White,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }

                                // أيقونة الإشعارات في الصفحة الرئيسية من الأعلى لفحص الأسماء المكررة
                                FilledTonalButton(
                                    onClick = { showDuplicatesDialog = true },
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.filledTonalButtonColors(
                                        containerColor = if (duplicatesCount > 0) Rose600 else Color.White.copy(alpha = 0.18f),
                                        contentColor = Color.White
                                    ),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                    modifier = Modifier.height(36.dp)
                                ) {
                                    BadgedBox(
                                        badge = {
                                            if (duplicatesCount > 0) {
                                                Badge(
                                                    containerColor = Amber500,
                                                    contentColor = Slate900
                                                ) {
                                                    Text(
                                                        duplicatesCount.toString().toStandardDigits(),
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 10.sp,
                                                        maxLines = 1,
                                                        softWrap = false
                                                    )
                                                }
                                            }
                                        }
                                    ) {
                                        Icon(
                                            imageVector = if (duplicatesCount > 0) Icons.Filled.NotificationsActive else Icons.Outlined.Notifications,
                                            contentDescription = "إشعارات التكرار",
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                    Spacer(Modifier.width(6.dp))
                                    Text(
                                        if (duplicatesCount > 0) "${duplicatesCount.toString().toStandardDigits()} تكرار" else "الإشعارات",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        softWrap = false
                                    )
                                }
                            }
                        } else {
                            FilledTonalButton(
                                onClick = { viewModel.goHome() },
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.filledTonalButtonColors(
                                    containerColor = Color.White.copy(alpha = 0.16f),
                                    contentColor = Color.White
                                ),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                modifier = Modifier.padding(end = 8.dp)
                            ) {
                                Icon(Icons.Outlined.Home, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("الرئيسية", style = MaterialTheme.typography.labelLarge, maxLines = 1, softWrap = false)
                            }
                        }
                    }
                )
            }
        },
        bottomBar = {
            if (inMosque) {
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    shadowElevation = 12.dp
                ) {
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.surface,
                        tonalElevation = 0.dp
                    ) {
                        navItems.forEach { item ->
                            val selected = currentTab == item.tab
                            NavigationBarItem(
                                selected = selected,
                                onClick = { viewModel.switchTab(item.tab) },
                                icon = {
                                    Icon(
                                        if (selected) item.selectedIcon else item.icon,
                                        contentDescription = item.label,
                                        modifier = Modifier.size(22.dp)
                                    )
                                },
                                label = {
                                    Text(
                                        item.label,
                                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 11.sp,
                                        maxLines = 1,
                                        softWrap = false
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Brand700,
                                    selectedTextColor = Brand700,
                                    indicatorColor = Brand100,
                                    unselectedIconColor = Slate400,
                                    unselectedTextColor = Slate500
                                )
                            )
                        }
                    }
                }
            }
        },
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets.systemBars
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .imePadding()
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            if (currentMosqueId == null) {
                HomeRoute(viewModel)
            } else {
                DashboardRoute(viewModel, currentTab, openedLessonId)
            }
        }
    }
}

@Composable
private fun HomeRoute(viewModel: MosqueViewModel) {
    val db by viewModel.dbFlow.collectAsState()
    HomeScreen(viewModel, db.mosques)
}

@Composable
private fun DashboardRoute(viewModel: MosqueViewModel, tab: MosqueViewModel.Tab, openedLessonId: String?) {
    val mosque by viewModel.currentMosque.collectAsState()
    mosque?.let { MosqueDashboard(viewModel, it, tab, openedLessonId) }
}
