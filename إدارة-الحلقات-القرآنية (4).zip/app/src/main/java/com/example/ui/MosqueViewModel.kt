package com.example.ui

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.MosqueApplication
import com.example.data.*
import com.example.utils.ExportUtils
import com.example.utils.PdfGenerator
import com.example.utils.toStandardDigits
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*

class MosqueViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = (application as MosqueApplication).repository

    val dbFlow = repository.dbFlow
    val isLoaded = repository.isLoaded

    private val _currentMosqueId = MutableStateFlow<String?>(null)
    val currentMosqueId: StateFlow<String?> = _currentMosqueId.asStateFlow()

    private val _currentTab = MutableStateFlow(Tab.SETTINGS)
    val currentTab: StateFlow<Tab> = _currentTab.asStateFlow()

    private val _openedLessonId = MutableStateFlow<String?>(null)
    val openedLessonId: StateFlow<String?> = _openedLessonId.asStateFlow()

    private val _openedTestId = MutableStateFlow<String?>(null)
    val openedTestId: StateFlow<String?> = _openedTestId.asStateFlow()

    private val _openedExamGroupId = MutableStateFlow<String?>(null)
    val openedExamGroupId: StateFlow<String?> = _openedExamGroupId.asStateFlow()

    val currentMosque = combine(dbFlow, currentMosqueId) { db, id ->
        db.mosques.find { it.id == id }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    /** اسم المسجد فقط — حتى لا يعاد رسم الشريط العلوي مع كل تعديل على بيانات الطلاب. */
    val currentMosqueName: StateFlow<String?> = currentMosque
        .map { it?.name }
        .distinctUntilChanged()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val _isExporting = MutableStateFlow(false)
    val isExporting: StateFlow<Boolean> = _isExporting.asStateFlow()

    private val _reportFilter = MutableStateFlow(com.example.utils.ReportPeriodFilter())
    val reportFilter: StateFlow<com.example.utils.ReportPeriodFilter> = _reportFilter.asStateFlow()

    fun setReportFilter(filter: com.example.utils.ReportPeriodFilter) {
        _reportFilter.value = filter
    }

    // فحص الأسماء المكررة مع دعم التجاهل وإعادة الفحص
    private val _ignoredDuplicateKeys = MutableStateFlow<Set<String>>(emptySet())
    val ignoredDuplicateKeys: StateFlow<Set<String>> = _ignoredDuplicateKeys.asStateFlow()

    private val _duplicateRefreshTrigger = MutableStateFlow(0L)

    val duplicateGroups: StateFlow<List<com.example.utils.DuplicateGroup>> = combine(
        dbFlow,
        _ignoredDuplicateKeys,
        _duplicateRefreshTrigger
    ) { db, ignored, _ ->
        com.example.utils.StudentDuplicateDetector.findDuplicates(db.mosques, ignored)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val duplicatesCount: StateFlow<Int> = duplicateGroups
        .map { it.size }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    fun ignoreDuplicate(groupKey: String) {
        _ignoredDuplicateKeys.value = _ignoredDuplicateKeys.value + groupKey
    }

    /**
     * تحديث حالة البحث عن التكرارات وإظهار الأسماء التي تم تجاهلها سابقاً مرة ثانية
     */
    fun recheckDuplicates() {
        _ignoredDuplicateKeys.value = emptySet()
        _duplicateRefreshTrigger.value = System.currentTimeMillis()
    }

    fun deleteStudentFromMosque(mosqueId: String, studentId: String) {
        val db = dbFlow.value
        val targetMosque = db.mosques.find { it.id == mosqueId } ?: return
        val updatedMosque = targetMosque.copy(students = targetMosque.students.filter { it.id != studentId })
        repository.updateMemory(db.copy(mosques = db.mosques.map { if (it.id == mosqueId) updatedMosque else it }))
        flushSaveNow()
    }

    fun keepOnlyOneInstance(
        instances: List<com.example.utils.DuplicateStudentInstance>,
        keepMosqueId: String? = null,
        keepStudentId: String? = null
    ) {
        instances.filterNot { it.mosqueId == keepMosqueId && it.student.id == keepStudentId }
            .forEach { deleteStudentFromMosque(it.mosqueId, it.student.id) }
    }

    /** يجهّز بيانات المسجد المعزولة (scopedStudents) مع تطبيق فلتر الفترة ثم ينفّذ عملية التصدير. */
    private fun runExport(
        mosque: Mosque,
        tab: String,
        examGroupId: String? = null,
        block: suspend (Mosque, String?) -> Unit
    ) {
        viewModelScope.launch {
            _isExporting.value = true
            try {
                val rawMosque = currentMosque.value ?: mosque
                val scopedList = rawMosque.scopedStudents
                val scopedIds = scopedList.map { it.id }.toSet()
                val scopedLessons = rawMosque.lessons.map { l ->
                    l.copy(records = l.records.filter { it.studentId in scopedIds })
                }
                val activeGroupId = examGroupId ?: _openedExamGroupId.value
                val groupAppts = if (tab == "EXAM_SCHEDULE" && activeGroupId != null) {
                    rawMosque.safeExamScheduleGroups.find { it.id == activeGroupId }?.appointments
                        ?: rawMosque.safeExamAppointments
                } else {
                    rawMosque.safeExamAppointments
                }
                val current = rawMosque.copy(
                    students = scopedList,
                    lessons = scopedLessons,
                    examAppointments = groupAppts.map { it.copy(appointmentDate = it.safeAppointmentDate) }
                )
                if (tab == "REPORTS") {
                    val (filteredLessons, title) = withContext(Dispatchers.Default) {
                        com.example.utils.ReportFilterUtils.filterLessons(current.lessons, _reportFilter.value)
                    }
                    block(current.copy(lessons = filteredLessons), title)
                } else {
                    block(current, null)
                }
            } catch (e: Exception) {
                android.util.Log.e("MosqueViewModel", "Export failed", e)
            } finally {
                _isExporting.value = false
            }
        }
    }

    fun generatePdf(
        context: Context,
        mosque: Mosque,
        tab: String,
        lessonId: String? = null,
        testId: String? = null,
        studentId: String? = null,
        examGroupId: String? = null
    ) {
        runExport(mosque, tab, examGroupId) { m, periodTitle ->
            PdfGenerator.generatePdf(context, m, tab, lessonId, testId, studentId, reportPeriodTitle = periodTitle)
        }
    }

    fun shareWhatsApp(
        context: Context,
        mosque: Mosque,
        tab: String,
        lessonId: String? = null,
        testId: String? = null,
        studentId: String? = null,
        examGroupId: String? = null
    ) {
        runExport(mosque, tab, examGroupId) { m, periodTitle ->
            ExportUtils.shareWhatsApp(context, m, tab, lessonId, testId, studentId, reportPeriodTitle = periodTitle)
        }
    }

    fun shareAsImage(
        context: Context,
        mosque: Mosque,
        tab: String,
        lessonId: String? = null,
        testId: String? = null,
        studentId: String? = null,
        targetPackage: String? = null,
        examGroupId: String? = null
    ) {
        runExport(mosque, tab, examGroupId) { m, periodTitle ->
            PdfGenerator.generatePdf(
                context,
                m,
                tab,
                lessonId,
                testId,
                studentId,
                shareAsImage = true,
                targetPackage = targetPackage,
                reportPeriodTitle = periodTitle
            )
        }
    }

    /** قراءة ملف النسخة الاحتياطية على خيط الخلفية ثم استيرادها. */
    fun importDbFromUri(context: Context, uri: android.net.Uri, onComplete: (Boolean) -> Unit) {
        viewModelScope.launch {
            val json = withContext(Dispatchers.IO) {
                try {
                    context.contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) }
                } catch (e: Exception) {
                    android.util.Log.e("MosqueViewModel", "Read backup failed", e)
                    null
                }
            }
            if (json == null) onComplete(false) else importDb(json, onComplete)
        }
    }

    fun importDb(json: String, onComplete: (Boolean) -> Unit) {
        viewModelScope.launch {
            val success = repository.importDb(json)
            if (success) {
                _currentMosqueId.value = null
                _currentTab.value = Tab.SETTINGS
                _openedLessonId.value = null
                _openedTestId.value = null
                _openedExamGroupId.value = null
            }
            onComplete(success)
        }
    }

    /** يكتب النسخة الاحتياطية في الملف المحدد على خيط الخلفية ثم يعيد النتيجة على الخيط الرئيسي. */
    fun exportDbToUri(context: Context, uri: android.net.Uri, onResult: (Boolean) -> Unit) {
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) {
                try {
                    val json = repository.exportDb() ?: return@withContext false
                    context.contentResolver.openOutputStream(uri)?.use { it.write(json.toByteArray(Charsets.UTF_8)) }
                        ?: return@withContext false
                    true
                } catch (e: Exception) {
                    android.util.Log.e("MosqueViewModel", "Backup failed", e)
                    false
                }
            }
            onResult(ok)
        }
    }

    // Home / General
    fun addMosque(name: String) {
        viewModelScope.launch {
            val db = dbFlow.value
            val newMosque = Mosque(
                id = generateId(),
                name = name.trim(),
                students = emptyList(),
                lessons = emptyList(),
                tests = emptyList()
            )
            repository.saveDb(db.copy(mosques = db.mosques + newMosque))
        }
    }

    fun editMosqueName(id: String, newName: String) {
        viewModelScope.launch {
            val db = dbFlow.value
            val cleanName = newName.trim()
            val updated = db.mosques.map { m ->
                if (m.id == id) {
                    m.copy(
                        name = cleanName,
                        students = m.students.map { s -> s.copy(sourceMosqueName = cleanName) }
                    )
                } else m
            }
            repository.saveDb(db.copy(mosques = updated))
        }
    }

    fun deleteMosque(id: String) {
        viewModelScope.launch {
            val db = dbFlow.value
            repository.saveDb(db.copy(mosques = db.mosques.filter { it.id != id }))
            if (_currentMosqueId.value == id) {
                _currentMosqueId.value = null
            }
        }
    }

    fun openMosque(id: String) {
        _currentMosqueId.value = id
        _currentTab.value = Tab.SETTINGS
        _openedLessonId.value = null
        _openedTestId.value = null
        _openedExamGroupId.value = null
    }

    fun goHome() {
        _currentMosqueId.value = null
        _openedLessonId.value = null
        _openedTestId.value = null
        _openedExamGroupId.value = null
    }

    fun switchTab(tab: Tab) {
        _currentTab.value = tab
        _openedLessonId.value = null
        _openedTestId.value = null
        _openedExamGroupId.value = null
    }

    // Settings (Students)
    fun addStudent(
        fullName: String,
        department: String = com.example.data.StudentDepartments.TILAWA,
        onDuplicate: () -> Unit,
        onSuccess: () -> Unit
    ) {
        val mosque = currentMosque.value ?: return
        if (mosque.scopedStudents.any { it.fullName.trim() == fullName.trim() }) {
            onDuplicate()
            return
        }
        forceAddStudent(fullName, department)
        onSuccess()
    }

    fun forceAddStudent(
        fullName: String,
        department: String = com.example.data.StudentDepartments.TILAWA,
        sourceMosqueName: String? = null
    ) {
        val mosque = currentMosque.value ?: return
        val newStudent = Student(
            id = generateId(),
            fullName = fullName.trim(),
            createdAt = System.currentTimeMillis(),
            department = com.example.data.StudentDepartments.normalize(department),
            sourceMosqueName = sourceMosqueName ?: mosque.name
        )
        updateMosque(mosque.copy(students = mosque.scopedStudents + newStudent))
    }

    fun updateStudentDepartment(id: String, newDepartment: String) {
        val mosque = currentMosque.value ?: return
        val cleanDept = com.example.data.StudentDepartments.normalize(newDepartment)
        val updatedStudents = mosque.scopedStudents.map {
            if (it.id == id) it.copy(department = cleanDept) else it
        }
        updateMosque(mosque.copy(students = updatedStudents))
        flushSaveNow()
    }

    /**
     * Batch adds multiple students at once for high efficiency.
     */
    fun bulkAddStudents(names: List<String>, department: String = com.example.data.StudentDepartments.TILAWA, onComplete: (Int) -> Unit) {
        val mosque = currentMosque.value ?: return
        val cleanNames = names.map { it.trim() }.filter { it.isNotBlank() }
        if (cleanNames.isEmpty()) {
            onComplete(0)
            return
        }

        val cleanDept = com.example.data.StudentDepartments.normalize(department)
        val newStudents = cleanNames.map { name ->
            Student(
                id = generateId(),
                fullName = name,
                createdAt = System.currentTimeMillis(),
                department = cleanDept,
                sourceMosqueName = mosque.name
            )
        }
        updateMosque(mosque.copy(students = mosque.scopedStudents + newStudents))
        flushSaveNow()
        onComplete(newStudents.size)
    }

    fun editStudent(id: String, newName: String, newDepartment: String? = null, newSourceMosque: String? = null) {
        val mosque = currentMosque.value ?: return
        val updatedStudents = mosque.scopedStudents.map {
            if (it.id == id) {
                it.copy(
                    fullName = newName.trim(),
                    department = if (newDepartment != null) com.example.data.StudentDepartments.normalize(newDepartment) else it.safeDepartment,
                    sourceMosqueName = newSourceMosque ?: mosque.name
                )
            } else it
        }
        updateMosque(mosque.copy(students = updatedStudents))
    }

    fun deleteStudent(id: String) {
        val mosque = currentMosque.value ?: return
        val updatedStudents = mosque.scopedStudents.filter { it.id != id }
        updateMosque(mosque.copy(students = updatedStudents))
    }

    // Lessons
    fun createNewLesson(onNoStudents: () -> Unit) {
        createNewLessonWithSections(com.example.data.StudentDepartments.ALL, onNoStudents)
    }

    fun createNewLessonWithSections(
        selectedSections: List<String>,
        onNoStudents: () -> Unit
    ) {
        val mosque = currentMosque.value ?: return
        val currentStudents = mosque.scopedStudents
        if (currentStudents.isEmpty()) {
            onNoStudents()
            return
        }

        val cleanSections = selectedSections
            .map { com.example.data.StudentDepartments.normalize(it) }
            .distinct()

        val orderedStudents = if (cleanSections.isEmpty() || cleanSections.size >= com.example.data.StudentDepartments.ALL.size) {
            val list = mutableListOf<Student>()
            com.example.data.StudentDepartments.ALL.forEach { sec ->
                list.addAll(currentStudents.filter { it.safeDepartment == sec }.sortedBy { it.fullName })
            }
            val remaining = currentStudents.filter { !list.contains(it) }.sortedBy { it.fullName }
            list.addAll(remaining)
            list
        } else {
            val list = mutableListOf<Student>()
            cleanSections.forEach { sec ->
                val inSec = currentStudents.filter { it.safeDepartment == sec }.sortedBy { it.fullName }
                list.addAll(inSec)
            }
            list
        }

        if (orderedStudents.isEmpty()) {
            onNoStudents()
            return
        }

        val dateFull = SimpleDateFormat("EEEE, d MMMM yyyy", Locale("ar", "EG")).format(Date()).toStandardDigits()
        val day = SimpleDateFormat("EEEE", Locale("ar", "EG")).format(Date())
        val dateStr = SimpleDateFormat("dd/MM/yyyy", Locale.US).format(Date()).toStandardDigits()

        val newLesson = Lesson(
            id = generateId(),
            dateFull = dateFull,
            day = day,
            dateStr = dateStr,
            timestamp = System.currentTimeMillis(),
            sections = if (cleanSections.isEmpty()) com.example.data.StudentDepartments.ALL else cleanSections,
            records = orderedStudents.map { student ->
                val defaultType = when (student.safeDepartment) {
                    com.example.data.StudentDepartments.RASHIDI -> "رشيدي"
                    com.example.data.StudentDepartments.QURAN_GHAIBAN -> "قرآن غيباً"
                    com.example.data.StudentDepartments.TAJWEED -> "تجويد"
                    else -> "تلاوة"
                }
                LessonRecord(
                    studentId = student.id,
                    studentName = student.fullName,
                    attendance = "حضور",
                    behavior = "",
                    type = defaultType,
                    page = "",
                    grade = "",
                    optTestType = "",
                    optTestInfo = "",
                    studentDepartment = student.safeDepartment,
                    studentMosqueName = mosque.name
                )
            }
        )
        updateMosque(mosque.copy(lessons = mosque.lessons + newLesson))
        _openedLessonId.value = newLesson.id
    }

    fun addDepartmentStudentsToLesson(lessonId: String, department: String) {
        val mosque = currentMosque.value ?: return
        val lesson = mosque.lessons.find { it.id == lessonId } ?: return
        val cleanDept = com.example.data.StudentDepartments.normalize(department)
        val existingStudentIds = lesson.records.map { it.studentId }.toSet()

        val newStudents = mosque.scopedStudents
            .filter { it.safeDepartment == cleanDept && !existingStudentIds.contains(it.id) }
            .sortedBy { it.fullName }

        if (newStudents.isEmpty()) return

        val defaultType = when (cleanDept) {
            com.example.data.StudentDepartments.RASHIDI -> "رشيدي"
            com.example.data.StudentDepartments.QURAN_GHAIBAN -> "قرآن غيباً"
            com.example.data.StudentDepartments.TAJWEED -> "تجويد"
            else -> "تلاوة"
        }

        val newRecords = newStudents.map {
            LessonRecord(
                studentId = it.id,
                studentName = it.fullName,
                attendance = "حضور",
                behavior = "",
                type = defaultType,
                page = "",
                grade = "",
                optTestType = "",
                optTestInfo = "",
                studentDepartment = cleanDept,
                studentMosqueName = mosque.name
            )
        }

        val updatedSections = (lesson.safeSections + cleanDept).distinct()
        val updatedLesson = lesson.copy(
            sections = updatedSections,
            records = lesson.records + newRecords
        )
        val updatedLessons = mosque.lessons.map { if (it.id == lessonId) updatedLesson else it }
        updateMosque(mosque.copy(lessons = updatedLessons))
        flushSaveNow()
    }

    fun openLesson(id: String) {
        _openedLessonId.value = id
    }

    fun closeLesson() {
        _openedLessonId.value = null
    }

    fun deleteLesson(id: String) {
        val mosque = currentMosque.value ?: return
        updateMosque(mosque.copy(lessons = mosque.lessons.filter { it.id != id }))
        if (_openedLessonId.value == id) {
            _openedLessonId.value = null
        }
    }

    fun updateAllLessonRecords(lessonId: String, updatedRecords: List<LessonRecord>) {
        val mosque = currentMosque.value ?: return
        val lesson = mosque.lessons.find { it.id == lessonId } ?: return
        val updatedLesson = lesson.copy(records = updatedRecords)
        val updatedLessons = mosque.lessons.map { if (it.id == lessonId) updatedLesson else it }
        updateMosque(mosque.copy(lessons = updatedLessons))
    }

    fun updateLessonRecord(lessonId: String, studentId: String, field: String, value: String) {
        val mosque = currentMosque.value ?: return
        val lesson = mosque.lessons.find { it.id == lessonId } ?: return
        val records = lesson.records.map { record ->
            if (record.studentId == studentId) {
                when (field) {
                    "attendance" -> record.copy(attendance = value)
                    "behavior" -> record.copy(behavior = value)
                    "type" -> record.copy(type = value)
                    "page" -> record.copy(page = value)
                    "grade" -> record.copy(grade = value)
                    "optTestType" -> record.copy(optTestType = value)
                    "optTestInfo" -> record.copy(optTestInfo = value)
                    else -> record
                }
            } else record
        }
        val updatedLesson = lesson.copy(records = records)
        val updatedLessons = mosque.lessons.map { if (it.id == lessonId) updatedLesson else it }
        updateMosque(mosque.copy(lessons = updatedLessons))
    }

    // Tests
    fun createNewTest(onNoStudents: () -> Unit) {
        createNewTestWithSections(com.example.data.StudentDepartments.ALL, onNoStudents)
    }

    fun createNewTestWithSections(
        selectedSections: List<String>,
        onNoStudents: () -> Unit
    ) {
        val mosque = currentMosque.value ?: return
        val currentStudents = mosque.scopedStudents
        if (currentStudents.isEmpty()) {
            onNoStudents()
            return
        }

        val cleanSections = selectedSections
            .map { com.example.data.StudentDepartments.normalize(it) }
            .distinct()

        val orderedStudents = if (cleanSections.isEmpty() || cleanSections.size >= com.example.data.StudentDepartments.ALL.size) {
            val list = mutableListOf<Student>()
            com.example.data.StudentDepartments.ALL.forEach { sec ->
                list.addAll(currentStudents.filter { it.safeDepartment == sec }.sortedBy { it.fullName })
            }
            val remaining = currentStudents.filter { !list.contains(it) }.sortedBy { it.fullName }
            list.addAll(remaining)
            list
        } else {
            val list = mutableListOf<Student>()
            cleanSections.forEach { sec ->
                val inSec = currentStudents.filter { it.safeDepartment == sec }.sortedBy { it.fullName }
                list.addAll(inSec)
            }
            list
        }

        if (orderedStudents.isEmpty()) {
            onNoStudents()
            return
        }

        val dateFull = SimpleDateFormat("EEEE, d MMMM yyyy", Locale("ar", "EG")).format(Date()).toStandardDigits()
        val day = SimpleDateFormat("EEEE", Locale("ar", "EG")).format(Date())
        val dateStr = SimpleDateFormat("dd/MM/yyyy", Locale.US).format(Date()).toStandardDigits()

        val newTest = Test(
            id = generateId(),
            title = "اختبار دوري",
            dateFull = dateFull,
            day = day,
            dateStr = dateStr,
            timestamp = System.currentTimeMillis(),
            sections = if (cleanSections.isEmpty()) com.example.data.StudentDepartments.ALL else cleanSections,
            records = orderedStudents.map {
                val defaultType = when (it.safeDepartment) {
                    com.example.data.StudentDepartments.RASHIDI -> "رشيدي"
                    com.example.data.StudentDepartments.QURAN_GHAIBAN -> "قرآن غيباً"
                    com.example.data.StudentDepartments.TAJWEED -> "تجويد"
                    else -> "تلاوة"
                }
                TestRecord(
                    studentId = it.id,
                    studentName = it.fullName,
                    attendance = "حضور",
                    behavior = "",
                    type = defaultType,
                    info = "",
                    grade = "",
                    studentDepartment = it.safeDepartment,
                    studentMosqueName = mosque.name
                )
            }
        )
        updateMosque(mosque.copy(tests = mosque.tests + newTest))
        _openedTestId.value = newTest.id
    }

    fun addSectionToTest(
        testId: String,
        selectedSections: List<String>,
        onAdded: (Int) -> Unit
    ) {
        val mosque = currentMosque.value ?: return
        val test = mosque.tests.find { it.id == testId } ?: return
        val cleanSections = selectedSections.map { com.example.data.StudentDepartments.normalize(it) }.distinct()
        val existingStudentIds = test.records.map { it.studentId }.toSet()

        val studentsToAdd = mutableListOf<Student>()
        cleanSections.forEach { sec ->
            val inSec = mosque.scopedStudents
                .filter { it.safeDepartment == sec && it.id !in existingStudentIds }
                .sortedBy { it.fullName }
            studentsToAdd.addAll(inSec)
        }

        if (studentsToAdd.isEmpty()) {
            onAdded(0)
            return
        }

        val newRecords = studentsToAdd.map { student ->
            val defaultType = when (student.safeDepartment) {
                com.example.data.StudentDepartments.RASHIDI -> "رشيدي"
                com.example.data.StudentDepartments.QURAN_GHAIBAN -> "قرآن غيباً"
                com.example.data.StudentDepartments.TAJWEED -> "تجويد"
                else -> "تلاوة"
            }
            TestRecord(
                studentId = student.id,
                studentName = student.fullName,
                attendance = "حضور",
                behavior = "",
                type = defaultType,
                info = "",
                grade = "",
                studentDepartment = student.safeDepartment,
                studentMosqueName = mosque.name
            )
        }

        val updatedSections = ((test.sections ?: emptyList()) + cleanSections).distinct()
        val updatedTest = test.copy(
            sections = updatedSections,
            records = test.records + newRecords
        )
        val updatedTests = mosque.tests.map { if (it.id == testId) updatedTest else it }
        updateMosque(mosque.copy(tests = updatedTests))
        onAdded(studentsToAdd.size)
    }

    fun openTest(id: String) {
        _openedTestId.value = id
    }

    fun closeTest() {
        _openedTestId.value = null
    }

    fun deleteTest(testId: String) {
        val mosque = currentMosque.value ?: return
        updateMosque(mosque.copy(tests = mosque.tests.filter { it.id != testId }))
        if (_openedTestId.value == testId) {
            _openedTestId.value = null
        }
    }

    fun updateAllTestRecords(testId: String, updatedRecords: List<TestRecord>) {
        val mosque = currentMosque.value ?: return
        val test = mosque.tests.find { it.id == testId } ?: return
        val updatedTest = test.copy(records = updatedRecords)
        val updatedTests = mosque.tests.map { if (it.id == testId) updatedTest else it }
        updateMosque(mosque.copy(tests = updatedTests))
    }

    fun updateTestHeader(testId: String, title: String, day: String, dateStr: String) {
        val mosque = currentMosque.value ?: return
        val test = mosque.tests.find { it.id == testId } ?: return
        val updatedTest = test.copy(title = title, day = day, dateStr = dateStr)
        val updatedTests = mosque.tests.map { if (it.id == testId) updatedTest else it }
        updateMosque(mosque.copy(tests = updatedTests))
    }

    fun updateTestRecord(testId: String, studentId: String, field: String, value: String) {
        val mosque = currentMosque.value ?: return
        val test = mosque.tests.find { it.id == testId } ?: return
        val records = test.records.map { record ->
            if (record.studentId == studentId) {
                when (field) {
                    "attendance" -> record.copy(attendance = value)
                    "behavior" -> record.copy(behavior = value)
                    "type" -> record.copy(type = value)
                    "info" -> record.copy(info = value)
                    "grade" -> record.copy(grade = value)
                    else -> record
                }
            } else record
        }
        val updatedTest = test.copy(records = records)
        val updatedTests = mosque.tests.map { if (it.id == testId) updatedTest else it }
        updateMosque(mosque.copy(tests = updatedTests))
    }

    // Exam Schedule Groups (مجموعات مواعيد الاختبار المحفوظة بتاريخ اليوم الذي صُممت فيه)
    fun openExamGroup(groupId: String) {
        _openedExamGroupId.value = groupId
    }

    fun closeExamGroup() {
        _openedExamGroupId.value = null
    }

    fun createNewExamGroup(customTitle: String? = null): String {
        val mosque = currentMosque.value ?: return ""
        val now = Date()
        val day = SimpleDateFormat("EEEE", Locale("ar", "EG")).format(now)
        val dateStr = SimpleDateFormat("dd/MM/yyyy", Locale.US).format(now).toStandardDigits()
        val dateFull = SimpleDateFormat("EEEE, d MMMM yyyy", Locale("ar", "EG")).format(now).toStandardDigits()
        val newGroupId = generateId()
        val title = if (!customTitle.isNullOrBlank()) customTitle.trim() else "مجموعة مواعيد - $day $dateStr"

        val newGroup = ExamScheduleGroup(
            id = newGroupId,
            title = title,
            day = day,
            dateStr = dateStr,
            dateFull = dateFull,
            createdAt = System.currentTimeMillis(),
            appointments = emptyList()
        )
        val updatedGroups = mosque.safeExamScheduleGroups + newGroup
        saveExamGroupsInternal(mosque, updatedGroups)
        _openedExamGroupId.value = newGroupId
        return newGroupId
    }

    fun updateExamGroupAppointments(groupId: String, appointments: List<ExamAppointment>) {
        val mosque = currentMosque.value ?: return
        val normalizedAppts = appointments.map { a ->
            val group = mosque.safeExamScheduleGroups.find { it.id == groupId }
            a.copy(
                appointmentDate = if (a.appointmentDate.isBlank()) "لم يحدد" else a.appointmentDate.trim(),
                groupId = groupId,
                groupTitle = group?.title ?: "مجموعة مواعيد الاختبار",
                groupDateStr = group?.dateStr ?: ""
            )
        }
        val updatedGroups = mosque.safeExamScheduleGroups.map { g ->
            if (g.id == groupId) g.copy(appointments = normalizedAppts) else g
        }
        saveExamGroupsInternal(mosque, updatedGroups)
    }

    fun deleteExamGroup(groupId: String) {
        val mosque = currentMosque.value ?: return
        val updatedGroups = mosque.safeExamScheduleGroups.filter { it.id != groupId }
        saveExamGroupsInternal(mosque, updatedGroups)
        if (_openedExamGroupId.value == groupId) {
            _openedExamGroupId.value = null
        }
        flushSaveNow()
    }

    private fun saveExamGroupsInternal(mosque: Mosque, groups: List<ExamScheduleGroup>) {
        val flatAppts = groups.flatMap { g ->
            g.appointments.map { a ->
                a.copy(
                    appointmentDate = a.safeAppointmentDate,
                    groupId = g.id,
                    groupTitle = g.title,
                    groupDateStr = g.dateStr
                )
            }
        }
        updateMosque(
            mosque.copy(
                examScheduleGroups = groups,
                examAppointments = flatAppts
            )
        )
    }

    fun saveExamAppointments(appointments: List<com.example.data.ExamAppointment>) {
        val mosque = currentMosque.value ?: return
        val normalized = appointments.map { it.copy(appointmentDate = it.safeAppointmentDate) }
        val activeGroupId = _openedExamGroupId.value
        if (activeGroupId != null) {
            updateExamGroupAppointments(activeGroupId, normalized)
        } else {
            updateMosque(mosque.copy(examAppointments = normalized))
        }
    }

    fun addExamAppointment(appointment: com.example.data.ExamAppointment) {
        val mosque = currentMosque.value ?: return
        val normalized = appointment.copy(appointmentDate = appointment.safeAppointmentDate)
        val updated = mosque.safeExamAppointments + normalized
        updateMosque(mosque.copy(examAppointments = updated))
    }

    fun addExamAppointments(appointments: List<com.example.data.ExamAppointment>) {
        val mosque = currentMosque.value ?: return
        val normalized = appointments.map { it.copy(appointmentDate = it.safeAppointmentDate) }
        val updated = mosque.safeExamAppointments + normalized
        updateMosque(mosque.copy(examAppointments = updated))
    }

    fun updateExamAppointment(appointment: com.example.data.ExamAppointment) {
        val mosque = currentMosque.value ?: return
        val normalized = appointment.copy(appointmentDate = appointment.safeAppointmentDate)
        val updated = mosque.safeExamAppointments.map {
            if (it.id == normalized.id) normalized else it
        }
        updateMosque(mosque.copy(examAppointments = updated))
    }

    fun deleteExamAppointment(id: String) {
        val mosque = currentMosque.value ?: return
        val updated = mosque.safeExamAppointments.filter { it.id != id }
        updateMosque(mosque.copy(examAppointments = updated))
    }

    fun clearExamAppointments() {
        val mosque = currentMosque.value ?: return
        updateMosque(mosque.copy(examAppointments = emptyList(), examScheduleGroups = emptyList()))
    }

    private var saveJob: Job? = null

    fun flushSaveNow() {
        saveJob?.cancel()
        repository.persistAsync(dbFlow.value)
    }

    override fun onCleared() {
        flushSaveNow()
        super.onCleared()
    }

    private fun updateMosque(mosque: Mosque) {
        val db = dbFlow.value
        val newDb = db.copy(mosques = db.mosques.map { if (it.id == mosque.id) mosque else it })

        repository.updateMemory(newDb)

        saveJob?.cancel()
        saveJob = viewModelScope.launch(Dispatchers.IO) {
            delay(400)
            repository.saveDbToDisk(newDb)
        }
    }

    private fun generateId(): String {
        return "_" + UUID.randomUUID().toString().substring(0, 9)
    }

    fun saveJuzRecords(records: List<com.example.data.JuzRecord>) {
        val mosque = currentMosque.value ?: return
        updateMosque(mosque.copy(juzRecords = records))
    }

    enum class Tab { SETTINGS, LESSONS, TESTS, JUZ, REPORTS, EXAM_SCHEDULE }
}
