package com.example.ui

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.*
import com.example.utils.DuplicateGroup
import com.example.utils.DuplicateStudentInstance
import com.example.utils.DuplicateType
import com.example.utils.toStandardDigits

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DuplicateStudentsDialog(
    viewModel: MosqueViewModel,
    duplicateGroups: List<DuplicateGroup>,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var groupToChooseDelete by remember { mutableStateOf<DuplicateGroup?>(null) }
    var singleInstanceToDelete by remember { mutableStateOf<DuplicateStudentInstance?>(null) }

    // حوار تأكيد حذف نسخة واحدة محددة
    if (singleInstanceToDelete != null) {
        val inst = singleInstanceToDelete!!
        AlertDialog(
            onDismissRequest = { singleInstanceToDelete = null },
            shape = RoundedCornerShape(16.dp),
            containerColor = Color.White,
            title = {
                Text(
                    "تأكيد حذف النسخة المكررة",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Rose600
                )
            },
            text = {
                Text(
                    "هل أنت متأكد من حذف نسخة الطالب «${inst.student.fullName}» المسجلة في:\n• المسجد/المجموعة: ${inst.mosqueName}\n• القسم: ${inst.department}؟",
                    style = MaterialTheme.typography.bodyMedium
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteStudentFromMosque(inst.mosqueId, inst.student.id)
                        Toast.makeText(context, "تم حذف النسخة المحددة من ${inst.mosqueName} (${inst.department}) ✓", Toast.LENGTH_SHORT).show()
                        singleInstanceToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Rose500),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("نعم، حذف هذه النسخة", maxLines = 1, softWrap = false)
                }
            },
            dismissButton = {
                TextButton(onClick = { singleInstanceToDelete = null }) {
                    Text("إلغاء", color = Slate500)
                }
            }
        )
    }

    // حوار اختيار أي نسخة (أو عدة نسخ) يراد حذفها
    if (groupToChooseDelete != null) {
        val group = groupToChooseDelete!!
        var selectedToDeleteKeys by remember(group.key) {
            mutableStateOf<Set<String>>(emptySet())
        }

        AlertDialog(
            onDismissRequest = { groupToChooseDelete = null },
            shape = RoundedCornerShape(16.dp),
            containerColor = Color.White,
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.DeleteSweep, contentDescription = null, tint = Rose600, modifier = Modifier.size(22.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "اختيار النسخة المراد حذفها",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Slate900
                    )
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "حدد النسخة المكررة التي ترغب بحذفها للاسم «${group.displayName}» (أو اضغط حذف مباشر بجانب النسخة):",
                        style = MaterialTheme.typography.bodySmall,
                        color = Slate700
                    )
                    Spacer(Modifier.height(4.dp))
                    group.instances.forEachIndexed { idx, inst ->
                        val instKey = "${inst.mosqueId}:${inst.student.id}"
                        val isSelected = instKey in selectedToDeleteKeys
                        val info = getDepartmentUiInfo(inst.department)

                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (isSelected) Rose50 else Slate50,
                            border = BorderStroke(if (isSelected) 1.5.dp else 1.dp, if (isSelected) Rose500 else Slate200),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedToDeleteKeys = if (isSelected) selectedToDeleteKeys - instKey else selectedToDeleteKeys + instKey
                                }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 10.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Checkbox(
                                        checked = isSelected,
                                        onCheckedChange = { checked ->
                                            selectedToDeleteKeys = if (checked) selectedToDeleteKeys + instKey else selectedToDeleteKeys - instKey
                                        },
                                        colors = CheckboxDefaults.colors(checkedColor = Rose600),
                                        modifier = Modifier.size(22.dp)
                                    )
                                    Spacer(Modifier.width(8.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            "نسخة ${(idx + 1).toString().toStandardDigits()}: ${inst.mosqueName}",
                                            fontWeight = FontWeight.Bold,
                                            color = Slate900,
                                            style = MaterialTheme.typography.bodySmall,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Spacer(Modifier.height(2.dp))
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Surface(
                                                shape = RoundedCornerShape(4.dp),
                                                color = info.containerColor,
                                                border = BorderStroke(0.5.dp, info.borderColor)
                                            ) {
                                                Text(
                                                    inst.department,
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = info.textColor,
                                                    maxLines = 1,
                                                    softWrap = false,
                                                    modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                                                )
                                            }
                                            Text(
                                                "دروس: ${inst.lessonsCount.toString().toStandardDigits()} | اختبارات: ${inst.testsCount.toString().toStandardDigits()}",
                                                fontSize = 10.sp,
                                                color = Slate500,
                                                maxLines = 1,
                                                softWrap = false
                                            )
                                        }
                                    }
                                }

                                // زر حذف فوري لهذه النسخة بعينها
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = Rose500,
                                    modifier = Modifier.clickable {
                                        viewModel.deleteStudentFromMosque(inst.mosqueId, inst.student.id)
                                        Toast.makeText(
                                            context,
                                            "تم حذف النسخة من ${inst.mosqueName} (${inst.department}) ✓",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                        groupToChooseDelete = null
                                    }
                                ) {
                                    Text(
                                        "حذف هذه",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White,
                                        maxLines = 1,
                                        softWrap = false,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                if (selectedToDeleteKeys.isNotEmpty()) {
                    Button(
                        onClick = {
                            val toDelete = group.instances.filter { "${it.mosqueId}:${it.student.id}" in selectedToDeleteKeys }
                            toDelete.forEach { inst ->
                                viewModel.deleteStudentFromMosque(inst.mosqueId, inst.student.id)
                            }
                            Toast.makeText(
                                context,
                                "تم حذف (${toDelete.size.toString().toStandardDigits()}) نسخة محددة بنجاح ✓",
                                Toast.LENGTH_SHORT
                            ).show()
                            groupToChooseDelete = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Rose600),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Filled.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("حذف المحدد (${selectedToDeleteKeys.size.toString().toStandardDigits()})", maxLines = 1, softWrap = false)
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { groupToChooseDelete = null }) {
                    Text("إغلاق", color = Slate500)
                }
            }
        )
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.96f)
                .fillMaxHeight(0.88f),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                // Header with Small Refresh Button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = if (duplicateGroups.isEmpty()) Emerald50 else Rose50,
                            modifier = Modifier.size(40.dp),
                            border = BorderStroke(1.dp, if (duplicateGroups.isEmpty()) Emerald200 else Rose200)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = if (duplicateGroups.isEmpty()) Icons.Filled.CheckCircle else Icons.Filled.NotificationsActive,
                                    contentDescription = null,
                                    tint = if (duplicateGroups.isEmpty()) Emerald600 else Rose600,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                        Spacer(Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                "إشعارات الأسماء المكررة",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Slate900,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                if (duplicateGroups.isEmpty()) "لا توجد أسماء مكررة حالياً"
                                else "يوجد ${duplicateGroups.size.toString().toStandardDigits()} اسم مكرر مع تفاصيل أماكن التكرار",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (duplicateGroups.isEmpty()) Emerald600 else Rose600,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        // زر صغير لتحديث والبحث عن التكرارات وإظهار المتجاهل سابقاً
                        FilledTonalButton(
                            onClick = {
                                viewModel.recheckDuplicates()
                                Toast.makeText(
                                    context,
                                    "تم تحديث حالة البحث وإظهار جميع التكرارات (بما فيها المتجاهلة سابقاً) ✓",
                                    Toast.LENGTH_SHORT
                                ).show()
                            },
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.filledTonalButtonColors(
                                containerColor = Brand50,
                                contentColor = Brand700
                            ),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            modifier = Modifier.height(32.dp)
                        ) {
                            Icon(Icons.Filled.Refresh, contentDescription = "تحديث البحث", modifier = Modifier.size(14.dp))
                            Spacer(Modifier.width(3.dp))
                            Text(
                                "تحديث وبحث",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                softWrap = false
                            )
                        }

                        IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Filled.Close, contentDescription = "إغلاق", tint = Slate500)
                        }
                    }
                }

                Spacer(Modifier.height(10.dp))

                // Info Banner explaining Refresh & Ignore behavior
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Slate50,
                    border = BorderStroke(1.dp, Slate200),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Outlined.Info, contentDescription = null, tint = Brand600, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(
                                "يمكنك تجاهل أي إشعار مؤقتاً أو اختيار النسخة المراد حذفها. الضغط على «تحديث وبحث» يعيد إظهار الأسماء المتجاهلة سابقاً.",
                                style = MaterialTheme.typography.labelSmall,
                                color = Slate600
                            )
                        }
                    }
                }

                Spacer(Modifier.height(10.dp))

                // Duplicate List or Empty State
                if (duplicateGroups.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Surface(
                                shape = CircleShape,
                                color = Emerald50,
                                modifier = Modifier.size(64.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(Icons.Outlined.Verified, contentDescription = null, tint = Emerald600, modifier = Modifier.size(36.dp))
                                }
                            }
                            Spacer(Modifier.height(14.dp))
                            Text(
                                "لا توجد أسماء مكررة حالياً",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Slate800
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                "اضغط على «تحديث وبحث» أعلاه لإعادة فحص جميع المساجد والأقسام وإظهار أي إشعارات تم تجاهلها سابقاً.",
                                style = MaterialTheme.typography.bodySmall,
                                color = Slate500,
                                textAlign = TextAlign.Center
                            )
                            Spacer(Modifier.height(16.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(
                                    onClick = {
                                        viewModel.recheckDuplicates()
                                        Toast.makeText(context, "تم تحديث البحث عن التكرارات ✓", Toast.LENGTH_SHORT).show()
                                    },
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text("تحديث وبحث عن التكرارات", maxLines = 1, softWrap = false)
                                }
                                Button(
                                    onClick = onDismiss,
                                    shape = RoundedCornerShape(8.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Emerald600)
                                ) {
                                    Text("إغلاق", maxLines = 1, softWrap = false)
                                }
                            }
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(duplicateGroups, key = { it.key }) { group ->
                            DuplicateGroupCard(
                                group = group,
                                onIgnore = {
                                    viewModel.ignoreDuplicate(group.key)
                                    Toast.makeText(
                                        context,
                                        "تم تجاهل الإشعار لـ «${group.displayName}». سيظهر مجدداً عند الضغط على زر تحديث البحث.",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                },
                                onChooseVersionToDelete = {
                                    groupToChooseDelete = group
                                },
                                onDeleteSingleInstance = { inst ->
                                    singleInstanceToDelete = inst
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DuplicateGroupCard(
    group: DuplicateGroup,
    onIgnore: () -> Unit,
    onChooseVersionToDelete: () -> Unit,
    onDeleteSingleInstance: (DuplicateStudentInstance) -> Unit
) {
    val isSameSection = group.duplicateType == DuplicateType.SAME_SECTION
    val badgeBg = if (isSameSection) Rose50 else Amber50
    val badgeBorder = if (isSameSection) Rose300 else Amber300
    val badgeText = if (isSameSection) Rose700 else Amber800

    Surface(
        shape = RoundedCornerShape(14.dp),
        color = Color.White,
        border = BorderStroke(1.dp, if (isSameSection) Rose200 else Slate200),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            // Header Row: Name + Type Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f).padding(end = 6.dp)
                ) {
                    Icon(
                        imageVector = if (isSameSection) Icons.Filled.ErrorOutline else Icons.Filled.WarningAmber,
                        contentDescription = null,
                        tint = badgeText,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        group.displayName,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Slate900,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = badgeBg,
                    border = BorderStroke(0.5.dp, badgeBorder)
                ) {
                    Text(
                        group.duplicateType.title,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = badgeText,
                        maxLines = 1,
                        softWrap = false,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(Modifier.height(4.dp))

            Text(
                group.duplicateType.description,
                style = MaterialTheme.typography.bodySmall,
                color = Slate600
            )

            Spacer(Modifier.height(8.dp))

            // Instances Details List
            Text(
                "تفاصيل أماكن تكرار الاسم (${group.instances.size.toString().toStandardDigits()} نسخ):",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = Slate700
            )
            Spacer(Modifier.height(6.dp))

            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                group.instances.forEachIndexed { idx, inst ->
                    val info = getDepartmentUiInfo(inst.department)
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Slate50,
                        border = BorderStroke(0.5.dp, Slate200),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 10.dp, vertical = 7.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f).padding(end = 6.dp)
                            ) {
                                Surface(
                                    shape = CircleShape,
                                    color = info.containerColor,
                                    border = BorderStroke(0.5.dp, info.borderColor),
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text(
                                            (idx + 1).toString().toStandardDigits(),
                                            style = MaterialTheme.typography.labelSmall,
                                            color = info.textColor,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                                Spacer(Modifier.width(8.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(
                                            inst.mosqueName,
                                            fontWeight = FontWeight.Bold,
                                            style = MaterialTheme.typography.labelMedium,
                                            color = Slate900,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Surface(
                                            shape = RoundedCornerShape(4.dp),
                                            color = info.containerColor,
                                            border = BorderStroke(0.5.dp, info.borderColor)
                                        ) {
                                            Text(
                                                inst.department,
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = info.textColor,
                                                fontSize = 10.sp,
                                                maxLines = 1,
                                                softWrap = false,
                                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                                            )
                                        }
                                    }
                                    Text(
                                        "سجل الدروس: ${inst.lessonsCount.toString().toStandardDigits()} | الاختبارات: ${inst.testsCount.toString().toStandardDigits()}",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontSize = 10.sp,
                                        color = Slate500,
                                        maxLines = 1,
                                        softWrap = false
                                    )
                                }
                            }

                            // زر حذف هذه النسخة مباشرة
                            FilledTonalButton(
                                onClick = { onDeleteSingleInstance(inst) },
                                shape = RoundedCornerShape(6.dp),
                                colors = ButtonDefaults.filledTonalButtonColors(
                                    containerColor = Rose50,
                                    contentColor = Rose600
                                ),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                modifier = Modifier.height(28.dp)
                            ) {
                                Icon(Icons.Outlined.DeleteOutline, contentDescription = "حذف هذه النسخة", modifier = Modifier.size(14.dp))
                                Spacer(Modifier.width(3.dp))
                                Text("حذف النسخة", fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(10.dp))

            // Action Buttons Bar: Choose which duplicate to delete OR Ignore notification
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onChooseVersionToDelete,
                    colors = ButtonDefaults.buttonColors(containerColor = Rose600),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    modifier = Modifier.weight(1.35f).height(36.dp)
                ) {
                    Icon(Icons.Outlined.DeleteSweep, contentDescription = null, modifier = Modifier.size(15.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(
                        "حذف نسخة مكررة (اختيار)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        softWrap = false
                    )
                }

                OutlinedButton(
                    onClick = onIgnore,
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Slate700),
                    modifier = Modifier.weight(0.95f).height(36.dp)
                ) {
                    Icon(Icons.Outlined.VisibilityOff, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(
                        "تجاهل الإشعار",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        softWrap = false
                    )
                }
            }
        }
    }
}
