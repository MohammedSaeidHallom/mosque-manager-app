package com.example.data.local

import android.content.Context
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

@Dao
interface MosqueDao {
    @Query("SELECT * FROM mosques ORDER BY createdAt ASC")
    fun getAllMosques(): Flow<List<MosqueEntity>>

    @Query("SELECT * FROM mosques ORDER BY createdAt ASC")
    suspend fun getMosquesList(): List<MosqueEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMosque(mosque: MosqueEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMosques(mosques: List<MosqueEntity>)

    @Query("DELETE FROM mosques WHERE id = :id")
    suspend fun deleteMosqueById(id: String)

    @Query("DELETE FROM mosques")
    suspend fun clearAll()
}

@Dao
interface StudentDao {
    @Query("SELECT * FROM students ORDER BY fullName ASC")
    fun getAllStudents(): Flow<List<StudentEntity>>

    @Query("SELECT * FROM students WHERE mosqueId = :mosqueId ORDER BY fullName ASC")
    fun getStudentsForMosque(mosqueId: String): Flow<List<StudentEntity>>

    @Query("SELECT * FROM students WHERE mosqueId = :mosqueId ORDER BY fullName ASC")
    suspend fun getStudentsForMosqueList(mosqueId: String): List<StudentEntity>

    @Query("SELECT * FROM students ORDER BY fullName ASC")
    suspend fun getAllStudentsList(): List<StudentEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStudents(students: List<StudentEntity>)

    @Query("DELETE FROM students WHERE mosqueId = :mosqueId")
    suspend fun deleteStudentsForMosque(mosqueId: String)

    @Query("DELETE FROM students WHERE id = :id")
    suspend fun deleteStudentById(id: String)

    @Query("DELETE FROM students")
    suspend fun clearAll()
}

@Dao
interface LessonDao {
    @Query("SELECT * FROM lessons ORDER BY timestamp DESC")
    fun getAllLessons(): Flow<List<LessonEntity>>

    @Query("SELECT * FROM lessons WHERE mosqueId = :mosqueId ORDER BY timestamp DESC")
    fun getLessonsForMosque(mosqueId: String): Flow<List<LessonEntity>>

    @Query("SELECT * FROM lessons WHERE mosqueId = :mosqueId ORDER BY timestamp DESC")
    suspend fun getLessonsForMosqueList(mosqueId: String): List<LessonEntity>

    @Query("SELECT * FROM lessons ORDER BY timestamp DESC")
    suspend fun getAllLessonsList(): List<LessonEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLessons(lessons: List<LessonEntity>)

    @Query("DELETE FROM lessons WHERE mosqueId = :mosqueId")
    suspend fun deleteLessonsForMosque(mosqueId: String)

    @Query("DELETE FROM lessons WHERE id = :id")
    suspend fun deleteLessonById(id: String)

    @Query("DELETE FROM lessons")
    suspend fun clearAll()
}

@Dao
interface TestDao {
    @Query("SELECT * FROM tests ORDER BY timestamp DESC")
    fun getAllTests(): Flow<List<TestEntity>>

    @Query("SELECT * FROM tests WHERE mosqueId = :mosqueId ORDER BY timestamp DESC")
    fun getTestsForMosque(mosqueId: String): Flow<List<TestEntity>>

    @Query("SELECT * FROM tests WHERE mosqueId = :mosqueId ORDER BY timestamp DESC")
    suspend fun getTestsForMosqueList(mosqueId: String): List<TestEntity>

    @Query("SELECT * FROM tests ORDER BY timestamp DESC")
    suspend fun getAllTestsList(): List<TestEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTests(tests: List<TestEntity>)

    @Query("DELETE FROM tests WHERE mosqueId = :mosqueId")
    suspend fun deleteTestsForMosque(mosqueId: String)

    @Query("DELETE FROM tests WHERE id = :id")
    suspend fun deleteTestById(id: String)

    @Query("DELETE FROM tests")
    suspend fun clearAll()
}

@Dao
interface JuzRecordDao {
    @Query("SELECT * FROM juz_records")
    fun getAllJuzRecords(): Flow<List<JuzRecordEntity>>

    @Query("SELECT * FROM juz_records WHERE mosqueId = :mosqueId")
    fun getJuzRecordsForMosque(mosqueId: String): Flow<List<JuzRecordEntity>>

    @Query("SELECT * FROM juz_records WHERE mosqueId = :mosqueId")
    suspend fun getJuzRecordsForMosqueList(mosqueId: String): List<JuzRecordEntity>

    @Query("SELECT * FROM juz_records")
    suspend fun getAllJuzRecordsList(): List<JuzRecordEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertJuzRecords(records: List<JuzRecordEntity>)

    @Query("DELETE FROM juz_records WHERE mosqueId = :mosqueId")
    suspend fun deleteJuzRecordsForMosque(mosqueId: String)

    @Query("DELETE FROM juz_records")
    suspend fun clearAll()
}

@Dao
interface ExamAppointmentDao {
    @Query("SELECT * FROM exam_appointments ORDER BY createdAt DESC")
    fun getAllExamAppointments(): Flow<List<ExamAppointmentEntity>>

    @Query("SELECT * FROM exam_appointments WHERE mosqueId = :mosqueId ORDER BY createdAt DESC")
    fun getExamAppointmentsForMosque(mosqueId: String): Flow<List<ExamAppointmentEntity>>

    @Query("SELECT * FROM exam_appointments WHERE mosqueId = :mosqueId ORDER BY createdAt DESC")
    suspend fun getExamAppointmentsForMosqueList(mosqueId: String): List<ExamAppointmentEntity>

    @Query("SELECT * FROM exam_appointments ORDER BY createdAt DESC")
    suspend fun getAllExamAppointmentsList(): List<ExamAppointmentEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExamAppointments(appointments: List<ExamAppointmentEntity>)

    @Query("DELETE FROM exam_appointments WHERE mosqueId = :mosqueId")
    suspend fun deleteExamAppointmentsForMosque(mosqueId: String)

    @Query("DELETE FROM exam_appointments WHERE id = :id")
    suspend fun deleteExamAppointmentById(id: String)

    @Query("DELETE FROM exam_appointments")
    suspend fun clearAll()
}

@Database(
    entities = [
        MosqueEntity::class,
        StudentEntity::class,
        LessonEntity::class,
        TestEntity::class,
        JuzRecordEntity::class,
        ExamAppointmentEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun mosqueDao(): MosqueDao
    abstract fun studentDao(): StudentDao
    abstract fun lessonDao(): LessonDao
    abstract fun testDao(): TestDao
    abstract fun juzRecordDao(): JuzRecordDao
    abstract fun examAppointmentDao(): ExamAppointmentDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE exam_appointments ADD COLUMN groupId TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE exam_appointments ADD COLUMN groupTitle TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE exam_appointments ADD COLUMN groupDateStr TEXT NOT NULL DEFAULT ''")
            }
        }

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "mosque_manager_room.db"
                )
                    .setJournalMode(JournalMode.WRITE_AHEAD_LOGGING)
                    .addMigrations(MIGRATION_1_2)
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
