package com.example.data

import android.content.Context
import android.util.Log
import androidx.room.withTransaction
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import com.example.data.local.*
import com.example.utils.numberToArabicOrdinal
import com.example.utils.toStandardDigits

@androidx.compose.runtime.Immutable
@JsonClass(generateAdapter = true)
data class MosqueDB(val mosques: List<Mosque>)

@androidx.compose.runtime.Immutable
@JsonClass(generateAdapter = true)
data class JuzRecord(
    val studentId: String = "",
    val studentName: String = "",
    val curriculum: String = "قرآن", // "قرآن", "رشيدي", "قرآن غيباً", "تجويد"
    val juzNumber: Int = 1, // 1..30 (kept for backwards compatibility)
    val juzNumbers: List<Int>? = emptyList(), // e.g. [1, 2, 3]
    val rashidiType: String? = "رشيدي كامل", // "رشيدي قسم أول", "رشيدي كامل"
    val dateStr: String = ""
) {
    val safeJuzNumbers: List<Int>
        get() = if (!juzNumbers.isNullOrEmpty()) {
            juzNumbers.distinct().sorted()
        } else if (juzNumber > 0) {
            listOf(juzNumber)
        } else {
            listOf(1)
        }

    val safeRashidiType: String
        get() = if (!rashidiType.isNullOrBlank()) rashidiType else "رشيدي كامل"

    val completionText: String
        get() = if (curriculum == "رشيدي" || curriculum.contains("رشيدي")) {
            "أنهى $safeRashidiType"
        } else {
            val parts = safeJuzNumbers
            if (parts.size > 1) {
                "أنهى الأجزاء: " + parts.joinToString(" و ") { "الجزء $it".toStandardDigits() }
            } else {
                "أنهى الجزء ${parts.firstOrNull() ?: juzNumber}".toStandardDigits()
            }
        }
}

@androidx.compose.runtime.Immutable
@JsonClass(generateAdapter = true)
data class ExamAppointment(
    val id: String = "",
    val studentId: String = "",
    val studentName: String = "",
    val section: String = "رشيدي", // "رشيدي" أو "تلاوة"
    val rashidiType: String = "رشيدي نهائي", // "رشيدي نهائي", "أول + نهائي", "رشيدي قسم أول"
    val juzNumbers: List<Int>? = emptyList(), // e.g. [1, 2, 3, 4]
    val appointmentDate: String = "لم يحدد", // عند تركها فارغة تملأ تلقائياً بكلمة "لم يحدد"
    val notes: String = "",
    val status: String = "مجدول", // "مجدول", "تم الاختبار", "مؤجل"
    val createdAt: Long = 0L,
    val groupId: String? = null,
    val groupTitle: String? = null,
    val groupDateStr: String? = null
) {
    val safeJuzNumbers: List<Int>
        get() = if (!juzNumbers.isNullOrEmpty()) juzNumbers.distinct().sorted() else listOf(1)

    val safeRashidiType: String
        get() = if (rashidiType.isNotBlank()) rashidiType else "رشيدي نهائي"

    val safeAppointmentDate: String
        get() = if (appointmentDate.isBlank()) "لم يحدد" else appointmentDate

    val displayDetails: String
        get() = if (section == "رشيدي") {
            safeRashidiType
        } else {
            val ordinals = safeJuzNumbers.map { numberToArabicOrdinal(it) }
            if (ordinals.size == 1) {
                "اختبار الجزء ${ordinals[0]}"
            } else {
                "اختبار الجزء " + ordinals.joinToString(" و")
            }
        }
}

@androidx.compose.runtime.Immutable
@JsonClass(generateAdapter = true)
data class ExamScheduleGroup(
    val id: String = "",
    val title: String = "مجموعة مواعيد الاختبار",
    val day: String = "",
    val dateStr: String = "",
    val dateFull: String = "",
    val createdAt: Long = 0L,
    val appointments: List<ExamAppointment> = emptyList()
)

@androidx.compose.runtime.Immutable
@JsonClass(generateAdapter = true)
data class Mosque(
    val id: String,
    val name: String,
    val students: List<Student>,
    val lessons: List<Lesson>,
    val tests: List<Test>,
    val juzRecords: List<JuzRecord>? = emptyList(),
    val examAppointments: List<ExamAppointment>? = emptyList(),
    val examScheduleGroups: List<ExamScheduleGroup>? = emptyList()
) {
    val safeJuzRecords: List<JuzRecord> get() = juzRecords ?: emptyList()

    val safeExamAppointments: List<ExamAppointment>
        get() = (examAppointments ?: emptyList()).map {
            if (it.appointmentDate.isBlank()) it.copy(appointmentDate = "لم يحدد") else it
        }

    /**
     * يرجع مجموعات مواعيد الاختبار المحفوظة بتاريخ اليوم الذي صُممت فيه،
     * مع تحويل أي مواعيد سابقة غير مجمّعة إلى مجموعة تلقائياً دون فقدان أي بيانات.
     */
    val safeExamScheduleGroups: List<ExamScheduleGroup>
        get() {
            val explicitGroups = examScheduleGroups ?: emptyList()
            val appts = safeExamAppointments
            if (explicitGroups.isNotEmpty()) {
                val groupedApptIds = explicitGroups.flatMap { g -> g.appointments.map { it.id } }.toSet()
                val orphans = appts.filter { it.id !in groupedApptIds }
                return if (orphans.isEmpty()) {
                    explicitGroups.map { g ->
                        g.copy(appointments = g.appointments.map { a -> a.copy(appointmentDate = a.safeAppointmentDate) })
                    }
                } else {
                    val firstGroup = explicitGroups.first()
                    val mergedFirst = firstGroup.copy(
                        appointments = (firstGroup.appointments + orphans).map { a ->
                            a.copy(appointmentDate = a.safeAppointmentDate, groupId = firstGroup.id, groupTitle = firstGroup.title, groupDateStr = firstGroup.dateStr)
                        }
                    )
                    listOf(mergedFirst) + explicitGroups.drop(1)
                }
            }
            if (appts.isEmpty()) return emptyList()
            val byGroup = appts.groupBy { appt ->
                if (!appt.groupId.isNullOrBlank()) appt.groupId
                else {
                    val date = if (appt.createdAt > 0) Date(appt.createdAt) else Date()
                    SimpleDateFormat("dd/MM/yyyy", Locale.US).format(date).toStandardDigits()
                }
            }
            return byGroup.entries.mapIndexed { idx, (key, list) ->
                val sample = list.first()
                val ts = if (sample.createdAt > 0) sample.createdAt else System.currentTimeMillis()
                val d = Date(ts)
                val dayStr = SimpleDateFormat("EEEE", Locale("ar", "EG")).format(d)
                val dStr = sample.groupDateStr?.takeIf { it.isNotBlank() }
                    ?: SimpleDateFormat("dd/MM/yyyy", Locale.US).format(d).toStandardDigits()
                val gTitle = sample.groupTitle?.takeIf { it.isNotBlank() } ?: "مجموعة مواعيد الاختبار"
                val gId = if (key.startsWith("_")) key else "_grp_${idx}_${dStr.replace("/", "")}"
                ExamScheduleGroup(
                    id = gId,
                    title = gTitle,
                    day = dayStr,
                    dateStr = dStr,
                    dateFull = "$dayStr $dStr",
                    createdAt = ts,
                    appointments = list.map {
                        it.copy(
                            appointmentDate = it.safeAppointmentDate,
                            groupId = gId,
                            groupTitle = gTitle,
                            groupDateStr = dStr
                        )
                    }
                )
            }
        }

    /**
     * يضمن إرجاع طلاب هذه المجموعة/المسجد فقط، ويمنع تسرب طلاب المجموعات الأخرى
     * إلى التقرير الشامل أو القوائم.
     */
    val scopedStudents: List<Student>
        get() {
            if (students.isEmpty()) return emptyList()
            val cleanMosqueName = name.trim()
            val hasOwnTaggedStudents = students.any {
                it.sourceMosqueName.isNullOrBlank() || it.sourceMosqueName.trim().equals(cleanMosqueName, ignoreCase = true)
            }
            return if (hasOwnTaggedStudents) {
                students.filter {
                    it.sourceMosqueName.isNullOrBlank() || it.sourceMosqueName.trim().equals(cleanMosqueName, ignoreCase = true)
                }
            } else {
                val distinctSources = students.mapNotNull { it.sourceMosqueName?.trim()?.takeIf { s -> s.isNotEmpty() } }.distinct()
                if (distinctSources.size <= 1) students else students.filter { it.sourceMosqueName?.trim() == distinctSources.first() }
            }
        }
}

object StudentDepartments {
    const val TILAWA = "قسم تلاوة"
    const val RASHIDI = "قسم رشيدي"
    const val QURAN_GHAIBAN = "قسم قرآن غيباً"
    const val TAJWEED = "قسم تجويد"

    val ALL = listOf(TILAWA, RASHIDI, QURAN_GHAIBAN, TAJWEED)

    fun normalize(dept: String?): String {
        val d = dept?.trim() ?: return TILAWA
        return when {
            d.contains("رشيدي") -> RASHIDI
            d.contains("غيب") || d.contains("حفظ") -> QURAN_GHAIBAN
            d.contains("تجويد") -> TAJWEED
            d.contains("تلاوة") || d.contains("قرآن") -> TILAWA
            ALL.contains(d) -> d
            else -> TILAWA
        }
    }
}

@androidx.compose.runtime.Immutable
@JsonClass(generateAdapter = true)
data class Student(
    val id: String,
    val fullName: String,
    val createdAt: Long,
    val department: String? = "قسم تلاوة",
    val sourceMosqueName: String? = null
) {
    val safeDepartment: String
        get() = StudentDepartments.normalize(department)
}

@androidx.compose.runtime.Immutable
@JsonClass(generateAdapter = true)
data class Lesson(
    val id: String,
    val dateFull: String,
    val day: String,
    val dateStr: String,
    val timestamp: Long,
    val records: List<LessonRecord>,
    val sections: List<String>? = emptyList()
) {
    val safeSections: List<String>
        get() = if (!sections.isNullOrEmpty()) sections else emptyList()
}

@androidx.compose.runtime.Immutable
@JsonClass(generateAdapter = true)
data class LessonRecord(
    val studentId: String,
    val studentName: String,
    val attendance: String,
    val behavior: String? = "",
    val type: String?,
    val page: String?,
    val grade: String?,
    val optTestType: String?,
    val optTestInfo: String?,
    val studentDepartment: String? = "",
    val studentMosqueName: String? = null
)

@androidx.compose.runtime.Immutable
@JsonClass(generateAdapter = true)
data class TestRecord(
    val studentId: String = "",
    val studentName: String = "",
    val attendance: String = "حضور",
    val behavior: String? = "",
    val type: String? = "",
    val info: String? = "",
    val grade: String? = "",
    val studentDepartment: String? = "",
    val studentMosqueName: String? = null
)

@androidx.compose.runtime.Immutable
@JsonClass(generateAdapter = true)
data class Test(
    val id: String,
    val title: String? = "اختبار دوري",
    val dateFull: String? = "",
    val day: String? = "",
    val dateStr: String? = "",
    val timestamp: Long? = 0L,
    val records: List<TestRecord> = emptyList(),
    val studentId: String? = null,
    val type: String? = null,
    val info: String? = null,
    val grade: String? = null,
    val date: String? = null,
    val sections: List<String>? = emptyList()
) {
    val safeSections: List<String>
        get() = if (!sections.isNullOrEmpty()) sections else emptyList()

    val displayDate: String
        get() = if (!dateStr.isNullOrEmpty()) dateStr else date ?: ""

    val displayDay: String
        get() = if (!day.isNullOrEmpty()) day else "اختبار"

    fun allRecords(mosque: Mosque): List<TestRecord> {
        if (records.isNotEmpty()) return records
        if (studentId != null) {
            val sName = mosque.scopedStudents.find { it.id == studentId }?.fullName
                ?: mosque.students.find { it.id == studentId }?.fullName
                ?: "طالب"
            return listOf(
                TestRecord(
                    studentId = studentId,
                    studentName = sName,
                    attendance = "حضور",
                    behavior = "",
                    type = type ?: "تلاوة",
                    info = info ?: "",
                    grade = grade ?: "ممتاز 100"
                )
            )
        }
        return emptyList()
    }
}

class MosqueRepository(private val context: Context) {
    private val moshi = Moshi.Builder().build()
    private val adapter = moshi.adapter(MosqueDB::class.java)
    private val file = File(context.filesDir, "mosqueDB.json")
    private val tmpFile = File(context.filesDir, "mosqueDB.json.tmp")
    private val writeLock = Any()

    private val appDatabase = AppDatabase.getInstance(context)

    private val _dbFlow = MutableStateFlow(MosqueDB(emptyList()))
    val dbFlow: StateFlow<MosqueDB> = _dbFlow.asStateFlow()

    /** يصبح true بعد انتهاء قراءة البيانات من القرص وقاعدة بيانات Room */
    private val _isLoaded = MutableStateFlow(false)
    val isLoaded: StateFlow<Boolean> = _isLoaded.asStateFlow()

    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    @Volatile
    private var lastPersistedDb: MosqueDB? = null

    init {
        // التحميل في الخلفية من Room Database مع استيراد تلقائي للملفات السابقة
        ioScope.launch { loadData() }
    }

    private fun readJsonBackupFile(): MosqueDB? {
        return try {
            val source = when {
                file.exists() && file.length() > 0 -> file
                tmpFile.exists() && tmpFile.length() > 0 -> tmpFile
                else -> null
            }
            source?.bufferedReader(Charsets.UTF_8)?.use { adapter.fromJson(it.readText()) }
        } catch (e: Exception) {
            Log.e("MosqueRepository", "Error reading JSON backup file", e)
            null
        }
    }

    private suspend fun loadDataFromRoom(): MosqueDB? {
        return try {
            val mosqueEntities = appDatabase.mosqueDao().getMosquesList()
            if (mosqueEntities.isEmpty()) return null

            val jsonDb = readJsonBackupFile()
            val jsonGroupsMap = jsonDb?.mosques?.associate { it.id to it.examScheduleGroups } ?: emptyMap()

            val mosques = mosqueEntities.map { me ->
                val students = appDatabase.studentDao().getStudentsForMosqueList(me.id).map { it.toDomain() }
                val lessons = appDatabase.lessonDao().getLessonsForMosqueList(me.id).map { it.toDomain(moshi) }
                val tests = appDatabase.testDao().getTestsForMosqueList(me.id).map { it.toDomain(moshi) }
                val juzRecords = appDatabase.juzRecordDao().getJuzRecordsForMosqueList(me.id).map { it.toDomain(moshi) }
                val appointments = appDatabase.examAppointmentDao().getExamAppointmentsForMosqueList(me.id).map { it.toDomain(moshi) }

                val tempMosque = Mosque(
                    id = me.id,
                    name = me.name,
                    students = students,
                    lessons = lessons,
                    tests = tests,
                    juzRecords = juzRecords,
                    examAppointments = appointments,
                    examScheduleGroups = jsonGroupsMap[me.id]
                )
                tempMosque.copy(examScheduleGroups = tempMosque.safeExamScheduleGroups)
            }
            MosqueDB(mosques)
        } catch (e: Exception) {
            Log.e("MosqueRepository", "Error reading Room DB", e)
            null
        }
    }

    suspend fun saveDbToRoom(db: MosqueDB) {
        try {
            val prevDb = lastPersistedDb
            appDatabase.withTransaction {
                val currentMosqueIds = db.mosques.map { it.id }.toSet()
                val existing = appDatabase.mosqueDao().getMosquesList()
                for (ex in existing) {
                    if (!currentMosqueIds.contains(ex.id)) {
                        appDatabase.mosqueDao().deleteMosqueById(ex.id)
                        appDatabase.studentDao().deleteStudentsForMosque(ex.id)
                        appDatabase.lessonDao().deleteLessonsForMosque(ex.id)
                        appDatabase.testDao().deleteTestsForMosque(ex.id)
                        appDatabase.juzRecordDao().deleteJuzRecordsForMosque(ex.id)
                        appDatabase.examAppointmentDao().deleteExamAppointmentsForMosque(ex.id)
                    }
                }

                for (m in db.mosques) {
                    val prevMosque = prevDb?.mosques?.find { it.id == m.id }
                    if (prevMosque === m) continue // لم يتغير هذا المسجد إطلاقاً -> تخطي الكتابة لسرعة فائقة

                    if (prevMosque == null || prevMosque.name != m.name) {
                        appDatabase.mosqueDao().insertMosque(MosqueEntity(m.id, m.name))
                    }

                    if (prevMosque == null || prevMosque.students !== m.students) {
                        appDatabase.studentDao().deleteStudentsForMosque(m.id)
                        appDatabase.studentDao().insertStudents(m.students.map { StudentEntity.fromDomain(m.id, it) })
                    }

                    if (prevMosque == null || prevMosque.lessons !== m.lessons) {
                        appDatabase.lessonDao().deleteLessonsForMosque(m.id)
                        appDatabase.lessonDao().insertLessons(m.lessons.map { LessonEntity.fromDomain(m.id, it, moshi) })
                    }

                    if (prevMosque == null || prevMosque.tests !== m.tests) {
                        appDatabase.testDao().deleteTestsForMosque(m.id)
                        appDatabase.testDao().insertTests(m.tests.map { TestEntity.fromDomain(m.id, it, moshi) })
                    }

                    if (prevMosque == null || prevMosque.juzRecords !== m.juzRecords) {
                        appDatabase.juzRecordDao().deleteJuzRecordsForMosque(m.id)
                        appDatabase.juzRecordDao().insertJuzRecords(m.safeJuzRecords.map { JuzRecordEntity.fromDomain(m.id, it, moshi) })
                    }

                    if (prevMosque == null || prevMosque.examAppointments !== m.examAppointments || prevMosque.examScheduleGroups !== m.examScheduleGroups) {
                        appDatabase.examAppointmentDao().deleteExamAppointmentsForMosque(m.id)
                        appDatabase.examAppointmentDao().insertExamAppointments(m.safeExamAppointments.map { ExamAppointmentEntity.fromDomain(m.id, it, moshi) })
                    }
                }
            }
            lastPersistedDb = db
        } catch (e: Exception) {
            Log.e("MosqueRepository", "Error saving to Room Database", e)
        }
    }

    private suspend fun loadData() {
        try {
            var db = loadDataFromRoom()
            if (db == null || db.mosques.isEmpty()) {
                val fileDb = readJsonBackupFile()
                if (fileDb != null && fileDb.mosques.isNotEmpty()) {
                    saveDbToRoom(fileDb)
                    db = fileDb
                }
            }
            if (db != null) {
                val normalized = normalizeDb(db)
                _dbFlow.value = normalized
                lastPersistedDb = normalized
                writeAtomically(adapter.toJson(normalized))
            }
        } catch (e: Exception) {
            Log.e("MosqueRepository", "Error loading DB", e)
        } finally {
            _isLoaded.value = true
        }
    }

    /**
     * تطبيع البيانات وعزل كل مجموعة/مسجد بطلابها فقط دون أي فرز تلقائي للأقسام.
     */
    fun normalizeDb(db: MosqueDB): MosqueDB {
        var modified = false
        val updatedMosques = db.mosques.map { mosque ->
            val scoped = mosque.scopedStudents
            var mosqueModified = scoped.size != mosque.students.size
            val updatedStudents = scoped.map { student ->
                val needsDept = student.department.isNullOrBlank()
                val needsSource = student.sourceMosqueName.isNullOrBlank() || student.sourceMosqueName != mosque.name
                if (needsDept || needsSource) {
                    mosqueModified = true
                    student.copy(
                        department = if (needsDept) StudentDepartments.TILAWA else StudentDepartments.normalize(student.department),
                        sourceMosqueName = mosque.name
                    )
                } else {
                    student
                }
            }

            val scopedIds = updatedStudents.map { it.id }.toSet()
            val cleanedLessons = mosque.lessons.map { l ->
                val filteredRecs = if (scopedIds.isNotEmpty()) l.records.filter { it.studentId in scopedIds } else l.records
                if (filteredRecs.size != l.records.size) {
                    mosqueModified = true
                    l.copy(records = filteredRecs)
                } else l
            }

            val groups = mosque.safeExamScheduleGroups
            val syncedAppts = groups.flatMap { g ->
                g.appointments.map { a ->
                    a.copy(
                        appointmentDate = a.safeAppointmentDate,
                        groupId = g.id,
                        groupTitle = g.title,
                        groupDateStr = g.dateStr
                    )
                }
            }

            if (mosqueModified || mosque.examScheduleGroups == null) {
                modified = true
                mosque.copy(
                    students = updatedStudents,
                    lessons = cleanedLessons,
                    examAppointments = syncedAppts,
                    examScheduleGroups = groups
                )
            } else {
                mosque
            }
        }
        val result = if (modified) db.copy(mosques = updatedMosques) else db
        if (modified) {
            persistAsync(result)
        }
        return result
    }

    fun updateMemory(db: MosqueDB) {
        _dbFlow.value = db
    }

    /** كتابة ذرّية: نكتب في ملف مؤقت ثم نستبدل الأصلي، فلا يتلف الملف إذا أُغلق التطبيق أثناء الحفظ. */
    private fun writeAtomically(json: String) {
        synchronized(writeLock) {
            tmpFile.writeText(json, Charsets.UTF_8)
            if (!tmpFile.renameTo(file)) {
                file.writeText(json, Charsets.UTF_8)
                tmpFile.delete()
            }
        }
    }

    suspend fun saveDbToDisk(db: MosqueDB) = withContext(Dispatchers.IO) {
        try {
            saveDbToRoom(db)
            writeAtomically(adapter.toJson(db))
        } catch (e: Exception) {
            Log.e("MosqueRepository", "Error saving DB", e)
        }
    }

    /** حفظ فوري لا يُلغى عند إغلاق الـ ViewModel (يُستخدم عند الخروج من الشاشة/التطبيق). */
    fun persistAsync(db: MosqueDB) {
        ioScope.launch {
            try {
                saveDbToRoom(db)
                writeAtomically(adapter.toJson(db))
            } catch (e: Exception) {
                Log.e("MosqueRepository", "Error saving DB", e)
            }
        }
    }

    suspend fun saveDb(db: MosqueDB) {
        updateMemory(db)
        saveDbToDisk(db)
    }

    suspend fun importDb(json: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val db = adapter.fromJson(json)
            if (db != null) {
                lastPersistedDb = null
                val normalized = normalizeDb(db)
                saveDbToRoom(normalized)
                writeAtomically(adapter.toJson(normalized))
                _dbFlow.value = normalized
                true
            } else {
                false
            }
        } catch (e: Exception) {
            Log.e("MosqueRepository", "Error importing DB", e)
            false
        }
    }

    /** التصدير يتم على خيط الخلفية لأن تحويل كل البيانات إلى JSON قد يكون ثقيلاً. */
    suspend fun exportDb(): String? = withContext(Dispatchers.IO) {
        try {
            adapter.toJson(_dbFlow.value)
        } catch (e: Exception) {
            Log.e("MosqueRepository", "Error exporting DB", e)
            null
        }
    }
}
