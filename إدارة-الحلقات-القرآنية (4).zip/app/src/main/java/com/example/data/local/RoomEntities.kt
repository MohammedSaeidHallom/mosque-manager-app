package com.example.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.example.data.*
import com.squareup.moshi.JsonAdapter
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types

object RoomJsonAdapters {
    @Volatile
    private var stringListAdapter: JsonAdapter<List<String>>? = null
    @Volatile
    private var intListAdapter: JsonAdapter<List<Int>>? = null
    @Volatile
    private var lessonRecordListAdapter: JsonAdapter<List<LessonRecord>>? = null
    @Volatile
    private var testRecordListAdapter: JsonAdapter<List<TestRecord>>? = null

    fun stringList(moshi: Moshi): JsonAdapter<List<String>> {
        return stringListAdapter ?: synchronized(this) {
            stringListAdapter ?: moshi.adapter<List<String>>(
                Types.newParameterizedType(List::class.java, String::class.java)
            ).also { stringListAdapter = it }
        }
    }

    fun intList(moshi: Moshi): JsonAdapter<List<Int>> {
        return intListAdapter ?: synchronized(this) {
            intListAdapter ?: moshi.adapter<List<Int>>(
                Types.newParameterizedType(List::class.java, Integer::class.java)
            ).also { intListAdapter = it }
        }
    }

    fun lessonRecordList(moshi: Moshi): JsonAdapter<List<LessonRecord>> {
        return lessonRecordListAdapter ?: synchronized(this) {
            lessonRecordListAdapter ?: moshi.adapter<List<LessonRecord>>(
                Types.newParameterizedType(List::class.java, LessonRecord::class.java)
            ).also { lessonRecordListAdapter = it }
        }
    }

    fun testRecordList(moshi: Moshi): JsonAdapter<List<TestRecord>> {
        return testRecordListAdapter ?: synchronized(this) {
            testRecordListAdapter ?: moshi.adapter<List<TestRecord>>(
                Types.newParameterizedType(List::class.java, TestRecord::class.java)
            ).also { testRecordListAdapter = it }
        }
    }
}

@Entity(tableName = "mosques")
data class MosqueEntity(
    @PrimaryKey val id: String,
    val name: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "students",
    indices = [Index(value = ["mosqueId"])]
)
data class StudentEntity(
    @PrimaryKey val id: String,
    val mosqueId: String,
    val fullName: String,
    val createdAt: Long,
    val department: String? = "قسم تلاوة",
    val sourceMosqueName: String? = null
) {
    fun toDomain(): Student = Student(
        id = id,
        fullName = fullName,
        createdAt = createdAt,
        department = department,
        sourceMosqueName = sourceMosqueName
    )

    companion object {
        fun fromDomain(mosqueId: String, student: Student): StudentEntity = StudentEntity(
            id = student.id,
            mosqueId = mosqueId,
            fullName = student.fullName,
            createdAt = student.createdAt,
            department = student.department,
            sourceMosqueName = student.sourceMosqueName
        )
    }
}

@Entity(
    tableName = "lessons",
    indices = [Index(value = ["mosqueId"])]
)
data class LessonEntity(
    @PrimaryKey val id: String,
    val mosqueId: String,
    val dateFull: String,
    val day: String,
    val dateStr: String,
    val timestamp: Long,
    val sectionsJson: String = "[]",
    val recordsJson: String = "[]"
) {
    fun toDomain(moshi: Moshi): Lesson {
        val sectionsList = try { RoomJsonAdapters.stringList(moshi).fromJson(sectionsJson) ?: emptyList() } catch (e: Exception) { emptyList() }
        val recordsList = try { RoomJsonAdapters.lessonRecordList(moshi).fromJson(recordsJson) ?: emptyList() } catch (e: Exception) { emptyList() }

        return Lesson(
            id = id,
            dateFull = dateFull,
            day = day,
            dateStr = dateStr,
            timestamp = timestamp,
            sections = sectionsList,
            records = recordsList
        )
    }

    companion object {
        fun fromDomain(mosqueId: String, lesson: Lesson, moshi: Moshi): LessonEntity {
            val sectionsJson = RoomJsonAdapters.stringList(moshi).toJson(lesson.safeSections)
            val recordsJson = RoomJsonAdapters.lessonRecordList(moshi).toJson(lesson.records)

            return LessonEntity(
                id = lesson.id,
                mosqueId = mosqueId,
                dateFull = lesson.dateFull,
                day = lesson.day,
                dateStr = lesson.dateStr,
                timestamp = lesson.timestamp,
                sectionsJson = sectionsJson,
                recordsJson = recordsJson
            )
        }
    }
}

@Entity(
    tableName = "tests",
    indices = [Index(value = ["mosqueId"])]
)
data class TestEntity(
    @PrimaryKey val id: String,
    val mosqueId: String,
    val title: String,
    val dateFull: String,
    val day: String,
    val dateStr: String,
    val timestamp: Long?,
    val sectionsJson: String = "[]",
    val recordsJson: String = "[]"
) {
    fun toDomain(moshi: Moshi): Test {
        val sectionsList = try { RoomJsonAdapters.stringList(moshi).fromJson(sectionsJson) ?: emptyList() } catch (e: Exception) { emptyList() }
        val recordsList = try { RoomJsonAdapters.testRecordList(moshi).fromJson(recordsJson) ?: emptyList() } catch (e: Exception) { emptyList() }

        return Test(
            id = id,
            title = title,
            dateFull = dateFull,
            day = day,
            dateStr = dateStr,
            timestamp = timestamp,
            sections = sectionsList,
            records = recordsList
        )
    }

    companion object {
        fun fromDomain(mosqueId: String, test: Test, moshi: Moshi): TestEntity {
            val sectionsJson = RoomJsonAdapters.stringList(moshi).toJson(test.safeSections)
            val recordsJson = RoomJsonAdapters.testRecordList(moshi).toJson(test.records)

            return TestEntity(
                id = test.id,
                mosqueId = mosqueId,
                title = test.title ?: "اختبار دوري",
                dateFull = test.dateFull ?: "",
                day = test.day ?: "",
                dateStr = test.dateStr ?: "",
                timestamp = test.timestamp,
                sectionsJson = sectionsJson,
                recordsJson = recordsJson
            )
        }
    }
}

@Entity(
    tableName = "juz_records",
    indices = [Index(value = ["mosqueId"])]
)
data class JuzRecordEntity(
    @PrimaryKey val id: String,
    val mosqueId: String,
    val studentId: String,
    val studentName: String,
    val curriculum: String,
    val juzNumber: Int,
    val juzNumbersJson: String = "[]",
    val rashidiType: String?,
    val dateStr: String
) {
    fun toDomain(moshi: Moshi): JuzRecord {
        val numbers = try { RoomJsonAdapters.intList(moshi).fromJson(juzNumbersJson) ?: listOf(juzNumber) } catch (e: Exception) { listOf(juzNumber) }

        return JuzRecord(
            studentId = studentId,
            studentName = studentName,
            curriculum = curriculum,
            juzNumber = juzNumber,
            juzNumbers = numbers,
            rashidiType = rashidiType,
            dateStr = dateStr
        )
    }

    companion object {
        fun fromDomain(mosqueId: String, record: JuzRecord, moshi: Moshi): JuzRecordEntity {
            val json = RoomJsonAdapters.intList(moshi).toJson(record.safeJuzNumbers)
            val key = "${mosqueId}_${record.studentId}_${record.curriculum}"

            return JuzRecordEntity(
                id = key,
                mosqueId = mosqueId,
                studentId = record.studentId,
                studentName = record.studentName,
                curriculum = record.curriculum,
                juzNumber = record.juzNumber,
                juzNumbersJson = json,
                rashidiType = record.rashidiType,
                dateStr = record.dateStr
            )
        }
    }
}

@Entity(
    tableName = "exam_appointments",
    indices = [Index(value = ["mosqueId"])]
)
data class ExamAppointmentEntity(
    @PrimaryKey val id: String,
    val mosqueId: String,
    val studentId: String,
    val studentName: String,
    val section: String,
    val rashidiType: String,
    val juzNumbersJson: String = "[]",
    val appointmentDate: String,
    val notes: String,
    val status: String,
    val createdAt: Long,
    val groupId: String = "",
    val groupTitle: String = "",
    val groupDateStr: String = ""
) {
    fun toDomain(moshi: Moshi): ExamAppointment {
        val numbers = try { RoomJsonAdapters.intList(moshi).fromJson(juzNumbersJson) ?: emptyList() } catch (e: Exception) { emptyList() }

        return ExamAppointment(
            id = id,
            studentId = studentId,
            studentName = studentName,
            section = section,
            rashidiType = rashidiType,
            juzNumbers = numbers,
            appointmentDate = if (appointmentDate.isBlank()) "لم يحدد" else appointmentDate,
            notes = notes,
            status = status,
            createdAt = createdAt,
            groupId = groupId.ifBlank { null },
            groupTitle = groupTitle.ifBlank { null },
            groupDateStr = groupDateStr.ifBlank { null }
        )
    }

    companion object {
        fun fromDomain(mosqueId: String, appt: ExamAppointment, moshi: Moshi): ExamAppointmentEntity {
            val json = RoomJsonAdapters.intList(moshi).toJson(appt.safeJuzNumbers)

            return ExamAppointmentEntity(
                id = appt.id,
                mosqueId = mosqueId,
                studentId = appt.studentId,
                studentName = appt.studentName,
                section = appt.section,
                rashidiType = appt.rashidiType,
                juzNumbersJson = json,
                appointmentDate = appt.safeAppointmentDate,
                notes = appt.notes,
                status = appt.status,
                createdAt = appt.createdAt,
                groupId = appt.groupId ?: "",
                groupTitle = appt.groupTitle ?: "",
                groupDateStr = appt.groupDateStr ?: ""
            )
        }
    }
}
