package com.example.utils

import com.example.data.Lesson
import java.text.SimpleDateFormat
import java.util.*

enum class ReportPeriodMode {
    WEEKLY, MONTHLY, ALL
}

data class ReportPeriodFilter(
    val mode: ReportPeriodMode = ReportPeriodMode.WEEKLY,
    val isWeeklyLast7Days: Boolean = true, // if true: last 7 days based on lessons
    val selectedYear: Int = Calendar.getInstance().get(Calendar.YEAR),
    val selectedMonth: Int = Calendar.getInstance().get(Calendar.MONTH) + 1, // 1..12
    val selectedWeekIndex: Int = 1 // 1..5
)

data class MonthItem(
    val year: Int,
    val month: Int,
    val label: String
)

data class WeekOption(
    val index: Int,
    val label: String,
    val startDay: Int,
    val endDay: Int
)

object ReportFilterUtils {

    fun getArabicMonthName(month: Int): String {
        return when (month) {
            1 -> "يناير"
            2 -> "فبراير"
            3 -> "مارس"
            4 -> "أبريل"
            5 -> "مايو"
            6 -> "يونيو"
            7 -> "يوليو"
            8 -> "أغسطس"
            9 -> "سبتمبر"
            10 -> "أكتوبر"
            11 -> "نوفمبر"
            12 -> "ديسمبر"
            else -> "شهر $month"
        }
    }

    val weekOptions = listOf(
        WeekOption(1, "الأسبوع الأول (1 - 7)", 1, 7),
        WeekOption(2, "الأسبوع الثاني (8 - 14)", 8, 14),
        WeekOption(3, "الأسبوع الثالث (15 - 21)", 15, 21),
        WeekOption(4, "الأسبوع الرابع (22 - 28)", 22, 28),
        WeekOption(5, "الأسبوع الخامس (29 - نهاية الشهر)", 29, 31)
    )

    fun parseLessonDate(lesson: Lesson): Calendar {
        val cal = Calendar.getInstance()
        if (!lesson.dateStr.isNullOrBlank()) {
            try {
                val parts = lesson.dateStr.trim().split("/", "-")
                if (parts.size >= 3) {
                    val d = parts[0].trim().toIntOrNull() ?: 1
                    val m = parts[1].trim().toIntOrNull() ?: 1
                    val y = parts[2].trim().toIntOrNull() ?: cal.get(Calendar.YEAR)
                    cal.set(Calendar.YEAR, y)
                    cal.set(Calendar.MONTH, m - 1)
                    cal.set(Calendar.DAY_OF_MONTH, d)
                    cal.set(Calendar.HOUR_OF_DAY, 12)
                    cal.set(Calendar.MINUTE, 0)
                    cal.set(Calendar.SECOND, 0)
                    cal.set(Calendar.MILLISECOND, 0)
                    return cal
                }
            } catch (_: Exception) {}
        }
        if (lesson.timestamp > 0) {
            cal.timeInMillis = lesson.timestamp
            cal.set(Calendar.HOUR_OF_DAY, 12)
            cal.set(Calendar.MINUTE, 0)
            cal.set(Calendar.SECOND, 0)
            cal.set(Calendar.MILLISECOND, 0)
        }
        return cal
    }

    /**
     * Extracts all distinct (Year, Month) pairs from entered lessons,
     * sorted descending (latest months first).
     */
    fun getAvailableMonths(lessons: List<Lesson>): List<MonthItem> {
        val curCal = Calendar.getInstance()
        val currentYear = curCal.get(Calendar.YEAR)
        val currentMonth = curCal.get(Calendar.MONTH) + 1

        val list = mutableSetOf<Pair<Int, Int>>()
        // Always include current month
        list.add(Pair(currentYear, currentMonth))

        lessons.forEach { lesson ->
            val cal = parseLessonDate(lesson)
            val y = cal.get(Calendar.YEAR)
            val m = cal.get(Calendar.MONTH) + 1
            list.add(Pair(y, m))
        }

        return list.sortedWith(compareByDescending<Pair<Int, Int>> { it.first }.thenByDescending { it.second })
            .map { (y, m) ->
                val monthName = getArabicMonthName(m)
                MonthItem(
                    year = y,
                    month = m,
                    label = "شهر $m ($monthName) $y".toStandardDigits()
                )
            }
    }

    /**
     * Filters lessons based on the selected period and returns both the filtered lessons
     * and a descriptive title for display and report headers.
     */
    fun filterLessons(lessons: List<Lesson>, filter: ReportPeriodFilter): Pair<List<Lesson>, String> {
        if (lessons.isEmpty()) {
            val title = when (filter.mode) {
                ReportPeriodMode.ALL -> "التقرير الشامل"
                ReportPeriodMode.MONTHLY -> "التقرير الشهري (شهر ${filter.selectedMonth})".toStandardDigits()
                ReportPeriodMode.WEEKLY -> if (filter.isWeeklyLast7Days) "التقرير الأسبوعي (آخر 7 أيام)" else "التقرير الأسبوعي"
            }
            return Pair(emptyList(), title)
        }

        val lessonsWithCal = lessons.map { it to parseLessonDate(it) }

        return when (filter.mode) {
            ReportPeriodMode.ALL -> {
                Pair(lessons, "التقرير الشامل التراكمي (جميع الدروس)")
            }
            ReportPeriodMode.MONTHLY -> {
                val filtered = lessonsWithCal.filter { (_, cal) ->
                    cal.get(Calendar.YEAR) == filter.selectedYear && (cal.get(Calendar.MONTH) + 1) == filter.selectedMonth
                }.map { it.first }

                val monthName = getArabicMonthName(filter.selectedMonth)
                val title = "التقرير الشهري: شهر ${filter.selectedMonth} ($monthName) ${filter.selectedYear}".toStandardDigits()
                Pair(filtered, title)
            }
            ReportPeriodMode.WEEKLY -> {
                if (filter.isWeeklyLast7Days) {
                    // Find the latest lesson date
                    val latestCal = lessonsWithCal.maxByOrNull { it.second.timeInMillis }?.second ?: Calendar.getInstance()
                    
                    val endCal = Calendar.getInstance().apply {
                        timeInMillis = latestCal.timeInMillis
                        set(Calendar.HOUR_OF_DAY, 23)
                        set(Calendar.MINUTE, 59)
                        set(Calendar.SECOND, 59)
                        set(Calendar.MILLISECOND, 999)
                    }
                    val startCal = Calendar.getInstance().apply {
                        timeInMillis = endCal.timeInMillis
                        add(Calendar.DAY_OF_YEAR, -6)
                        set(Calendar.HOUR_OF_DAY, 0)
                        set(Calendar.MINUTE, 0)
                        set(Calendar.SECOND, 0)
                        set(Calendar.MILLISECOND, 0)
                    }

                    val filtered = lessonsWithCal.filter { (_, cal) ->
                        cal.timeInMillis in startCal.timeInMillis..endCal.timeInMillis
                    }.map { it.first }

                    val sdf = SimpleDateFormat("dd/MM/yyyy", Locale.US)
                    val startStr = sdf.format(startCal.time).toStandardDigits()
                    val endStr = sdf.format(endCal.time).toStandardDigits()

                    val title = "التقرير الأسبوعي: آخر 7 أيام ($startStr - $endStr)"
                    Pair(filtered, title)
                } else {
                    // Specific week in selected month
                    val weekOpt = weekOptions.find { it.index == filter.selectedWeekIndex } ?: weekOptions[0]
                    val filtered = lessonsWithCal.filter { (_, cal) ->
                        val y = cal.get(Calendar.YEAR)
                        val m = cal.get(Calendar.MONTH) + 1
                        val d = cal.get(Calendar.DAY_OF_MONTH)
                        y == filter.selectedYear && m == filter.selectedMonth && d in weekOpt.startDay..weekOpt.endDay
                    }.map { it.first }

                    val monthName = getArabicMonthName(filter.selectedMonth)
                    val title = "التقرير الأسبوعي: ${weekOpt.label} - شهر ${filter.selectedMonth} ($monthName) ${filter.selectedYear}".toStandardDigits()
                    Pair(filtered, title)
                }
            }
        }
    }
}
