package com.example.utils

import com.example.data.Mosque
import com.example.data.Student

data class StudentReward(
    val studentId: String,
    val studentName: String,
    val category: String, // "تلاوة", "رشيدي", "قرآن غيباً"
    val fullMarksCount: Int,
    val politeCount: Int,
    val presentCount: Int,
    val absentCount: Int,
    val excusedCount: Int,
    val rankInCategory: Int,
    val starsCount: Int,
    val starsDisplay: String,
    val giftBadge: String,
    val behaviorStatus: String,
    val rankTitle: String = "مشارك"
)

object RewardCalculator {

    const val CATEGORY_TILAWA = "تلاوة"
    const val CATEGORY_RASHIDI = "رشيدي"
    const val CATEGORY_MEMORIZATION = "قرآن غيباً"

    fun determineCategory(
        student: Student,
        studentRecords: List<com.example.data.LessonRecord>,
        studentTests: List<com.example.data.TestRecord>
    ): String {
        val dept = student.safeDepartment
        if (dept.contains("رشيدي")) return CATEGORY_RASHIDI
        if (dept.contains("غيب") || dept.contains("حفظ")) return CATEGORY_MEMORIZATION

        if (studentRecords.isNotEmpty()) {
            val typeCounts = studentRecords.mapNotNull { it.type }.groupingBy { it }.eachCount()
            val dominantType = typeCounts.maxByOrNull { it.value }?.key ?: ""
            if (dominantType.contains("رشيدي")) return CATEGORY_RASHIDI
            if (dominantType.contains("غيب") || dominantType.contains("حفظ")) return CATEGORY_MEMORIZATION
            if (dominantType.contains("تلاوة")) return CATEGORY_TILAWA
        }

        if (studentTests.isNotEmpty()) {
            val dominantTest = studentTests.mapNotNull { it.type }.groupingBy { it }.eachCount().maxByOrNull { it.value }?.key ?: ""
            if (dominantTest.contains("رشيدي")) return CATEGORY_RASHIDI
            if (dominantTest.contains("غيب") || dominantTest.contains("حفظ")) return CATEGORY_MEMORIZATION
        }

        return CATEGORY_TILAWA
    }

    fun determineCategory(student: Student, mosque: Mosque): String {
        val studentRecords = mosque.lessons.flatMap { it.records }.filter { it.studentId == student.id }
        val studentTests = mosque.tests.flatMap { it.allRecords(mosque) }.filter { it.studentId == student.id }
        return determineCategory(student, studentRecords, studentTests)
    }

    fun calculateRewards(mosque: Mosque): List<StudentReward> {
        val scopedStudents = mosque.scopedStudents
        if (scopedStudents.isEmpty()) return emptyList()

        val recordsByStudent = mosque.lessons.asSequence().flatMap { it.records.asSequence() }.groupBy { it.studentId }
        val testsByStudent = mosque.tests.asSequence().flatMap { it.allRecords(mosque).asSequence() }.groupBy { it.studentId }

        val studentStats = scopedStudents.map { student ->
            val records = recordsByStudent[student.id] ?: emptyList()
            val tests = testsByStudent[student.id] ?: emptyList()

            val present = records.count { it.attendance == "حضور" }
            val absent = records.count { it.attendance == "غائب" }
            val excused = records.count { it.attendance == "إذن" }

            val polite = records.count { it.behavior == "مؤدب" } + tests.count { it.behavior == "مؤدب" }

            val fullMarksInLessons = records.count { (it.grade ?: "").contains("100") || (it.grade ?: "").contains("ممتاز") }
            val fullMarksInTests = tests.count { (it.grade ?: "").contains("100") || (it.grade ?: "").contains("ممتاز") }
            val totalFullMarks = fullMarksInLessons + fullMarksInTests

            val category = determineCategory(student, records, tests)

            val behaviorStatus = when {
                polite > 0 -> "🌟 مؤدب ($polite)"
                else -> "منتظم"
            }

            StudentRawStat(
                studentId = student.id,
                studentName = student.fullName,
                category = category,
                fullMarksCount = totalFullMarks,
                politeCount = polite,
                presentCount = present,
                absentCount = absent,
                excusedCount = excused,
                behaviorStatus = behaviorStatus
            )
        }

        val allCategories = listOf(CATEGORY_TILAWA, CATEGORY_RASHIDI, CATEGORY_MEMORIZATION)
        val finalRewards = mutableListOf<StudentReward>()

        allCategories.forEach { cat ->
            val catStudents = studentStats.filter { it.category == cat }
                .sortedWith(
                    compareByDescending<StudentRawStat> { it.fullMarksCount }
                        .thenByDescending { it.politeCount }
                        .thenByDescending { it.presentCount }
                        .thenBy { it.absentCount }
                        .thenBy { it.studentName }
                )

            catStudents.forEachIndexed { index, stat ->
                val rank = index + 1
                val starsCount = when {
                    rank <= 3 -> 3
                    rank <= 8 -> 2
                    else -> 1
                }
                val starsDisplay = when (starsCount) {
                    3 -> "⭐⭐⭐"
                    2 -> "⭐⭐"
                    else -> "⭐"
                }
                val giftBadge = when (starsCount) {
                    3 -> "🏆 3 نجوم (هدية كبرى)"
                    2 -> "🎁 نجمتان (هدية مميزة)"
                    else -> "⭐ نجمة (هدية تشجيعية)"
                }

                finalRewards.add(
                    StudentReward(
                        studentId = stat.studentId,
                        studentName = stat.studentName,
                        category = stat.category,
                        fullMarksCount = stat.fullMarksCount,
                        politeCount = stat.politeCount,
                        presentCount = stat.presentCount,
                        absentCount = stat.absentCount,
                        excusedCount = stat.excusedCount,
                        rankInCategory = rank,
                        starsCount = starsCount,
                        starsDisplay = starsDisplay,
                        giftBadge = giftBadge,
                        behaviorStatus = stat.behaviorStatus,
                        rankTitle = when (starsCount) {
                            3 -> "ممتاز (متفوق)"
                            2 -> "جيد جداً (متميز)"
                            else -> "منتظم ومجتهد"
                        }
                    )
                )
            }
        }

        val processedIds = finalRewards.map { it.studentId }.toSet()
        val remaining = studentStats.filter { it.studentId !in processedIds }
        remaining.forEachIndexed { index, stat ->
            val rank = index + 1
            finalRewards.add(
                StudentReward(
                    studentId = stat.studentId,
                    studentName = stat.studentName,
                    category = stat.category,
                    fullMarksCount = stat.fullMarksCount,
                    politeCount = stat.politeCount,
                    presentCount = stat.presentCount,
                    absentCount = stat.absentCount,
                    excusedCount = stat.excusedCount,
                    rankInCategory = rank,
                    starsCount = 1,
                    starsDisplay = "⭐",
                    giftBadge = "⭐ نجمة (هدية تشجيعية)",
                    behaviorStatus = stat.behaviorStatus
                )
            )
        }

        return finalRewards
    }

    private data class StudentRawStat(
        val studentId: String,
        val studentName: String,
        val category: String,
        val fullMarksCount: Int,
        val politeCount: Int,
        val presentCount: Int,
        val absentCount: Int,
        val excusedCount: Int,
        val behaviorStatus: String
    )
}
