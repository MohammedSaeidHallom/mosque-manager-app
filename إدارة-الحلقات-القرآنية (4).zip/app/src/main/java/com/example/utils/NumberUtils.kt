package com.example.utils

/**
 * Ensures all numbers across the application use standard Arabic numerals "123" (0-9)
 * and normalizes any Eastern Arabic-Indic numerals (٠-٩) to standard digits.
 */
fun String?.toStandardDigits(): String {
    if (this == null || this.isEmpty()) return this ?: ""
    val builder = StringBuilder(this.length)
    for (ch in this) {
        when (ch) {
            '٠', '۰' -> builder.append('0')
            '١', '۱' -> builder.append('1')
            '٢', '۲' -> builder.append('2')
            '٣', '۳' -> builder.append('3')
            '٤', '۴' -> builder.append('4')
            '٥', '۵' -> builder.append('5')
            '٦', '۶' -> builder.append('6')
            '٧', '۷' -> builder.append('7')
            '٨', '۸' -> builder.append('8')
            '٩', '۹' -> builder.append('9')
            else -> builder.append(ch)
        }
    }
    return builder.toString()
}

fun formatStandardDate(date: java.util.Date, pattern: String): String {
    val sdf = java.text.SimpleDateFormat(pattern, java.util.Locale("ar", "SA"))
    return sdf.format(date).toStandardDigits()
}

fun numberToArabicOrdinal(n: Int): String {
    return when (n) {
        1 -> "الأول"
        2 -> "الثاني"
        3 -> "الثالث"
        4 -> "الرابع"
        5 -> "الخامس"
        6 -> "السادس"
        7 -> "السابع"
        8 -> "الثامن"
        9 -> "التاسع"
        10 -> "العاشر"
        11 -> "الحادي عشر"
        12 -> "الثاني عشر"
        13 -> "الثالث عشر"
        14 -> "الرابع عشر"
        15 -> "الخامس عشر"
        16 -> "السادس عشر"
        17 -> "السابع عشر"
        18 -> "الثامن عشر"
        19 -> "التاسع عشر"
        20 -> "العشرون"
        21 -> "الحادي والعشرون"
        22 -> "الثاني والعشرون"
        23 -> "الثالث والعشرون"
        24 -> "الرابع والعشرون"
        25 -> "الخامس والعشرون"
        26 -> "السادس والعشرون"
        27 -> "السابع والعشرون"
        28 -> "الثامن والعشرون"
        29 -> "التاسع والعشرون"
        30 -> "الثلاثون"
        else -> n.toString().toStandardDigits()
    }
}

fun formatJuzOrdinalsJoined(numbers: List<Int>): String {
    val sorted = numbers.distinct().sorted()
    if (sorted.isEmpty()) return "الجزء الأول"
    val ordinals = sorted.map { numberToArabicOrdinal(it) }
    return if (ordinals.size == 1) {
        "الجزء ${ordinals[0]}"
    } else {
        "الجزء " + ordinals.joinToString(" و")
    }
}

fun formatJuzDigitsJoined(numbers: List<Int>): String {
    val sorted = numbers.distinct().sorted()
    if (sorted.isEmpty()) return "الجزء 1"
    return if (sorted.size == 1) {
        "الجزء ${sorted[0].toString().toStandardDigits()}"
    } else {
        "الأجزاء " + sorted.joinToString(" و ") { it.toString().toStandardDigits() }
    }
}

