package com.example.utils

import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.data.Mosque
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object PdfGenerator {

    private const val PAGE_WIDTH = 595
    private const val PAGE_HEIGHT = 842
    private const val MARGIN = 30f

    private fun formatBehaviorForPdf(behavior: String?): String {
        return when (behavior?.trim()) {
            "مؤدب" -> "🌟 مؤدب"
            "يحتاج هدوء" -> "يحتاج هدوء"
            else -> "-"
        }
    }

    private fun formatGradeForPdf(grade: String?): String {
        val g = grade?.ifEmpty { "-" } ?: "-"
        return when {
            g.contains("100") -> "$g 💯"
            g.contains("ممتاز") -> "$g ⭐"
            else -> g
        }
    }

    suspend fun generatePdf(
        context: Context,
        mosque: Mosque,
        currentTab: String,
        openedLessonId: String?,
        openedTestId: String? = null,
        reportStudentId: String?,
        shareAsImage: Boolean = false,
        targetPackage: String? = null,
        reportPeriodTitle: String? = null
    ) = withContext(Dispatchers.IO) {
        if (currentTab == "GIFTS" && shareAsImage) {
            val giftsBitmap = renderGiftsScreenBitmap(mosque)
            shareBitmapAsImage(context, mosque, giftsBitmap, targetPackage)
            return@withContext
        }

        val scopedStudents = mosque.scopedStudents
        val scopedStudentIds = scopedStudents.map { it.id }.toSet()

        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, 1).create()
        var page = document.startPage(pageInfo)
        var canvas = page.canvas
        var pageNum = 1

        val normalPaint = Paint().apply {
            color = Color.parseColor("#1E293B")
            textSize = 10.5f
            isAntiAlias = true
            isSubpixelText = true
            textAlign = Paint.Align.RIGHT
        }
        val headerPaint = Paint().apply {
            color = Color.parseColor("#0B6659")
            textSize = 20f
            isAntiAlias = true
            isSubpixelText = true
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }
        val subHeaderPaint = Paint().apply {
            color = Color.parseColor("#0F172A")
            textSize = 15f
            isAntiAlias = true
            isSubpixelText = true
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }
        val sectionTitlePaint = Paint().apply {
            color = Color.parseColor("#0A5247")
            textSize = 13f
            isAntiAlias = true
            isSubpixelText = true
            isFakeBoldText = true
            textAlign = Paint.Align.RIGHT
        }
        val tableHeaderPaint = Paint().apply {
            color = Color.WHITE
            textSize = 10.5f
            isAntiAlias = true
            isSubpixelText = true
            isFakeBoldText = true
            textAlign = Paint.Align.RIGHT
        }
        val footerPaint = Paint().apply {
            color = Color.parseColor("#64748B")
            textSize = 9f
            isAntiAlias = true
            isSubpixelText = true
            textAlign = Paint.Align.CENTER
        }

        val normalMosquePaint = Paint().apply {
            color = Color.parseColor("#1E293B")
            textSize = 13f
            isAntiAlias = true
            isSubpixelText = true
            textAlign = Paint.Align.CENTER
        }

        var yPos = 36f

        fun drawHeader() {
            if (currentTab == "JUZ") {
                val day = SimpleDateFormat("EEEE", Locale("ar", "EG")).format(Date())
                val dateStr = SimpleDateFormat("dd/MM/yyyy", Locale.US).format(Date()).toStandardDigits()
                canvas.drawText("بسم الله الرحمن الرحيم", PAGE_WIDTH / 2f, yPos, subHeaderPaint)
                yPos += 18f
                canvas.drawText("بفضل الله سبحانه وتعالى", PAGE_WIDTH / 2f, yPos, subHeaderPaint)
                yPos += 18f
                canvas.drawText(mosque.name, PAGE_WIDTH / 2f, yPos, normalMosquePaint)
                yPos += 20f
                canvas.drawText("السجل - $day $dateStr", PAGE_WIDTH / 2f, yPos, subHeaderPaint)
                yPos += 22f
            } else {
                canvas.drawText("بسم الله الرحمن الرحيم", PAGE_WIDTH / 2f, yPos, subHeaderPaint)
                yPos += 20f
                canvas.drawText(mosque.name, PAGE_WIDTH / 2f, yPos, headerPaint)
                yPos += 26f
            }
        }

        fun drawFooter() {
            val dateStr = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.US).format(Date()).toStandardDigits()
            canvas.drawText("تاريخ التصدير: $dateStr - صفحة $pageNum".toStandardDigits(), PAGE_WIDTH / 2f, PAGE_HEIGHT - 18f, footerPaint)
        }

        fun checkNewPage(neededSpace: Float = 30f, onNewPage: (() -> Unit)? = null) {
            if (yPos + neededSpace > PAGE_HEIGHT - 35f) {
                drawFooter()
                document.finishPage(page)
                pageNum++
                page = document.startPage(pageInfo)
                canvas = page.canvas
                yPos = 36f
                onNewPage?.invoke()
            }
        }

        drawHeader()

        fun drawTable(headers: List<String>, data: List<List<String>>, weights: List<Float>) {
            val totalWeight = weights.sum()
            val availableWidth = PAGE_WIDTH - 2 * MARGIN
            val colWidths = weights.map { (it / totalWeight) * availableWidth }
            val defaultRowHeight = 22f

            val headerBgPaint = Paint().apply { color = Color.parseColor("#0B6659"); isAntiAlias = true }
            val rowBgPaint1 = Paint().apply { color = Color.parseColor("#F8FAFC"); isAntiAlias = true }
            val rowBgPaint2 = Paint().apply { color = Color.WHITE; isAntiAlias = true }
            val borderPaint = Paint().apply { color = Color.parseColor("#CBD5E1"); style = Paint.Style.STROKE; strokeWidth = 0.8f; isAntiAlias = true }
            val textPaint = TextPaint(normalPaint).apply { textAlign = Paint.Align.LEFT }

            fun drawTableHeaderRow() {
                canvas.drawRect(MARGIN, yPos, PAGE_WIDTH - MARGIN, yPos + defaultRowHeight, headerBgPaint)
                var xPos = PAGE_WIDTH - MARGIN
                headers.forEachIndexed { i, header ->
                    val pad = 4f
                    canvas.drawText(header, xPos - pad, yPos + 15f, tableHeaderPaint)
                    xPos -= colWidths[i]
                }
                yPos += defaultRowHeight
            }

            checkNewPage(defaultRowHeight + 10f)
            drawTableHeaderRow()

            data.forEachIndexed { rowIndex, row ->
                var maxLines = 1
                val layouts = row.mapIndexed { colIndex, rawText ->
                    val text = rawText.toStandardDigits()
                    val width = colWidths[colIndex].toInt() - 8
                    if (width > 0) {
                        val sl = StaticLayout.Builder.obtain(text, 0, text.length, textPaint, width)
                            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                            .setIncludePad(false)
                            .build()
                        if (sl.lineCount > maxLines) maxLines = sl.lineCount
                        sl
                    } else null
                }

                val rowHeight = Math.max(defaultRowHeight, maxLines * 12f + 7f)
                checkNewPage(rowHeight + 4f) {
                    drawTableHeaderRow()
                }

                val bg = if (rowIndex % 2 == 0) rowBgPaint1 else rowBgPaint2
                canvas.drawRect(MARGIN, yPos, PAGE_WIDTH - MARGIN, yPos + rowHeight, bg)
                canvas.drawRect(MARGIN, yPos, PAGE_WIDTH - MARGIN, yPos + rowHeight, borderPaint)

                var colX = PAGE_WIDTH - MARGIN
                layouts.forEachIndexed { colIndex, sl ->
                    val width = colWidths[colIndex]
                    canvas.drawLine(colX - width, yPos, colX - width, yPos + rowHeight, borderPaint)
                    if (sl != null) {
                        canvas.save()
                        val textY = yPos + (rowHeight - (sl.height)) / 2f
                        canvas.translate(colX - width + 4f, textY)
                        sl.draw(canvas)
                        canvas.restore()
                    }
                    colX -= width
                }
                yPos += rowHeight
            }
        }

        when (currentTab) {
            "SETTINGS" -> {
                canvas.drawText("قاعدة بيانات الطلبة (${scopedStudents.size} طالب)".toStandardDigits(), PAGE_WIDTH / 2f, yPos, subHeaderPaint)
                yPos += 26f

                val headers = listOf("م", "اسم الطالب الكامل", "القسم", "تاريخ الإضافة")
                val data = scopedStudents.mapIndexed { i, s ->
                    val date = SimpleDateFormat("dd/MM/yyyy", Locale.US).format(Date(s.createdAt)).toStandardDigits()
                    listOf((i + 1).toString(), s.fullName, s.safeDepartment, date)
                }
                val weights = listOf(0.8f, 3.2f, 1.8f, 1.8f)
                drawTable(headers, data, weights)
            }
            "LESSONS" -> {
                if (openedLessonId != null) {
                    val lesson = mosque.lessons.find { it.id == openedLessonId }
                    if (lesson != null) {
                        canvas.drawText("سجل الدرس اليومي (${lesson.day} - ${lesson.dateStr})", PAGE_WIDTH / 2f, yPos, subHeaderPaint)
                        yPos += 22f

                        val headers = listOf("م", "اسم الطالب", "الحضور", "المنهج", "الصفحة", "التقييم", "السلوك")
                        val data = lesson.records.mapIndexed { i, r ->
                            val isAttPresent = r.attendance == "حضور"
                            val resolvedType = if (r.type.isNullOrBlank()) "تلاوة" else r.type
                            var finalType = if (isAttPresent) resolvedType else "-"
                            if (isAttPresent && !r.optTestType.isNullOrEmpty()) {
                                finalType += "\nاختبار: ${r.optTestType}"
                            }
                            listOf(
                                (i + 1).toString(),
                                r.studentName,
                                r.attendance,
                                finalType,
                                if (isAttPresent) (r.page?.ifEmpty { "-" } ?: "-") else "-",
                                if (isAttPresent) formatGradeForPdf(r.grade) else "-",
                                if (isAttPresent) formatBehaviorForPdf(r.behavior) else "-"
                            )
                        }
                        val weights = listOf(0.7f, 2.3f, 1.2f, 1.6f, 1.2f, 1.5f, 1.4f)
                        drawTable(headers, data, weights)
                    }
                } else {
                    canvas.drawText("سجل جميع الدروس اليومية", PAGE_WIDTH / 2f, yPos, subHeaderPaint)
                    yPos += 22f

                    val headers = listOf("م", "اليوم", "التاريخ", "الطلاب الحاضرين", "الغياب")
                    val data = mosque.lessons.reversed().mapIndexed { i, l ->
                        val present = l.records.count { it.attendance == "حضور" }
                        val absent = l.records.count { it.attendance == "غائب" }
                        listOf((i + 1).toString(), l.day, l.dateStr, present.toString(), absent.toString())
                    }
                    val weights = listOf(0.8f, 2f, 2f, 2f, 1.5f)
                    drawTable(headers, data, weights)
                }
            }
            "TESTS" -> {
                if (openedTestId != null) {
                    val test = mosque.tests.find { it.id == openedTestId }
                    if (test != null) {
                        canvas.drawText("سجل الاختبار: ${test.title ?: "اختبار دوري"} (${test.displayDay} - ${test.displayDate})", PAGE_WIDTH / 2f, yPos, subHeaderPaint)
                        yPos += 22f

                        val records = test.allRecords(mosque)
                        val headers = listOf("م", "اسم الطالب", "الحضور", "المنهج", "الصفحة / السورة", "التقييم", "السلوك")
                        val data = records.mapIndexed { i, r ->
                            val isAttPresent = r.attendance == "حضور"
                            listOf(
                                (i + 1).toString(),
                                r.studentName,
                                r.attendance,
                                if (isAttPresent) (r.type?.ifEmpty { "-" } ?: "-") else "-",
                                if (isAttPresent) (r.info?.ifEmpty { "-" } ?: "-") else "-",
                                if (isAttPresent) formatGradeForPdf(r.grade) else "-",
                                if (isAttPresent) formatBehaviorForPdf(r.behavior) else "-"
                            )
                        }
                        val weights = listOf(0.7f, 2.3f, 1.2f, 1.5f, 1.7f, 1.5f, 1.4f)
                        drawTable(headers, data, weights)
                    }
                } else {
                    canvas.drawText("سجل الاختبارات والتقييمات", PAGE_WIDTH / 2f, yPos, subHeaderPaint)
                    yPos += 22f

                    val headers = listOf("م", "اليوم", "التاريخ", "اسم الاختبار", "حضور", "ممتاز 100")
                    val data = mosque.tests.reversed().mapIndexed { i, t ->
                        val records = t.allRecords(mosque)
                        val present = records.count { it.attendance == "حضور" }
                        val fullMarks = records.count { (it.grade ?: "").contains("100") || (it.grade ?: "").contains("ممتاز") }
                        listOf((i + 1).toString(), t.displayDay, t.displayDate, t.title ?: "اختبار دوري", present.toString(), fullMarks.toString())
                    }
                    val weights = listOf(0.8f, 1.8f, 2f, 2.8f, 1.3f, 1.5f)
                    drawTable(headers, data, weights)
                }
            }
            "JUZ" -> {
                canvas.drawText("السجل - متابعة إنجاز الأجزاء والرشيدي", PAGE_WIDTH / 2f, yPos, subHeaderPaint)
                yPos += 22f

                val headers = listOf("م", "اسم الطالب", "المنهج", "الجزء المنجز / البيان")
                val records = mosque.safeJuzRecords
                val data = records.mapIndexed { i, r ->
                    listOf(
                        (i + 1).toString(),
                        r.studentName,
                        r.curriculum,
                        r.completionText
                    )
                }
                val weights = listOf(0.8f, 3f, 1.8f, 3.2f)
                drawTable(headers, data, weights)
            }
            "EXAM_SCHEDULE" -> {
                val appts = mosque.safeExamAppointments
                val groupDate = appts.firstOrNull()?.groupDateStr?.takeIf { it.isNotBlank() }
                    ?: SimpleDateFormat("dd/MM/yyyy", Locale.US).format(Date()).toStandardDigits()
                canvas.drawText("جدول مواعيد الاختبارات - تاريخ المجموعة: $groupDate", PAGE_WIDTH / 2f, yPos, subHeaderPaint)
                yPos += 22f

                val headers = listOf("م", "اسم الطالب", "القسم", "نوع الاختبار / الأجزاء", "تاريخ وموعد الاختبار", "الحالة")
                val data = appts.mapIndexed { i, a ->
                    val testDesc = if (a.section == "رشيدي") "اختبار " + a.safeRashidiType else a.displayDetails
                    val dateStr = a.safeAppointmentDate // "لم يحدد" عند تركها فارغة
                    listOf(
                        (i + 1).toString(),
                        a.studentName,
                        if (a.section == "رشيدي") "الرشيدي" else "التلاوة",
                        testDesc,
                        dateStr,
                        a.status
                    )
                }
                val weights = listOf(0.7f, 2.5f, 1.3f, 3.0f, 2.0f, 1.2f)
                drawTable(headers, data, weights)
            }
            "GIFTS" -> {
                canvas.drawText("السلام عليكم ورحمة الله وبركاته", PAGE_WIDTH / 2f, yPos, subHeaderPaint)
                yPos += 22f
                canvas.drawText("إحصائيات هذا الأسبوع - مسجد ${mosque.name}", PAGE_WIDTH / 2f, yPos, headerPaint)
                yPos += 26f
                canvas.drawText("🎁 لوحة المتفوقين وقائمة الهدايا والنجوم ⭐", PAGE_WIDTH / 2f, yPos, subHeaderPaint)
                yPos += 24f

                val allRewards = RewardCalculator.calculateRewards(mosque)
                val categories = listOf(RewardCalculator.CATEGORY_TILAWA, RewardCalculator.CATEGORY_RASHIDI, RewardCalculator.CATEGORY_MEMORIZATION)

                categories.forEach { cat ->
                    val catRewards = allRewards.filter { it.category == cat }
                    if (catRewards.isNotEmpty()) {
                        checkNewPage(40f)
                        canvas.drawText("فئة [ $cat ]", PAGE_WIDTH - MARGIN, yPos, sectionTitlePaint)
                        yPos += 18f

                        val headers = listOf("الترتيب", "اسم الطالب", "ممتاز 100", "مؤدب", "حضور", "الهدية والنجوم", "السلوك")
                        val data = catRewards.map { r ->
                            listOf(
                                r.rankInCategory.toString(),
                                r.studentName,
                                r.fullMarksCount.toString(),
                                r.politeCount.toString(),
                                r.presentCount.toString(),
                                "${r.starsDisplay} (${r.giftBadge.replace("🏆 ", "").replace("🥈 ", "").replace("⭐ ", "")})",
                                r.behaviorStatus
                            )
                        }
                        val weights = listOf(0.9f, 2.5f, 1.2f, 1.1f, 1.1f, 2.3f, 1.3f)
                        drawTable(headers, data, weights)
                        yPos += 16f
                    }
                }
            }
            "REPORTS" -> {
                val allRewards = RewardCalculator.calculateRewards(mosque)
                val rewardsMap = allRewards.associateBy { it.studentId }

                if (reportStudentId == "all" || reportStudentId == null) {
                    val titleHeader = if (!reportPeriodTitle.isNullOrBlank()) reportPeriodTitle else "📊 التقرير الإحصائي وتقييم أداء طلبة المجموعة"
                    canvas.drawText(titleHeader, PAGE_WIDTH / 2f, yPos, subHeaderPaint)
                    yPos += 26f

                    checkNewPage(40f)
                    canvas.drawText("1. جدول إحصائيات وتقييم أداء طلبة المجموعة (${scopedStudents.size} طالب)".toStandardDigits(), PAGE_WIDTH - MARGIN, yPos, sectionTitlePaint)
                    yPos += 18f

                    val statHeaders = listOf("م", "اسم الطالب", "القسم", "حضور", "غياب", "ممتاز 100", "التقييم العام", "السلوك")
                    val statData = scopedStudents.mapIndexed { i, s ->
                        val r = rewardsMap[s.id]
                        listOf(
                            (i + 1).toString(),
                            s.fullName,
                            s.safeDepartment,
                            (r?.presentCount ?: 0).toString(),
                            (r?.absentCount ?: 0).toString(),
                            (r?.fullMarksCount ?: 0).toString(),
                            r?.rankTitle ?: "مشارك",
                            r?.behaviorStatus ?: "-"
                        )
                    }
                    val statWeights = listOf(0.7f, 2.4f, 1.3f, 1.1f, 1.1f, 1.3f, 1.8f, 1.3f)
                    drawTable(statHeaders, statData, statWeights)

                    yPos += 20f

                    checkNewPage(40f)
                    canvas.drawText("2. سجل الدروس اليومية المفصل لطلبة المجموعة", PAGE_WIDTH - MARGIN, yPos, sectionTitlePaint)
                    yPos += 18f

                    val allLessonsData = mutableListOf<List<String>>()
                    var count = 1
                    mosque.lessons.reversed().forEach { l ->
                        l.records
                            .filter { it.studentId in scopedStudentIds }
                            .forEach { r ->
                                val sName = scopedStudents.find { it.id == r.studentId }?.fullName ?: r.studentName
                                val isAttPresent = r.attendance == "حضور"
                                var finalType = if (isAttPresent) (r.type?.ifEmpty { "-" } ?: "-") else "-"
                                if (isAttPresent && !r.optTestType.isNullOrEmpty()) {
                                    finalType += "\nاختبار: ${r.optTestType}"
                                }
                                allLessonsData.add(
                                    listOf(
                                        count++.toString(),
                                        l.dateStr,
                                        sName,
                                        r.attendance,
                                        finalType,
                                        if (isAttPresent) (r.page ?: "-") else "-",
                                        if (isAttPresent) formatGradeForPdf(r.grade) else "-",
                                        if (isAttPresent) formatBehaviorForPdf(r.behavior) else "-"
                                    )
                                )
                            }
                    }
                    val headers1 = listOf("م", "التاريخ", "الطالب", "الحضور", "المنهج", "الصفحة", "التقييم", "السلوك")
                    val weights1 = listOf(0.7f, 1.6f, 2.2f, 1.2f, 1.5f, 1.2f, 1.5f, 1.4f)
                    if (allLessonsData.isNotEmpty()) {
                        drawTable(headers1, allLessonsData, weights1)
                    } else {
                        checkNewPage(20f)
                        canvas.drawText("لا يوجد سجلات دروس مسجلة لطلبة هذه المجموعة.", PAGE_WIDTH - MARGIN, yPos, normalPaint)
                        yPos += 20f
                    }
                } else {
                    val student = scopedStudents.find { it.id == reportStudentId }
                    if (student != null) {
                        canvas.drawText("تقرير إنجاز الطالب: ${student.fullName}", PAGE_WIDTH / 2f, yPos, subHeaderPaint)
                        yPos += 26f

                        val reward = rewardsMap[student.id]
                        if (reward != null) {
                            checkNewPage(60f)
                            canvas.drawText("الملخص التقييمي للطالب:", PAGE_WIDTH - MARGIN, yPos, sectionTitlePaint)
                            yPos += 18f

                            val summaryData = listOf(
                                listOf("القسم المسجل به", student.safeDepartment),
                                listOf("التقييم العام ومستوى الطالب", reward.rankTitle),
                                listOf("عدد مرات العلامة التامة (100)", reward.fullMarksCount.toString()),
                                listOf("مرات السلوك المؤدب", reward.politeCount.toString()),
                                listOf("أيام الحضور والالتزام", "${reward.presentCount} (غياب: ${reward.absentCount})"),
                                listOf("السلوك العام", reward.behaviorStatus)
                            )
                            drawTable(listOf("البند", "البيان"), summaryData, listOf(2.5f, 4.5f))
                            yPos += 20f
                        }

                        checkNewPage(40f)
                        canvas.drawText("سجل الدروس والتسميع للطالب", PAGE_WIDTH - MARGIN, yPos, sectionTitlePaint)
                        yPos += 18f

                        val studentLessons = mosque.lessons.mapNotNull { l ->
                            val r = l.records.find { it.studentId == reportStudentId }
                            if (r != null) Pair(l, r) else null
                        }.reversed()

                        val headers1 = listOf("م", "التاريخ", "الحضور", "المنهج", "الصفحة", "التقييم", "السلوك")
                        val data1 = studentLessons.mapIndexed { i, (l, r) ->
                            val isAttPresent = r.attendance == "حضور"
                            listOf(
                                (i + 1).toString(),
                                l.dateStr,
                                r.attendance,
                                if (isAttPresent) (r.type ?: "-") else "-",
                                if (isAttPresent) (r.page?.ifEmpty { "-" } ?: "-") else "-",
                                if (isAttPresent) formatGradeForPdf(r.grade) else "-",
                                if (isAttPresent) formatBehaviorForPdf(r.behavior) else "-"
                            )
                        }
                        val weights1 = listOf(0.7f, 1.7f, 1.3f, 1.6f, 1.2f, 1.5f, 1.4f)
                        if (data1.isNotEmpty()) {
                            drawTable(headers1, data1, weights1)
                        } else {
                            checkNewPage(20f)
                            canvas.drawText("لا يوجد سجل دروس لهذا الطالب.", PAGE_WIDTH - MARGIN, yPos, normalPaint)
                            yPos += 20f
                        }
                    }
                }
            }
        }

        drawFooter()
        document.finishPage(page)

        try {
            val file = File(context.cacheDir, "Export_${mosque.name}.pdf")
            document.writeTo(FileOutputStream(file))
            document.close()

            if (shareAsImage) {
                val fd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
                val renderer = PdfRenderer(fd)
                val pageCount = renderer.pageCount
                var totalHeight = 0
                val bitmaps = mutableListOf<Bitmap>()
                val scale = 2.5f
                for (i in 0 until pageCount) {
                    val p = renderer.openPage(i)
                    val w = (p.width * scale).toInt()
                    val h = (p.height * scale).toInt()
                    val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                    val bgCanvas = Canvas(bitmap)
                    bgCanvas.drawColor(Color.WHITE)
                    p.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    bitmaps.add(bitmap)
                    totalHeight += h
                    p.close()
                }
                renderer.close()
                fd.close()

                val finalWidth = bitmaps.firstOrNull()?.width ?: 0
                val finalBitmap = Bitmap.createBitmap(finalWidth, totalHeight, Bitmap.Config.ARGB_8888)
                val finalCanvas = Canvas(finalBitmap)
                var currentY = 0f
                for (b in bitmaps) {
                    finalCanvas.drawBitmap(b, 0f, currentY, null)
                    currentY += b.height
                    b.recycle()
                }

                shareBitmapAsImage(context, mosque, finalBitmap, targetPackage)
            } else {
                val uri = FileProvider.getUriForFile(context, "com.aistudio.mosquemanager.xywz.provider", file)
                val intent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, "application/pdf")
                    flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK
                }
                withContext(Dispatchers.Main) {
                    try {
                        val chooser = Intent.createChooser(intent, "عرض PDF").apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(chooser)
                    } catch (e: Exception) {
                        Toast.makeText(context, "لا يوجد تطبيق لعرض ملفات PDF", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            withContext(Dispatchers.Main) {
                Toast.makeText(context, "خطأ في إنشاء أو مشاركة الملف", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private suspend fun shareBitmapAsImage(
        context: Context,
        mosque: Mosque,
        finalBitmap: Bitmap,
        targetPackage: String?
    ) {
        val imgFile = File(context.cacheDir, "Export_${mosque.name}.jpg")
        val outStream = FileOutputStream(imgFile)
        finalBitmap.compress(Bitmap.CompressFormat.JPEG, 92, outStream)
        outStream.close()
        finalBitmap.recycle()

        val uri = FileProvider.getUriForFile(context, "com.aistudio.mosquemanager.xywz.provider", imgFile)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "image/jpeg"
            putExtra(Intent.EXTRA_STREAM, uri)
            flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK
            if (targetPackage != null) {
                setPackage(targetPackage)
            }
        }

        withContext(Dispatchers.Main) {
            try {
                context.startActivity(intent)
            } catch (e: Exception) {
                val chooser = Intent.createChooser(intent, "مشاركة كصورة").apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(chooser)
            }
        }
    }

    private fun renderGiftsScreenBitmap(mosque: Mosque): Bitmap {
        val allRewards = RewardCalculator.calculateRewards(mosque)
        val categories = listOf(
            RewardCalculator.CATEGORY_TILAWA,
            RewardCalculator.CATEGORY_RASHIDI,
            RewardCalculator.CATEGORY_MEMORIZATION
        ).filter { cat -> allRewards.any { it.category == cat } }

        val bmpWidth = 1080
        val marginX = 40f
        val contentWidth = bmpWidth - (marginX * 2)

        var estimatedHeight = 500f
        categories.forEach { cat ->
            val catRewards = allRewards.filter { it.category == cat }
            estimatedHeight += 70f
            val top3Count = catRewards.filter { it.starsCount == 3 }.take(3).size
            if (top3Count > 0) {
                estimatedHeight += 210f
            }
            estimatedHeight += 50f
            estimatedHeight += catRewards.size * 105f
            estimatedHeight += 30f
        }
        estimatedHeight += 90f

        val bmpHeight = Math.max(1200, estimatedHeight.toInt())
        val bitmap = Bitmap.createBitmap(bmpWidth, bmpHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        val bgPaint = Paint().apply { color = Color.parseColor("#F8FAFC") }
        canvas.drawRect(0f, 0f, bmpWidth.toFloat(), bmpHeight.toFloat(), bgPaint)

        var currentY = 50f

        val salamPaint = Paint().apply {
            color = Color.parseColor("#334155")
            textSize = 28f
            isAntiAlias = true
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }
        val basmalaPaint = Paint().apply {
            color = Color.parseColor("#0B6659")
            textSize = 34f
            isAntiAlias = true
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }
        val mosqueTitlePaint = Paint().apply {
            color = Color.parseColor("#047857")
            textSize = 30f
            isAntiAlias = true
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }
        val dateSubtitlePaint = Paint().apply {
            color = Color.parseColor("#64748B")
            textSize = 20f
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }

        canvas.drawText("السلام عليكم ورحمة الله وبركاته", bmpWidth / 2f, currentY, salamPaint)
        currentY += 45f
        canvas.drawText("بسم الله الرحمن الرحيم", bmpWidth / 2f, currentY, basmalaPaint)
        currentY += 45f
        canvas.drawText("إحصائيات هذا الأسبوع - مسجد ${mosque.name}", bmpWidth / 2f, currentY, mosqueTitlePaint)
        currentY += 32f

        val formattedDate = SimpleDateFormat("EEEE، d MMMM yyyy", Locale("ar", "EG")).format(Date()).toStandardDigits()
        canvas.drawText("تاريخ التقرير: $formattedDate", bmpWidth / 2f, currentY, dateSubtitlePaint)
        currentY += 45f

        val cardBgPaint = Paint().apply { color = Color.WHITE; isAntiAlias = true }
        val cardBorderAmber = Paint().apply {
            color = Color.parseColor("#F59E0B")
            style = Paint.Style.STROKE
            strokeWidth = 2.5f
            isAntiAlias = true
        }

        val heroCardHeight = 175f
        val heroRect = RectF(marginX, currentY, bmpWidth - marginX, currentY + heroCardHeight)
        canvas.drawRoundRect(heroRect, 22f, 22f, cardBgPaint)
        canvas.drawRoundRect(heroRect, 22f, 22f, cardBorderAmber)

        val heroTitlePaint = Paint().apply {
            color = Color.parseColor("#0F172A")
            textSize = 26f
            isAntiAlias = true
            isFakeBoldText = true
            textAlign = Paint.Align.RIGHT
        }
        val heroSubtitlePaint = Paint().apply {
            color = Color.parseColor("#475569")
            textSize = 18f
            isAntiAlias = true
            textAlign = Paint.Align.RIGHT
        }

        canvas.drawText("🎁 قائمة الهدايا والجوائز والنجوم", (bmpWidth - marginX) - 30f, currentY + 42f, heroTitlePaint)
        canvas.drawText("توزيع النجوم والهدايا حسب التفوق والسلوك والحضور", (bmpWidth - marginX) - 30f, currentY + 74f, heroSubtitlePaint)

        val critBoxRect = RectF(marginX + 20f, currentY + 95f, (bmpWidth - marginX) - 20f, currentY + 155f)
        val critBgPaint = Paint().apply { color = Color.parseColor("#F8FAFC"); isAntiAlias = true }
        val critBorderPaint = Paint().apply { color = Color.parseColor("#E2E8F0"); style = Paint.Style.STROKE; strokeWidth = 1.5f; isAntiAlias = true }
        canvas.drawRoundRect(critBoxRect, 14f, 14f, critBgPaint)
        canvas.drawRoundRect(critBoxRect, 14f, 14f, critBorderPaint)

        val critColWidth = critBoxRect.width() / 3f
        val star3Paint = Paint().apply { color = Color.parseColor("#D97706"); textSize = 17f; isAntiAlias = true; isFakeBoldText = true; textAlign = Paint.Align.CENTER }
        val star2Paint = Paint().apply { color = Color.parseColor("#0284C7"); textSize = 17f; isAntiAlias = true; isFakeBoldText = true; textAlign = Paint.Align.CENTER }
        val star1Paint = Paint().apply { color = Color.parseColor("#059669"); textSize = 17f; isAntiAlias = true; isFakeBoldText = true; textAlign = Paint.Align.CENTER }

        val boxCenterY = critBoxRect.centerY() + 6f
        canvas.drawText("⭐⭐⭐ أول 3 طلاب (هدية كبرى)", critBoxRect.right - (critColWidth / 2f), boxCenterY, star3Paint)
        canvas.drawText("⭐⭐ الـ 5 التاليين (هدية مميزة)", critBoxRect.left + (critColWidth * 1.5f), boxCenterY, star2Paint)
        canvas.drawText("⭐ باقي الطلاب (تشجيعية)", critBoxRect.left + (critColWidth / 2f), boxCenterY, star1Paint)

        currentY += heroCardHeight + 35f

        categories.forEach { cat ->
            val catRewards = allRewards.filter { it.category == cat }
            if (catRewards.isEmpty()) return@forEach

            val catTitlePaint = Paint().apply {
                color = Color.parseColor("#1E1B4B")
                textSize = 24f
                isAntiAlias = true
                isFakeBoldText = true
                textAlign = Paint.Align.RIGHT
            }
            canvas.drawText("🏆 أوائل المتفوقين في فئة [ $cat ]", (bmpWidth - marginX), currentY, catTitlePaint)
            currentY += 22f

            val top3 = catRewards.filter { it.starsCount == 3 }.take(3)
            if (top3.isNotEmpty()) {
                val podiumCardWidth = (contentWidth - ((top3.size - 1) * 16f)) / top3.size
                val podiumCardHeight = 170f
                var pX = (bmpWidth - marginX) - podiumCardWidth

                top3.forEachIndexed { rankIndex, r ->
                    val (pBgColor, pBorderColor, pMedal, pBadgeBg, pBadgeText) = when (rankIndex) {
                        0 -> listOf("#FFFBEB", "#F59E0B", "🥇", "#FEF3C7", "#D97706")
                        1 -> listOf("#F1F5F9", "#94A3B8", "🥈", "#E2E8F0", "#475569")
                        else -> listOf("#FFF7ED", "#EA580C", "🥉", "#FFEDD5", "#C2410C")
                    }

                    val pRect = RectF(pX, currentY, pX + podiumCardWidth, currentY + podiumCardHeight)
                    val pBg = Paint().apply { color = Color.parseColor(pBgColor); isAntiAlias = true }
                    val pBorder = Paint().apply { color = Color.parseColor(pBorderColor); style = Paint.Style.STROKE; strokeWidth = 2f; isAntiAlias = true }
                    canvas.drawRoundRect(pRect, 18f, 18f, pBg)
                    canvas.drawRoundRect(pRect, 18f, 18f, pBorder)

                    val medalPaint = Paint().apply { textSize = 28f; textAlign = Paint.Align.CENTER; isAntiAlias = true }
                    canvas.drawText(pMedal, pRect.centerX(), currentY + 36f, medalPaint)

                    val namePaint = Paint().apply {
                        color = Color.parseColor("#0F172A")
                        textSize = 19f
                        isAntiAlias = true
                        isFakeBoldText = true
                        textAlign = Paint.Align.CENTER
                    }
                    val displayName = if (r.studentName.length > 20) r.studentName.take(19) + "…" else r.studentName
                    canvas.drawText(displayName, pRect.centerX(), currentY + 70f, namePaint)

                    val starsPaint = Paint().apply { textSize = 18f; textAlign = Paint.Align.CENTER; isAntiAlias = true }
                    canvas.drawText("⭐⭐⭐", pRect.centerX(), currentY + 100f, starsPaint)

                    val badgeRect = RectF(pRect.centerX() - 70f, currentY + 115f, pRect.centerX() + 70f, currentY + 145f)
                    val badgeBg = Paint().apply { color = Color.parseColor(pBadgeBg); isAntiAlias = true }
                    val badgeTextPaint = Paint().apply { color = Color.parseColor(pBadgeText); textSize = 14f; isFakeBoldText = true; textAlign = Paint.Align.CENTER; isAntiAlias = true }
                    canvas.drawRoundRect(badgeRect, 8f, 8f, badgeBg)
                    canvas.drawText("هدية كبرى 🏆", badgeRect.centerX(), badgeRect.centerY() + 5f, badgeTextPaint)

                    pX -= (podiumCardWidth + 16f)
                }
                currentY += podiumCardHeight + 25f
            }

            val subSectionPaint = Paint().apply {
                color = Color.parseColor("#475569")
                textSize = 19f
                isAntiAlias = true
                isFakeBoldText = true
                textAlign = Paint.Align.RIGHT
            }
            canvas.drawText("ترتيب وتوزيع النجوم لجميع طلبة فئة [ $cat ] (${catRewards.size} طالب):", (bmpWidth - marginX), currentY, subSectionPaint)
            currentY += 18f

            val cardNormalBg = Paint().apply { color = Color.WHITE; isAntiAlias = true }
            val cardNormalBorder = Paint().apply { color = Color.parseColor("#E2E8F0"); style = Paint.Style.STROKE; strokeWidth = 1.2f; isAntiAlias = true }

            catRewards.forEach { r ->
                val sCardHeight = 90f
                val sCardRect = RectF(marginX, currentY, bmpWidth - marginX, currentY + sCardHeight)

                canvas.drawRoundRect(sCardRect, 16f, 16f, cardNormalBg)
                canvas.drawRoundRect(sCardRect, 16f, 16f, cardNormalBorder)

                val rankCircleX = (bmpWidth - marginX) - 40f
                val rankCircleY = currentY + (sCardHeight / 2f)
                val rankCircleRadius = 24f

                val (circleBgColor, circleBorderColor, circleTextColor) = when (r.starsCount) {
                    3 -> listOf("#FEF3C7", "#F59E0B", "#D97706")
                    2 -> listOf("#E0F2FE", "#0284C7", "#0369A1")
                    else -> listOf("#ECFDF5", "#10B981", "#047857")
                }

                val circleBg = Paint().apply { color = Color.parseColor(circleBgColor); isAntiAlias = true }
                val circleBorder = Paint().apply { color = Color.parseColor(circleBorderColor); style = Paint.Style.STROKE; strokeWidth = 2f; isAntiAlias = true }
                val circleText = Paint().apply { color = Color.parseColor(circleTextColor); textSize = 18f; isFakeBoldText = true; textAlign = Paint.Align.CENTER; isAntiAlias = true }

                canvas.drawCircle(rankCircleX, rankCircleY, rankCircleRadius, circleBg)
                canvas.drawCircle(rankCircleX, rankCircleY, rankCircleRadius, circleBorder)
                canvas.drawText(r.rankInCategory.toString().toStandardDigits(), rankCircleX, rankCircleY + 6f, circleText)

                val sNamePaint = Paint().apply {
                    color = Color.parseColor("#0F172A")
                    textSize = 21f
                    isAntiAlias = true
                    isFakeBoldText = true
                    textAlign = Paint.Align.RIGHT
                }
                val sNameX = rankCircleX - rankCircleRadius - 16f
                canvas.drawText(r.studentName, sNameX, currentY + 36f, sNamePaint)

                val catPillText = r.category
                val catPillPaint = Paint().apply { color = Color.parseColor("#0B6659"); textSize = 13f; isFakeBoldText = true; textAlign = Paint.Align.RIGHT; isAntiAlias = true }
                val nameWidth = sNamePaint.measureText(r.studentName)
                canvas.drawText("[$catPillText]", sNameX - nameWidth - 12f, currentY + 36f, catPillPaint)

                val sStatsPaint = Paint().apply {
                    color = Color.parseColor("#64748B")
                    textSize = 15.5f
                    isAntiAlias = true
                    textAlign = Paint.Align.RIGHT
                }
                val statsText = "ممتاز 100: ${r.fullMarksCount.toString().toStandardDigits()}  •  مؤدب: ${r.politeCount.toString().toStandardDigits()}  •  حضور: ${r.presentCount.toString().toStandardDigits()}  •  السلوك: ${r.behaviorStatus}"
                canvas.drawText(statsText, sNameX, currentY + 68f, sStatsPaint)

                val starsLeftX = marginX + 30f
                val sStarDisplayPaint = Paint().apply { textSize = 22f; textAlign = Paint.Align.LEFT; isAntiAlias = true }
                val starStr = when (r.starsCount) {
                    3 -> "⭐⭐⭐"
                    2 -> "⭐⭐"
                    else -> "⭐"
                }
                canvas.drawText(starStr, starsLeftX, currentY + 36f, sStarDisplayPaint)

                val badgeClean = r.giftBadge.replace("🏆 ", "").replace("🥈 ", "").replace("⭐ ", "")
                val badgePillRect = RectF(starsLeftX, currentY + 48f, starsLeftX + 110f, currentY + 74f)
                val badgePillBg = Paint().apply { color = Color.parseColor(circleBgColor); isAntiAlias = true }
                val badgePillText = Paint().apply { color = Color.parseColor(circleTextColor); textSize = 13f; isFakeBoldText = true; textAlign = Paint.Align.CENTER; isAntiAlias = true }
                canvas.drawRoundRect(badgePillRect, 6f, 6f, badgePillBg)
                canvas.drawText(badgeClean, badgePillRect.centerX(), badgePillRect.centerY() + 4.5f, badgePillText)

                currentY += sCardHeight + 12f
            }

            currentY += 25f
        }

        val footerPaint = Paint().apply {
            color = Color.parseColor("#94A3B8")
            textSize = 16f
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }
        val exportTime = SimpleDateFormat("dd/MM/yyyy - HH:mm", Locale.US).format(Date()).toStandardDigits()
        canvas.drawText("نظام إدارة الحلقات القرآنية - مسجد ${mosque.name} - تاريخ التصدير: $exportTime", bmpWidth / 2f, currentY + 20f, footerPaint)

        return bitmap
    }
}
