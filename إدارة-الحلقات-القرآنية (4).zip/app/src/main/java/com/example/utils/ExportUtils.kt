package com.example.utils

import android.content.Context
import android.content.Intent
import com.example.data.Mosque

object ExportUtils {

    private fun formatBehavior(behavior: String?): String {
        return when (behavior?.trim()) {
            "مؤدب" -> "🌟 مؤدب"
            "يحتاج هدوء" -> "يحتاج هدوء"
            else -> ""
        }
    }

    private fun formatGrade(grade: String?): String {
        val g = grade?.trim() ?: ""
        if (g.isEmpty() || g == "-") return "-"
        return when {
            g.contains("100") -> "$g 💯"
            g.contains("ممتاز") -> "$g ⭐"
            else -> g
        }
    }

    fun shareWhatsApp(
        context: Context,
        mosque: Mosque,
        currentTab: String,
        openedLessonId: String?,
        openedTestId: String?,
        reportStudentId: String?,
        reportPeriodTitle: String? = null
    ) {
        val scopedStudents = mosque.scopedStudents
        var text = "بسم الله الرحمن الرحيم\n🕌 *${mosque.name}*\n\n"

        when (currentTab) {
            "LESSONS" -> {
                if (openedLessonId != null) {
                    val lesson = mosque.lessons.find { it.id == openedLessonId }
                    if (lesson != null) {
                        text += "📖 *سجل الدرس اليومي: ${lesson.day} - ${lesson.dateStr}*\n"
                        text += "-----------------------------------\n"
                        lesson.records.forEachIndexed { i, r ->
                            val num = (i + 1).toString().toStandardDigits()
                            if (r.attendance == "حضور") {
                                val pageText = if (!r.page.isNullOrEmpty()) " ص ${r.page}" else ""
                                val gradeText = formatGrade(r.grade)
                                val beh = formatBehavior(r.behavior)
                                val behaviorText = if (beh.isNotEmpty()) " [السلوك: $beh]" else ""
                                val curriculumType = if (r.type.isNullOrBlank()) "-" else r.type
                                var recordText = "$num. *${r.studentName}*: $curriculumType$pageText ($gradeText)$behaviorText"
                                if (!r.optTestType.isNullOrEmpty()) {
                                    val optInfo = if (!r.optTestInfo.isNullOrEmpty()) " ${r.optTestInfo}" else ""
                                    recordText += " | اختبار: ${r.optTestType}$optInfo"
                                }
                                text += recordText + "\n"
                            } else {
                                val attIcon = if (r.attendance == "غائب") "❌ " else if (r.attendance == "إذن") "🟡 " else ""
                                text += "$num. *${r.studentName}*: $attIcon${r.attendance}\n"
                            }
                        }
                    }
                } else {
                    text += "📋 *ملخص الدروس اليومية*\n"
                    text += "إجمالي الدروس: ${mosque.lessons.size}\n"
                    text += "إجمالي الطلبة: ${scopedStudents.size}\n"
                }
            }
            "TESTS" -> {
                if (openedTestId != null) {
                    val test = mosque.tests.find { it.id == openedTestId }
                    if (test != null) {
                        text += "📝 *سجل الاختبار: ${test.title ?: "اختبار دوري"} (${test.displayDay} - ${test.displayDate})*\n"
                        text += "-----------------------------------\n"
                        val records = test.allRecords(mosque)
                        records.forEachIndexed { i, r ->
                            val num = (i + 1).toString().toStandardDigits()
                            if (r.attendance == "حضور") {
                                val infoText = if (!r.info.isNullOrEmpty()) " (${r.info})" else ""
                                val gradeText = formatGrade(r.grade)
                                val beh = formatBehavior(r.behavior)
                                val behaviorText = if (beh.isNotEmpty()) " [السلوك: $beh]" else ""
                                val curriculumType = if (r.type.isNullOrBlank()) "-" else r.type
                                text += "$num. *${r.studentName}*: $curriculumType$infoText - $gradeText$behaviorText\n"
                            } else {
                                val attIcon = if (r.attendance == "غائب") "❌ " else if (r.attendance == "إذن") "🟡 " else ""
                                text += "$num. *${r.studentName}*: $attIcon${r.attendance}\n"
                            }
                        }
                    }
                } else {
                    text += "📝 *سجل الاختبارات والتقييمات*\n"
                    text += "إجمالي الاختبارات: ${mosque.tests.size}\n"
                    text += "-----------------------------------\n"
                    mosque.tests.reversed().forEachIndexed { i, test ->
                        val records = test.allRecords(mosque)
                        val present = records.count { it.attendance == "حضور" }
                        val fullMarks = records.count { (it.grade ?: "").contains("100") || (it.grade ?: "").contains("ممتاز") }
                        text += "${(i + 1).toString().toStandardDigits()}. *${test.title ?: "اختبار"}* [${test.displayDay} ${test.displayDate}] (حضور: $present, 💯 ممتاز: $fullMarks)\n"
                    }
                }
            }
            "JUZ" -> {
                val day = java.text.SimpleDateFormat("EEEE", java.util.Locale("ar", "EG")).format(java.util.Date())
                val dateStr = java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.US).format(java.util.Date()).toStandardDigits()
                text = "بسم الله الرحمن الرحيم\n"
                text += "بفضل الله سبحانه وتعالى\n"
                text += "${mosque.name}\n"
                text += "السجل - $day $dateStr\n"
                text += "-----------------------------------\n"
                val records = mosque.safeJuzRecords
                if (records.isEmpty()) {
                    text += "لا توجد أسماء مسجلة في قائمة الأجزاء حالياً.\n"
                } else {
                    records.forEachIndexed { i, r ->
                        val num = (i + 1).toString().toStandardDigits()
                        text += "$num. *${r.studentName}*: ${r.completionText} (${r.curriculum})\n"
                    }
                }
                text += "-----------------------------------\n"
                text += "اللهم بارك في طلابنا واجعل القرآن ربيع قلوبهم.\n"
            }
            "EXAM_SCHEDULE" -> {
                val day = java.text.SimpleDateFormat("EEEE", java.util.Locale("ar", "EG")).format(java.util.Date())
                val dateStr = java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.US).format(java.util.Date()).toStandardDigits()
                val appts = mosque.safeExamAppointments
                val groupDateLabel = appts.firstOrNull()?.groupDateStr?.takeIf { it.isNotBlank() } ?: "$day $dateStr"
                text = "بسم الله الرحمن الرحيم\n"
                text += "🕌 *${mosque.name}*\n"
                text += "📅 *جدول مواعيد الاختبارات* (تاريخ المجموعة: $groupDateLabel)\n"
                text += "-----------------------------------\n"
                if (appts.isEmpty()) {
                    text += "لا توجد مواعيد اختبارات مسجلة حالياً.\n"
                } else {
                    val rashidiList = appts.filter { it.section == "رشيدي" }
                    val tilawaList = appts.filter { it.section != "رشيدي" }

                    if (rashidiList.isNotEmpty()) {
                        text += "📋 *قسم الرشيدي:*\n"
                        rashidiList.forEachIndexed { i, a ->
                            val num = (i + 1).toString().toStandardDigits()
                            val dateInfo = " [الموعد: ${a.safeAppointmentDate}]"
                            val statusInfo = if (a.status != "مجدول") " (${a.status})" else ""
                            text += "$num. *${a.studentName}*: اختبار ${a.safeRashidiType}$dateInfo$statusInfo\n"
                        }
                        text += "\n"
                    }

                    if (tilawaList.isNotEmpty()) {
                        text += "📖 *قسم التلاوة:*\n"
                        tilawaList.forEachIndexed { i, a ->
                            val num = (i + 1).toString().toStandardDigits()
                            val dateInfo = " [الموعد: ${a.safeAppointmentDate}]"
                            val statusInfo = if (a.status != "مجدول") " (${a.status})" else ""
                            text += "$num. *${a.studentName}*: ${a.displayDetails}$dateInfo$statusInfo\n"
                        }
                    }
                }
                text += "-----------------------------------\n"
                text += "نسأل الله تعالى لطلابنا الأعزاء التوفيق والنجاح والسداد.\n"
            }
            "GIFTS" -> {
                text = "السلام عليكم ورحمة الله وبركاته\n"
                text += "بسم الله الرحمن الرحيم\n"
                text += "إحصائيات هذا الأسبوع - مسجد ${mosque.name}\n\n"
                text += "🎁 *قائمة الهدايا والجوائز والنجوم* ⭐\n"
                text += "توزيع النجوم والهدايا حسب التفوق والسلوك والحضور:\n"
                text += "- ⭐⭐⭐ أول 3 طلاب (هدية كبرى)\n"
                text += "- ⭐⭐ الـ 5 التاليين (هدية مميزة)\n"
                text += "- ⭐ باقي الطلاب (هدية تشجيعية)\n\n"
                text += "-----------------------------------\n\n"

                val allRewards = RewardCalculator.calculateRewards(mosque)
                val categories = listOf(RewardCalculator.CATEGORY_TILAWA, RewardCalculator.CATEGORY_RASHIDI, RewardCalculator.CATEGORY_MEMORIZATION)

                categories.forEach { cat ->
                    val catRewards = allRewards.filter { it.category == cat }
                    if (catRewards.isNotEmpty()) {
                        text += "🏆 *أوائل المتفوقين والترتيب في فئة [ $cat ] :*\n"
                        catRewards.forEach { r ->
                            val medal = when (r.starsCount) {
                                3 -> if (r.rankInCategory == 1) "🥇" else if (r.rankInCategory == 2) "🥈" else "🥉"
                                2 -> "⭐"
                                else -> "▫️"
                            }
                            val starText = when (r.starsCount) {
                                3 -> "⭐⭐⭐"
                                2 -> "⭐⭐"
                                else -> "⭐"
                            }
                            text += "$medal ${r.rankInCategory}. *${r.studentName}* $starText (${r.giftBadge.replace("🏆 ", "").replace("🥈 ", "").replace("⭐ ", "")})\n"
                            text += "    [💯 ممتاز 100: ${r.fullMarksCount} | 🌟 مؤدب: ${r.politeCount} | 🟢 حضور: ${r.presentCount} | السلوك: ${r.behaviorStatus}]\n"
                        }
                        text += "\n"
                    }
                }
            }
            "REPORTS" -> {
                val allRewards = RewardCalculator.calculateRewards(mosque)
                val rewardsMap = allRewards.associateBy { it.studentId }

                if (reportStudentId == "all" || reportStudentId == null) {
                    val titleHeader = if (!reportPeriodTitle.isNullOrBlank()) reportPeriodTitle else "التقرير الإحصائي وتقييم أداء طلبة المجموعة"
                    text += "📊 *$titleHeader*\n"
                    text += "إجمالي طلبة المجموعة: ${scopedStudents.size}\n"
                    text += "-----------------------------------\n\n"

                    text += "📋 *جدول إحصائيات وتقييم الطلبة:*\n"
                    scopedStudents.forEachIndexed { i, student ->
                        val r = rewardsMap[student.id]
                        val fullMarks = r?.fullMarksCount ?: 0
                        val polite = r?.politeCount ?: 0
                        val present = r?.presentCount ?: 0
                        val cat = student.safeDepartment
                        val rank = r?.rankTitle ?: "مشارك"
                        text += "${(i + 1).toString().toStandardDigits()}. *${student.fullName}* [$cat] -> $rank\n"
                        text += "   حضور: $present | 💯 ممتاز: $fullMarks | 🌟 مؤدب: $polite\n"
                    }
                    text += "\n-----------------------------------\n"
                } else {
                    val student = scopedStudents.find { it.id == reportStudentId }
                    if (student != null) {
                        val reward = rewardsMap[student.id]
                        text += "👤 *تقرير إنجاز الطالب: ${student.fullName}*\n"
                        text += "-----------------------------------\n"
                        if (reward != null) {
                            text += "📖 القسم: ${student.safeDepartment}\n"
                            text += "🎖️ التقييم العام: ${reward.rankTitle}\n"
                            text += "💯 علامات ممتاز: ${reward.fullMarksCount}\n"
                            text += "🌟 مرات السلوك المؤدب: ${reward.politeCount}\n"
                            text += "🟢 مرات الحضور: ${reward.presentCount} (غياب: ${reward.absentCount})\n"
                            text += "📌 السلوك العام: ${reward.behaviorStatus}\n\n"
                        }

                        val studentLessons = mosque.lessons.mapNotNull { l ->
                            val r = l.records.find { it.studentId == reportStudentId }
                            if (r != null) Pair(l, r) else null
                        }
                        if (studentLessons.isNotEmpty()) {
                            text += "📖 *الدروس اليومية:*\n"
                            studentLessons.forEach { (l, r) ->
                                if (r.attendance == "حضور") {
                                    val beh = formatBehavior(r.behavior)
                                    val behaviorText = if (beh.isNotEmpty()) " [السلوك: $beh]" else ""
                                    val gradeText = formatGrade(r.grade)
                                    val pageText = if (!r.page.isNullOrEmpty()) " ص ${r.page}" else ""
                                    text += "- ${l.dateStr}: ${r.type ?: ""}$pageText ($gradeText)$behaviorText\n"
                                } else {
                                    val attIcon = if (r.attendance == "غائب") "❌ " else if (r.attendance == "إذن") "🟡 " else ""
                                    text += "- ${l.dateStr}: $attIcon${r.attendance}\n"
                                }
                            }
                        }
                    }
                }
            }
            else -> {
                text += "إجمالي الطلبة: ${scopedStudents.size}\n"
                text += "إجمالي الدروس: ${mosque.lessons.size}\n"
            }
        }

        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            putExtra(Intent.EXTRA_TEXT, text.toStandardDigits())
            type = "text/plain"
            setPackage("com.whatsapp")
        }

        try {
            context.startActivity(sendIntent)
        } catch (e: Exception) {
            val fallbackIntent = Intent(Intent.ACTION_SEND).apply {
                putExtra(Intent.EXTRA_TEXT, text.toStandardDigits())
                type = "text/plain"
            }
            context.startActivity(Intent.createChooser(fallbackIntent, "مشاركة عبر..."))
        }
    }
}
