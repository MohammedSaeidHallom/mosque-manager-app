package com.example.utils

import com.example.data.Mosque
import com.example.data.Student

/**
 * نوع التكرار:
 * SAME_SECTION: مكرر في نفس القسم والمسجد (خطأ إدخال)
 * CROSS_SECTION: مكرر في أكثر من قسم مختلف لنفس المسجد (مثل تلاوة ورشيدي)
 * CROSS_MOSQUE: مكرر في أكثر من مسجد أو مجموعة مختلفة
 */
enum class DuplicateType(val title: String, val description: String) {
    SAME_SECTION("تكرار في نفس القسم", "الاسم مسجل أكثر من مرة في نفس القسم والمجموعة"),
    CROSS_SECTION("مسجل في أكثر من قسم", "الاسم مسجل في أقسام متعددة داخل نفس المسجد/المجموعة"),
    CROSS_MOSQUE("مسجل في أكثر من مجموعة/مسجد", "الاسم مسجل في أكثر من مسجد أو مجموعة مستقلة")
}

data class DuplicateStudentInstance(
    val student: Student,
    val mosqueId: String,
    val mosqueName: String,
    val department: String,
    val lessonsCount: Int = 0,
    val testsCount: Int = 0
)

data class DuplicateGroup(
    val normalizedName: String,
    val displayName: String,
    val instances: List<DuplicateStudentInstance>,
    val duplicateType: DuplicateType
) {
    val key: String
        get() = "${normalizedName}_${instances.map { "${it.mosqueId}:${it.student.id}" }.sorted().joinToString(",")}"
}

object StudentDuplicateDetector {

    fun normalizeStudentName(name: String): String {
        return name.trim()
            .lowercase()
            .replace("[\u064B-\u065F\u0670\u0640]".toRegex(), "") // التشكيل والتطويل
            .replace("[أإآٱ]".toRegex(), "ا")
            .replace("ى", "ي")
            .replace("ة", "ه")
            .replace("\\s+".toRegex(), " ")
    }

    /**
     * يفحص جميع المساجد والطلبة ويرجع مجموعات الأسماء المكررة مع تفاصيل كل نسخة
     */
    fun findDuplicates(
        mosques: List<Mosque>,
        ignoredKeys: Set<String> = emptySet()
    ): List<DuplicateGroup> {
        val allInstances = mutableListOf<DuplicateStudentInstance>()
        for (mosque in mosques) {
            val studentsList = mosque.scopedStudents
            for (student in studentsList) {
                val lessonsCnt = mosque.lessons.count { l -> l.records.any { r -> r.studentId == student.id } }
                val testsCnt = mosque.tests.count { t -> t.records.any { r -> r.studentId == student.id } || t.studentId == student.id }
                allInstances.add(
                    DuplicateStudentInstance(
                        student = student,
                        mosqueId = mosque.id,
                        mosqueName = mosque.name,
                        department = student.safeDepartment,
                        lessonsCount = lessonsCnt,
                        testsCount = testsCnt
                    )
                )
            }
        }

        val grouped = allInstances
            .filter { normalizeStudentName(it.student.fullName).isNotBlank() }
            .groupBy { normalizeStudentName(it.student.fullName) }

        val result = mutableListOf<DuplicateGroup>()

        for ((normalized, instances) in grouped) {
            if (instances.size < 2) continue

            val distinctMosqueIds = instances.map { it.mosqueId }.distinct()
            val distinctMosqueNames = instances.map { normalizeStudentName(it.mosqueName) }.distinct()
            val distinctDepts = instances.map { it.department.trim() }.distinct()

            val type = when {
                distinctMosqueIds.size > 1 || distinctMosqueNames.size > 1 -> DuplicateType.CROSS_MOSQUE
                distinctDepts.size > 1 -> DuplicateType.CROSS_SECTION
                else -> DuplicateType.SAME_SECTION
            }

            val group = DuplicateGroup(
                normalizedName = normalized,
                displayName = instances.first().student.fullName,
                instances = instances,
                duplicateType = type
            )

            if (!ignoredKeys.contains(group.key) && !ignoredKeys.contains(normalized)) {
                result.add(group)
            }
        }

        return result.sortedWith(
            compareBy<DuplicateGroup> {
                when (it.duplicateType) {
                    DuplicateType.SAME_SECTION -> 0
                    DuplicateType.CROSS_SECTION -> 1
                    DuplicateType.CROSS_MOSQUE -> 2
                }
            }.thenBy { it.displayName }
        )
    }
}
